package app.Modele;

public abstract class Utilisateur {
	
	private String nom;
	private String prenom;
	private String adresse;
	private String numero_tel;
	private String login;
	protected String motDepasse;
	private String dateNaissance;
	protected String email;
	private String statut;
	
	
	public Utilisateur(String nom, String prenom, String adresse, String numero_tel, String login, String motDepasse,
			String dateNaissance, String email, String statut) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.numero_tel = numero_tel;
		this.login = login;
		this.motDepasse = motDepasse;
		this.dateNaissance = dateNaissance;
		this.email = email;
		this.statut = statut;
	}


	public Utilisateur(String motDepasse, String email) {
		super();
		this.setMotDepasse(motDepasse);
		this.setEmail(email);
	}
	
	
	public Utilisateur(String motDepasse, String email, String statut) {
		super();
		this.setMotDepasse(motDepasse);
		this.setEmail(email);
		this.setStatut(statut);
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


	public String getAdresse() {
		return adresse;
	}


	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}


	public String getNumero_tel() {
		return numero_tel;
	}


	public void setNumero_tel(String numero_tel) {
		this.numero_tel = numero_tel;
	}


	public String getLogin() {
		return login;
	}


	public void setLogin(String login) {
		this.login = login;
	}


	public String getMotDepasse() {
		return motDepasse;
	}


	public void setMotDepasse(String motDepasse) {
		this.motDepasse = motDepasse;
	}


	public String getDateNaissance() {
		return dateNaissance;
	}


	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getStatut() {
		return statut;
	}


	public void setStatut(String statut) {
		this.statut = statut;
	}
	
	
	
	
	
	
		
	
	
	
	
	

}

package app.Modele;

import java.util.Random;

public class Paiement {
	
	private int identifiantPaiement;
	private int caution;
	private int loyer;
	private int montantLocationJournalier;
	private int tranche_1;
	private int tranche_2;
	private int tranche_3;
	
	//Des attribut pour juste recuperer un Paiement ils ne font pas partie des r�el de la classe
	private String NumPiece;
	private int IdentifiantBien;
	
	
	
	
	public Paiement(int caution, int loyer, int montantLocationJournalier, int tranche_1, int tranche_2, int tranche_3,
			String numPiece, int identifiantBien) {
		super();
		this.caution = caution;
		this.loyer = loyer;
		this.montantLocationJournalier = montantLocationJournalier;
		this.tranche_1 = tranche_1;
		this.tranche_2 = tranche_2;
		this.tranche_3 = tranche_3;
		NumPiece = numPiece;
		IdentifiantBien = identifiantBien;
	}

	public Paiement() {
		
	}
	
	
	
	// constructeur pour renvoyer toutes les caracteristiques d'un paiement
	public Paiement(int caution, int loyer, int montantLocationJournalier, int tranche_1, int tranche_2,
			int tranche_3) {
		super();
		this.setCaution(caution);
		this.setLoyer(loyer);
		this.setMontantLocationJournalier(montantLocationJournalier);
		this.setTranche_1(tranche_1);
		this.setTranche_2(tranche_2);
		this.setTranche_3(tranche_3);
		this.setIdentifiantPaiement(identifiantPaiement);
		
	}
	
  // constructeur d'un Paiement a long terme
	public Paiement(int caution, int loyer) {
		super();
		this.caution = caution;
		this.loyer = loyer;
		this.setIdentifiantPaiement(identifiantPaiement);
		this.setMontantLocationJournalier(0);
		this.setTranche_1(0);
		this.setTranche_2(0);
		this.setTranche_3(0);
		this.setIdentifiantPaiement(identifiantPaiement);
	}
	
	
	
    // Constructeur d'un paiement journalier
	
	
	public Paiement(int montantLocationJournalier) {
		super();
		this.montantLocationJournalier = montantLocationJournalier;
		this.setCaution(0);
		this.setLoyer(0);
		this.setTranche_1(0);
		this.setTranche_2(0);
		this.setTranche_3(0);
		this.setIdentifiantPaiement(identifiantPaiement);
	}
	
	
	public Paiement(int montantLocationJournalier, int tranche_1, int tranche_2, int tranche_3) {
		super();
		this.montantLocationJournalier = montantLocationJournalier;
		this.tranche_1 = tranche_1;
		this.tranche_2 = tranche_2;
		this.tranche_3 = tranche_3;
		this.setIdentifiantPaiement(identifiantPaiement);
		
	}

	//constructeur d'un paiement a moyen terme
	public Paiement(int tranche_1, int tranche_2, int tranche_3) {
		super();
		this.tranche_1 = tranche_1;
		this.tranche_2 = tranche_2;
		this.tranche_3 = tranche_3;
		this.setCaution(0);
		this.setLoyer(0);
		this.setMontantLocationJournalier(0);
		this.setIdentifiantPaiement(identifiantPaiement);
	}
	
	
	
	
	


	public String getNumPiece() {
		return NumPiece;
	}

	public void setNumPiece(String numPiece) {
		NumPiece = numPiece;
	}

	public int getIdentifiantBien() {
		return IdentifiantBien;
	}

	public void setIdentifiantBien(int identifiantBien) {
		IdentifiantBien = identifiantBien;
	}
	
	
	
	

	public int getIdentifiantPaiement() {
		return identifiantPaiement;
	}

	public void setIdentifiantPaiement(int identifiantPaiement) {
		
		if(identifiantPaiement !=0)
		{
			this.identifiantPaiement = identifiantPaiement;
		}
		else
		{
			//Generation Al�atoires de l'identifiant
		Random rand = new Random();
		int max = 1500000;
		int min = 900000;		
		identifiantPaiement = rand.nextInt(max-min +1)+ min + rand.nextInt(1500000-60000)+1*2 + rand.nextInt(18000-1)+7/9; 
		this.identifiantPaiement = identifiantPaiement;
		}
	}

	public int getCaution() {
		return caution;
	}

	public void setCaution(int caution) {
		this.caution = caution;
	}

	public int getLoyer() {
		return loyer;
	}

	public void setLoyer(int loyer) {
		this.loyer = loyer;
	}

	public int getMontantLocationJournalier() {
		return montantLocationJournalier;
	}

	public void setMontantLocationJournalier(int montantLocationJournalier) {
		this.montantLocationJournalier = montantLocationJournalier;
	}

	public int getTranche_1() {
		return tranche_1;
	}

	public void setTranche_1(int tranche_1) {
		this.tranche_1 = tranche_1;
	}

	public int getTranche_2() {
		return tranche_2;
	}

	public void setTranche_2(int tranche_2) {
		this.tranche_2 = tranche_2;
	}

	public int getTranche_3() {
		return tranche_3;
	}

	public void setTranche_3(int tranche_3) {
		this.tranche_3 = tranche_3;
	}
	
	

}

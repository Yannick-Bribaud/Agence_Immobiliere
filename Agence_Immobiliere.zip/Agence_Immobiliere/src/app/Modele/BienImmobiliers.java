package app.Modele;

import java.util.Random;

public class BienImmobiliers {
	
	private int identifiantBien=0;
	private String adresseBien;
	private int nombrePieces;
	private int montant;
	private int loyer;
	private String detail;
	private String statut;
	
	
	public BienImmobiliers() {
	}
	
	public BienImmobiliers(String adresseBien, int nombrePieces, int montant, int loyer, String detail, String statut) {
		super();
		this.adresseBien = adresseBien;
		this.nombrePieces = nombrePieces;
		this.montant = montant;
		this.loyer = loyer;
		this.detail = detail;
		this.statut = statut;
		this.setIdentifiantBien(identifiantBien);
	}


	public int getIdentifiantBien() {
		return identifiantBien;
	}


	public void setIdentifiantBien(int identifiantBien) {
		
		if(identifiantBien !=0)
		{
			this.identifiantBien = identifiantBien;
		}
		else
		{
			//Generation Al�atoires de l'identifiant
		Random rand = new Random();
		int max = 700000;
		int min = 400000;		
		identifiantBien = rand.nextInt(max-min +1)+ min + rand.nextInt(700000-10000)+1*2 + rand.nextInt(9000-1)+3/4; 
		this.identifiantBien = identifiantBien;
		}
	}


	public String getAdresseBien() {
		return adresseBien;
	}


	public void setAdresseBien(String adresseBien) {
		this.adresseBien = adresseBien;
	}


	public int getNombrePieces() {
		return nombrePieces;
	}


	public void setNombrePieces(int nombrePieces) {
		this.nombrePieces = nombrePieces;
	}


	public int getMontant() {
		return montant;
	}


	public void setMontant(int montant) {
		this.montant = montant;
	}


	public int getLoyer() {
		return loyer;
	}


	public void setLoyer(int loyer) {
		this.loyer = loyer;
	}


	public String getDetail() {
		return detail;
	}


	public void setDetail(String detail) {
		this.detail = detail;
	}


	public String getStatut() {
		return statut;
	}


	public void setStatut(String statut) {
		this.statut = statut;
	}
	
	
	
	
	
	
	
	
	
	

}

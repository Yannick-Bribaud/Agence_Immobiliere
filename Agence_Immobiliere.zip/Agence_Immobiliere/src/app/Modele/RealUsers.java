package app.Modele;

import java.util.Random;

public class RealUsers extends Utilisateur {
	
	
		private int identifiant=0;
              
	
 public RealUsers(String nom, String prenom, String adresse, String numero_tel, String login, String motDepasse,
				String dateNaissance, String email,String statut) {
	 
			super(nom, prenom, adresse, numero_tel, login, motDepasse, dateNaissance, email,statut);
			this.setIdentifiant(identifiant);	
	}
 
 
 	public RealUsers(String motDepasse, String email) {
	super(motDepasse, email);
	
}
 	public RealUsers(String motDepasse, String email,String statut) {
 		super(motDepasse, email,statut);
 		
 		}
	

	public int getIdentifiant() {
		return identifiant;
	}


	public void setIdentifiant(int identifiant) {
		
		if(identifiant !=0)
		{
			this.identifiant = identifiant;
		}
		else
		{
			// Generation Al�atoires de l'identifiant
			Random rand = new Random();
			int max = 100000;
			int min = 1;
			
			identifiant = rand.nextInt(max-min +1)+ min + rand.nextInt(100000-100)+1*2 + rand.nextInt(1000-1)+3/3; 
			this.identifiant = identifiant;
		}
			
		
	}



	
	
}

package app.Modele;

import java.util.Random;

public class Locataire {
	
	private int identifiant_locataire=0;
	private String nom_Locataire;
	private String prenom_locataire;
	private String num_Pieces_Locataire;
	private String genre;
	private String date_naissance;
	private String num_telephone;
	private String adresse_mail;
	private String d_Location;
	
	
	public Locataire() {
		
	}
	
	

	public Locataire(String num_Pieces_Locataire) {
		super();
		this.num_Pieces_Locataire = num_Pieces_Locataire;
	}


	public Locataire(String nom_Locataire, String prenom_locataire, String d_Location) {
		super();
		this.nom_Locataire = nom_Locataire;
		this.prenom_locataire = prenom_locataire;
		this.d_Location = d_Location;
	}


	public Locataire(int identifiant_locataire, String nom_Locataire, String prenom_locataire, String d_Location) {
		super();
		this.identifiant_locataire = identifiant_locataire;
		this.nom_Locataire = nom_Locataire;
		this.prenom_locataire = prenom_locataire;
		this.d_Location = d_Location;
	}



	public Locataire(String nom_Locataire, String prenom_locataire, String num_Pieces_Locataire, String genre,
			String date_naissance, String num_telephone, String adresse_mail, String d_Location) {
		super();
		this.nom_Locataire = nom_Locataire;
		this.prenom_locataire = prenom_locataire;
		this.num_Pieces_Locataire = num_Pieces_Locataire;
		this.genre = genre;
		this.date_naissance = date_naissance;
		this.num_telephone = num_telephone;
		this.adresse_mail = adresse_mail;
		this.d_Location = d_Location;
		this.setIdentifiant_locataire(identifiant_locataire);
	}
	

	public Locataire(int identifiant_locataire, String nom_Locataire, String prenom_locataire,
			String num_Pieces_Locataire, String d_Location) {
		super();
		this.identifiant_locataire = identifiant_locataire;
		this.nom_Locataire = nom_Locataire;
		this.prenom_locataire = prenom_locataire;
		this.num_Pieces_Locataire = num_Pieces_Locataire;
		this.d_Location = d_Location;
		
	}



	public int getIdentifiant_locataire() {
		return identifiant_locataire;
	}

	public void setIdentifiant_locataire(int identifiant_locataire) {
		
		if(identifiant_locataire !=0)
		{
			this.identifiant_locataire = identifiant_locataire;
		}
		else
		{
			//Generation Al�atoires de l'identifiant
			Random rand = new Random();
			int max = 900000;
			int min = 750000;		
			identifiant_locataire = rand.nextInt(max-min +1)+ min + rand.nextInt(900000-30000)+1*2 + rand.nextInt(11000-1)+120/4; 
			this.identifiant_locataire = identifiant_locataire;
		}
		
	}

	public String getNom_Locataire() {
		return nom_Locataire;
	}

	public void setNom_Locataire(String nom_Locataire) {
		this.nom_Locataire = nom_Locataire;
	}

	public String getPrenom_locataire() {
		return prenom_locataire;
	}

	public void setPrenom_locataire(String prenom_locataire) {
		this.prenom_locataire = prenom_locataire;
	}

	public String getNum_Pieces_Locataire() {
		return num_Pieces_Locataire;
	}

	public void setNum_Pieces_Locataire(String num_Pieces_Locataire) {
		this.num_Pieces_Locataire = num_Pieces_Locataire;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getDate_naissance() {
		return date_naissance;
	}

	public void setDate_naissance(String date_naissance) {
		this.date_naissance = date_naissance;
	}

	public String getNum_telephone() {
		return num_telephone;
	}

	public void setNum_telephone(String num_telephone) {
		this.num_telephone = num_telephone;
	}

	public String getAdresse_mail() {
		return adresse_mail;
	}

	public void setAdresse_mail(String adresse_mail) {
		this.adresse_mail = adresse_mail;
	}

	public String getD_Location() {
		return d_Location;
	}

	public void setD_Location(String d_Location) {
		this.d_Location = d_Location;
	}
	
	
	
	

}

package app.interfaces.vue;

import javax.swing.JFrame;

import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import diu.swe.habib.JPanelSlider.JPanelSlider;
import java.awt.BorderLayout;
import javax.swing.JRadioButton;


public class Affectation extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	
	private JTextField textFieldNom;
	private JTextField textFieldPrenom;
	private JTextField NumPiecetextField;
	private JTextField EmailTextField;
	private JTextField NumTeltextField;
	private JCheckBox CheckBoxLongterm;
	private JComboBox<String> comboBoxImmobilier;
	private JComboBox<String> comboBoxJour;
	private JComboBox<String> comboBoxMois;
	private JComboBox<String> comboBoxAnnee;
	private JCheckBox checkBoxJournaliere;
	private JTextField AvancetextField;
	private JTextField CautiontextField;
	private JButton btnAffecter;
	private JRadioButton radioBtnHomme; 
	private JRadioButton radioBtnFemme;
	private JButton btnTerminer;
	
	
	public Affectation() {
		
		
		  CheckBoxLongterm = new JCheckBox("Location/Long Terme");
		  comboBoxImmobilier = new JComboBox<String>();
		  comboBoxImmobilier.setForeground(new Color(49, 54, 70));
		  comboBoxImmobilier.setBackground(Color.WHITE);
		  btnTerminer = new JButton("Terminer");
		  btnTerminer.setToolTipText("Fermer l'interface");
		  btnTerminer.setBackground(new Color(152, 16, 57));
		 
		  comboBoxJour = new JComboBox<String>();
		  comboBoxMois = new JComboBox<String>();
		  comboBoxAnnee = new JComboBox<String>();
		  checkBoxJournaliere = new JCheckBox("Location /Journali\u00E8re");
		  btnAffecter = new JButton("Affecter");
		 radioBtnHomme = new JRadioButton("Homme");
		 radioBtnHomme.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		if(radioBtnHomme.isSelected())
		 		{
		 			radioBtnFemme.setSelected(false);
		 		}
		 	}
		 });
		 radioBtnHomme.setBackground(new Color(49, 54, 70));
		 radioBtnFemme = new JRadioButton("Femme");
		 radioBtnFemme.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		
		 		if(radioBtnFemme.isSelected())
		 		{
		 			radioBtnHomme.setSelected(false);
		 		}
		 	}
		 });
		 radioBtnFemme.setBackground(new Color(49, 54, 70));
		 
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		getContentPane().setMinimumSize(new Dimension(850, 450));
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanelSlider panelSlider = new JPanelSlider();
		getContentPane().add(panelSlider);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(49, 54, 70));
		panelSlider.add(panel, "name_53352887760200");
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setHorizontalAlignment(SwingConstants.CENTER);
		lblNom.setForeground(Color.WHITE);
		lblNom.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNom.setBounds(18, 61, 65, 29);
		panel.add(lblNom);
		
		textFieldNom = new JTextField();
		textFieldNom.setFont(new Font("Rockwell", Font.PLAIN, 16));
		textFieldNom.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNom.setToolTipText("Entrez le nom du locataire");
		textFieldNom.setForeground(Color.WHITE);
		textFieldNom.setColumns(10);
		textFieldNom.setBorder(null);
		textFieldNom.setBackground(new Color(49, 54, 70));
		textFieldNom.setBounds(93, 61, 132, 21);
		panel.add(textFieldNom);
		
		JSeparator separator = new JSeparator();
		separator.setBorder(new LineBorder(Color.WHITE, 3));
		separator.setBounds(93, 81, 132, 2);
		panel.add(separator);
		
		JLabel LablPrenom = new JLabel("Pr\u00E9nom");
		LablPrenom.setHorizontalAlignment(SwingConstants.CENTER);
		LablPrenom.setForeground(Color.WHITE);
		LablPrenom.setFont(new Font("Rockwell", Font.BOLD, 15));
		LablPrenom.setBounds(18, 134, 65, 24);
		panel.add(LablPrenom);
		
		textFieldPrenom = new JTextField();
		textFieldPrenom.setFont(new Font("Rockwell", Font.PLAIN, 16));
		textFieldPrenom.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldPrenom.setToolTipText("Entrez le Prenom du Locataire");
		textFieldPrenom.setForeground(Color.WHITE);
		textFieldPrenom.setColumns(10);
		textFieldPrenom.setBorder(null);
		textFieldPrenom.setBackground(new Color(49, 54, 70));
		textFieldPrenom.setBounds(92, 135, 133, 20);
		panel.add(textFieldPrenom);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBorder(new LineBorder(Color.WHITE, 3));
		separator_1.setBounds(92, 158, 133, 1);
		panel.add(separator_1);
		
		JLabel LablNumPiece = new JLabel("N\u00B0Piece");
		LablNumPiece.setHorizontalAlignment(SwingConstants.CENTER);
		LablNumPiece.setForeground(Color.WHITE);
		LablNumPiece.setFont(new Font("Rockwell", Font.BOLD, 15));
		LablNumPiece.setBounds(18, 210, 65, 24);
		panel.add(LablNumPiece);
		
		NumPiecetextField = new JTextField();
		NumPiecetextField.setHorizontalAlignment(SwingConstants.CENTER);
		NumPiecetextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		NumPiecetextField.setToolTipText("Numero Piece d'identit\u00E9");
		NumPiecetextField.setForeground(Color.WHITE);
		NumPiecetextField.setColumns(10);
		NumPiecetextField.setBorder(null);
		NumPiecetextField.setBackground(new Color(49, 54, 70));
		NumPiecetextField.setBounds(93, 212, 132, 20);
		panel.add(NumPiecetextField);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBorder(new LineBorder(Color.WHITE, 3));
		separator_2.setBounds(93, 233, 132, 2);
		panel.add(separator_2);
		
		EmailTextField = new JTextField();
		EmailTextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		EmailTextField.setHorizontalAlignment(SwingConstants.CENTER);
		EmailTextField.setToolTipText("Entrez le mail du locataire");
		EmailTextField.setForeground(Color.WHITE);
		EmailTextField.setColumns(10);
		EmailTextField.setBorder(null);
		EmailTextField.setBackground(new Color(49, 54, 70));
		EmailTextField.setBounds(93, 283, 132, 20);
		panel.add(EmailTextField);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBorder(new LineBorder(Color.WHITE, 3));
		separator_3.setBounds(93, 304, 132, 2);
		panel.add(separator_3);
		
		JLabel NumeroTelph = new JLabel("Numero Tel");
		NumeroTelph.setHorizontalAlignment(SwingConstants.CENTER);
		NumeroTelph.setForeground(Color.WHITE);
		NumeroTelph.setFont(new Font("Rockwell", Font.BOLD, 15));
		NumeroTelph.setBounds(288, 61, 100, 29);
		panel.add(NumeroTelph);
		
		NumTeltextField = new JTextField();
		NumTeltextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		NumTeltextField.setHorizontalAlignment(SwingConstants.CENTER);
		NumTeltextField.setToolTipText("Numero T\u00E9l\u00E9phone");
		NumTeltextField.setForeground(Color.WHITE);
		NumTeltextField.setColumns(10);
		NumTeltextField.setBorder(null);
		NumTeltextField.setBackground(new Color(49, 54, 70));
		NumTeltextField.setBounds(405, 67, 128, 20);
		panel.add(NumTeltextField);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBorder(new LineBorder(Color.WHITE, 3));
		separator_4.setBounds(407, 88, 128, 2);
		panel.add(separator_4);
		
		JLabel lblJour = new JLabel("Date de Naissance");
		lblJour.setHorizontalAlignment(SwingConstants.CENTER);
		lblJour.setForeground(Color.WHITE);
		lblJour.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblJour.setBounds(311, 134, 318, 29);
		panel.add(lblJour);
		
		JLabel lblJour_1 = new JLabel("Jour");
		lblJour_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblJour_1.setForeground(Color.WHITE);
		lblJour_1.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblJour_1.setBounds(296, 189, 65, 24);
		panel.add(lblJour_1);
		
		
		comboBoxJour.setModel(new DefaultComboBoxModel<String>(new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		
		comboBoxJour.setFont(new Font("Rockwell", Font.BOLD, 13));
		comboBoxJour.setToolTipText("Jour de naissance");
		comboBoxJour.setBounds(358, 192, 57, 22);
		comboBoxJour.setForeground(new Color(49, 54, 70));
		panel.add(comboBoxJour);
		
		JLabel lblJour_1_1 = new JLabel("Mois");
		lblJour_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblJour_1_1.setForeground(Color.WHITE);
		lblJour_1_1.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblJour_1_1.setBounds(425, 189, 65, 29);
		panel.add(lblJour_1_1);
		
		
		comboBoxMois.setFont(new Font("Rockwell", Font.BOLD, 13));
		comboBoxMois.setModel(new DefaultComboBoxModel<String>(new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBoxMois.setToolTipText("Mois de naissance");
		comboBoxMois.setBounds(491, 192, 57, 22);
		comboBoxMois.setForeground(new Color(49, 54, 70));
		panel.add(comboBoxMois);
		
		JLabel lblJour_1_2 = new JLabel("Annee");
		lblJour_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblJour_1_2.setForeground(Color.WHITE);
		lblJour_1_2.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblJour_1_2.setBounds(563, 189, 65, 24);
		panel.add(lblJour_1_2);
		
		
		comboBoxAnnee.setModel(new DefaultComboBoxModel<>(new String[] {"2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", ""}));
		comboBoxAnnee.setFont(new Font("Rockwell", Font.BOLD, 13));
		comboBoxAnnee.setToolTipText("Ann\u00E9e de naissance");
		comboBoxAnnee.setBounds(630, 192, 65, 22);
		comboBoxAnnee.setForeground(new Color(49, 54, 70));
		panel.add(comboBoxAnnee);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail.setForeground(Color.WHITE);
		lblEmail.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblEmail.setBounds(18, 281, 65, 24);
		panel.add(lblEmail);
		
		
		
		CheckBoxLongterm.setToolTipText("Cliquer pour s\u00E9lectionner");
		CheckBoxLongterm.setHorizontalAlignment(SwingConstants.CENTER);
		CheckBoxLongterm.setForeground(Color.WHITE);
		CheckBoxLongterm.setFont(new Font("Rockwell", Font.BOLD, 15));
		CheckBoxLongterm.setEnabled(false);
		CheckBoxLongterm.setBackground(new Color(49, 54, 70));
		CheckBoxLongterm.setBounds(18, 346, 207, 23);
		panel.add(CheckBoxLongterm);
		
		
		checkBoxJournaliere.setToolTipText("Cliquer pour s\u00E9lectionner");
		checkBoxJournaliere.setHorizontalAlignment(SwingConstants.CENTER);
		checkBoxJournaliere.setForeground(Color.WHITE);
		checkBoxJournaliere.setFont(new Font("Rockwell", Font.BOLD, 15));
		checkBoxJournaliere.setEnabled(false);
		checkBoxJournaliere.setBackground(new Color(49, 54, 70));
		checkBoxJournaliere.setBounds(311, 345, 237, 25);
		panel.add(checkBoxJournaliere);
		
		JPanel panelHaut = new JPanel();
		panelHaut.setBackground(Color.WHITE);
		panelHaut.setBounds(0, 0, 846, 34);
		panel.add(panelHaut);
		
		JLabel lblAffectation = new JLabel("AFFECTATION");
		lblAffectation.setHorizontalAlignment(SwingConstants.CENTER);
		lblAffectation.setForeground(new Color(49, 54, 70));
		lblAffectation.setFont(new Font("Rockwell", Font.BOLD, 20));
		panelHaut.add(lblAffectation);
		
		JLabel lblImmobilier = new JLabel("Selection Immobilier");
		lblImmobilier.setHorizontalAlignment(SwingConstants.CENTER);
		lblImmobilier.setForeground(Color.WHITE);
		lblImmobilier.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblImmobilier.setBounds(573, 60, 252, 21);
		panel.add(lblImmobilier);
		
		
		comboBoxImmobilier.setModel(new DefaultComboBoxModel<String>(new String[] {"                     ---S\u00E9lectionner---"}));
		comboBoxImmobilier.setToolTipText("Selectionner un bien Immobilier");
		comboBoxImmobilier.setFont(new Font("Rockwell", Font.BOLD, 13));
		comboBoxImmobilier.setBounds(577, 84, 252, 22);
		panel.add(comboBoxImmobilier);
		
		
		
		btnAffecter.setToolTipText("Cliquer pour Affecter");
		btnAffecter.setForeground(Color.WHITE);
		btnAffecter.setFont(new Font("Rockwell", Font.BOLD, 15));
		btnAffecter.setEnabled(false);
		btnAffecter.setBackground(new Color(152, 16, 57));
		btnAffecter.setBounds(620, 255, 100, 100);
		panel.add(btnAffecter);
		
		
		radioBtnHomme.setHorizontalAlignment(SwingConstants.CENTER);
		radioBtnHomme.setFont(new Font("Rockwell", Font.BOLD, 16));
		radioBtnHomme.setForeground(Color.WHITE);
		radioBtnHomme.setBounds(335, 242, 155, 25);
		panel.add(radioBtnHomme);
		
		
		radioBtnFemme.setForeground(Color.WHITE);
		radioBtnFemme.setFont(new Font("Rockwell", Font.BOLD, 16));
		radioBtnFemme.setHorizontalAlignment(SwingConstants.CENTER);
		radioBtnFemme.setBounds(335, 286, 155, 25);
		panel.add(radioBtnFemme);
		
		
		btnTerminer.setForeground(Color.WHITE);
		btnTerminer.setFont(new Font("Rockwell", Font.PLAIN, 12));
		btnTerminer.setBounds(759, 337, 74, 74);
		panel.add(btnTerminer);
		
		JPanel panelPaiement = new JPanel();
		panelSlider.add(panelPaiement, "name_76399627774100");
		panelPaiement.setBackground(new Color(49, 54, 70));
		panelPaiement.setLayout(null);
		
		JPanel panelAudessuPaiement = new JPanel();
		panelAudessuPaiement.setBackground(Color.WHITE);
		panelAudessuPaiement.setFont(new Font("Rockwell", Font.BOLD, 22));
		panelAudessuPaiement.setBounds(0, 0, 842, 43);
		panelPaiement.add(panelAudessuPaiement);
		panelAudessuPaiement.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("Paiement");
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panelAudessuPaiement.add(lblNewLabel, BorderLayout.CENTER);
		
		JPanel panelPaiementAvcAvance = new JPanel();
		panelPaiementAvcAvance.setBorder(null);
		panelPaiementAvcAvance.setBackground(Color.DARK_GRAY);
		panelPaiementAvcAvance.setBounds(32, 78, 333, 279);
		panelPaiement.add(panelPaiementAvcAvance);
		panelPaiementAvcAvance.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Avance");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(9, 61, 68, 24);
		panelPaiementAvcAvance.add(lblNewLabel_1);
		
		AvancetextField = new JTextField();
		AvancetextField.setForeground(Color.WHITE);
		AvancetextField.setBorder(null);
		AvancetextField.setBackground(Color.DARK_GRAY);
		AvancetextField.setBounds(87, 65, 183, 20);
		panelPaiementAvcAvance.add(AvancetextField);
		AvancetextField.setColumns(10);
		
		JSeparator separator_6 = new JSeparator();
		separator_6.setBorder(new LineBorder(Color.WHITE, 3));
		separator_6.setBounds(87, 87, 182, 2);
		panelPaiementAvcAvance.add(separator_6);
		
		JLabel lblNewLabel_2 = new JLabel("Caution");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_2.setBounds(10, 153, 78, 24);
		panelPaiementAvcAvance.add(lblNewLabel_2);
		
		CautiontextField = new JTextField();
		CautiontextField.setFont(new Font("Rockwell", Font.BOLD, 14));
		CautiontextField.setForeground(Color.WHITE);
		CautiontextField.setColumns(10);
		CautiontextField.setBorder(null);
		CautiontextField.setBackground(Color.DARK_GRAY);
		CautiontextField.setBounds(87, 154, 183, 20);
		panelPaiementAvcAvance.add(CautiontextField);
		
		JSeparator separator_6_1 = new JSeparator();
		separator_6_1.setBorder(new LineBorder(Color.WHITE, 3));
		separator_6_1.setBounds(88, 175, 182, 2);
		panelPaiementAvcAvance.add(separator_6_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 333, 30);
		panelPaiementAvcAvance.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_3 = new JLabel("Long Terme");
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 17));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_3);
		setMinimumSize(new Dimension(850, 450));
		setSize(new Dimension(850, 450));
		
		CheckBoxLongterm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(CheckBoxLongterm.isSelected())
				{
					checkBoxJournaliere.setSelected(false);
					checkBoxJournaliere.setEnabled(false);
					btnAffecter.setEnabled(true);
					
				}
				else {
					checkBoxJournaliere.setEnabled(true);
					btnAffecter.setEnabled(false);
				}
			}
		});
		
		checkBoxJournaliere.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent e) {
			  		
			  		if(checkBoxJournaliere.isSelected())
			  		{
			  			CheckBoxLongterm.setSelected(false);
			  			CheckBoxLongterm.setEnabled(false);
						btnAffecter.setEnabled(true);
			  		}
			  		else
			  		{
			  			CheckBoxLongterm.setEnabled(true);
						btnAffecter.setEnabled(false);
			  		}
			  	}
			  });
		 
		 
		
		
		this.setLocationRelativeTo(null);
		setVisible(true);
	}


	public String getTextFieldNom() {
		
		String value = textFieldNom.getText();
		return value;
	}

	public void setTextFieldNom(JTextField textFieldNom) {
		this.textFieldNom = textFieldNom;
	} 

	public String getTextFieldPrenom() {
		
		String value = textFieldPrenom.getText();
		return value;
	}

	public void setTextFieldPrenom(JTextField textFieldPrenom) {
		this.textFieldPrenom = textFieldPrenom;
	} 

	public String getNumPiecetextField() {
		
		String value = NumPiecetextField.getText();
		return value;
	}

	public void setNumPiecetextField(JTextField numPiecetextField) {
		NumPiecetextField = numPiecetextField;
	} 

	public String getEmailTextField() {
		
		String value = EmailTextField.getText();
		return value;
	}


	public void setEmailTextField(JTextField emailTextField) {
		EmailTextField = emailTextField;
	}


	public JRadioButton getRadioBtnHomme() {
	  
	  return radioBtnHomme;
	  
	}

	public void setRadioBtnHomme(JRadioButton radioBtnHomme) {
		this.radioBtnHomme = radioBtnHomme;
	}

	public JRadioButton getRadioBtnFemme() {
		  
		  return radioBtnFemme;
	} 


	public void setRadioBtnFemme(JRadioButton radioBtnFemme) {
		this.radioBtnFemme = radioBtnFemme;
	} 
	public String getNumTeltextField() {
		
		String value = NumTeltextField.getText();
		return value;
	}

	public void setNumTeltextField(JTextField numTeltextField) {
		NumTeltextField = numTeltextField;
	}

	public JCheckBox getCheckBoxLongterm() {
		
		return CheckBoxLongterm;
		
	} 

	public void setCheckBoxLongterm(JCheckBox checkBoxLongterm) {
		
		CheckBoxLongterm = checkBoxLongterm;
	}

	public JComboBox <String> getComboBoxImmobilier() {
		
		return comboBoxImmobilier;
	}

	public void setComboBoxImmobilier(JComboBox<String> comboBoxImmobilier) {
		this.comboBoxImmobilier = comboBoxImmobilier;
	}

	public String getComboBoxJour() {
		
		String value = comboBoxJour.getSelectedItem().toString();
		return value;
	}

	public void setComboBoxJour(JComboBox<String> comboBoxJour) {
		this.comboBoxJour = comboBoxJour;
	}

	public String getComboBoxMois() {
		
		String value = comboBoxMois.getSelectedItem().toString();
		return value;
	}

	public void setComboBoxMois(JComboBox<String> comboBoxMois) {
		this.comboBoxMois = comboBoxMois;
	}

	public String getComboBoxAnnee() {
		String value = comboBoxAnnee.getSelectedItem().toString();
		return value;
	}
	
	public void setComboBoxAnnee(JComboBox<String>comboBoxAnnee) {
		this.comboBoxAnnee = comboBoxAnnee;
	}

	public JCheckBox getCheckBoxJournaliere() {
		
		return checkBoxJournaliere;
	}

	public void setCheckBoxJournaliere(JCheckBox checkBoxJournaliere) {
		this.checkBoxJournaliere = checkBoxJournaliere;
	}

	public String getTextField() {
		
		String value = AvancetextField.getText();
		
		return value;
	}

	public void setTextField(JTextField textField) {
		this.AvancetextField = textField;
	}

	public String getTextField_1() {
		
		String value = CautiontextField.getText();
		return value;
	}

	public void setTextField_1(JTextField textField_1) {
		this.CautiontextField = textField_1;
	}

	public JButton getBtnAffecter() {
		return btnAffecter;
	}

	public void setBtnAffecter(JButton btnAffecter) {
		this.btnAffecter = btnAffecter;
	}
	
	public void run()
	{
		this.setVisible(true);
	}
	
	public void addEcouteurbtnAffecter(ActionListener actionListener) {
		btnAffecter.addActionListener(actionListener);
	}
	public void ErrorMessage(String message) {
		
	JOptionPane.showMessageDialog(null, message,"ERREUR!!!"
		,JOptionPane.ERROR_MESSAGE);		
	}
	public void MessageResultat() {
		
		JOptionPane.showMessageDialog(null, "Aucune correspondance","ERREUR RECHERCHE"
				,JOptionPane.ERROR_MESSAGE);		
	}
	public void addEcouteurSelectionCombox(ItemListener itemListener) {
		comboBoxImmobilier.addItemListener(itemListener);			
	}
	public void Reset() {
		comboBoxImmobilier.setSelectedIndex(0);
		btnAffecter.setEnabled(false);	
	}

	public void MessageExceptionAffectation(String message) {
		JOptionPane.showMessageDialog(null, message, "ERREUR D'AFFECTATION"
				,JOptionPane.ERROR_MESSAGE);		
	}
	
	public void MessageErreurChamps(String message) {
		JOptionPane.showMessageDialog(null, message, "Champs vide/Non renseign�"
				,JOptionPane.ERROR_MESSAGE);	
	}

	public void MessageConnexion(String message) {
		JOptionPane.showMessageDialog(null, message,"ComboConnexion"
				,JOptionPane.ERROR_MESSAGE);	
	}

	public void succesAffectation() {
		JOptionPane.showMessageDialog(null, "Affectation Reussie", "AFFECTATION"
				,JOptionPane.INFORMATION_MESSAGE);	
	}


	public void Clear() {
		
		textFieldNom.setText(""); 
		textFieldPrenom.setText(""); 
		NumPiecetextField.setText(""); 
		EmailTextField.setText("");
		radioBtnHomme.setSelected(false);
		radioBtnFemme.setSelected(false); 
		NumTeltextField.setText(""); 
		comboBoxImmobilier.setSelectedIndex(0);
		comboBoxJour.setSelectedIndex(0);
		comboBoxMois.setSelectedIndex(0);
		comboBoxAnnee.setSelectedIndex(0);
		btnAffecter.setEnabled(false);
			
	}


	public void EcouteurBtnTerminer(ActionListener actionListener) {
		btnTerminer.addActionListener(actionListener);
		
	}
}

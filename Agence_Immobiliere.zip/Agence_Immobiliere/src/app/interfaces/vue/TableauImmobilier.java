package app.interfaces.vue;

import javax.swing.JPanel;


import java.awt.BorderLayout;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class TableauImmobilier extends JPanel {
	
	
	private static final long serialVersionUID = 1L;
	private JTable tableImmobilier;
	
	
	
	public TableauImmobilier() {
			
		
		setLayout(new BorderLayout(0, 0));
		this.setBackground(SystemColor.controlShadow);
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane, BorderLayout.CENTER);
		
		tableImmobilier = new JTable();
		tableImmobilier.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Identifiant", "Adresse Immobilier", "Nombre Pieces", "Montant", "Loyer", "Details", "Statut"
			}
		) {
			
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(tableImmobilier);
		
	}




	public JTable getTableImmobilier() {
		return tableImmobilier;
	}


	public void setTableImmobilier(JTable tableImmobilier) {
		this.tableImmobilier = tableImmobilier;
	}

	

	


	
	
	

	
	

}

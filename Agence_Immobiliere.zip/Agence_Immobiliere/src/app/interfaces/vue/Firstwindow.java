package app.interfaces.vue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import app.Controleur.ControleurWindow;
import app.Modele.RealUsers;

import java.awt.Color;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import diu.swe.habib.JPanelSlider.JPanelSlider;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;

public class Firstwindow extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JProgressBar progressBar;
	private JProgressBar progressBar_1;
	private JProgressBar progressBar_2;
	private JProgressBar progressBar_3;
	        MThread Prgbar;
	        ralentie Jslider;
	        private JPanel panel_6;
	        private JLabel LabelIcone;
	        private JLabel LibelleApp;
	       
	
	
	public Firstwindow () {
		setForeground(Color.WHITE);
		
		
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\LogoRdim.png"));
		// instanciation des Threads
		
		Jslider = new ralentie();
		Prgbar = new MThread( progressBar, progressBar_1, progressBar_2, progressBar_3);
		
		// Redimensionnement du containeur
		getContentPane().setMinimumSize(new Dimension(796, 447));
		getContentPane().setPreferredSize(new Dimension(796, 447));
		
		
		getContentPane().setBackground(Color.WHITE);
		setBackground(Color.BLACK);
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(799, 474);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		getContentPane().setSize(796, 447);
		getContentPane().setLayout(null);
		
		
		panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(0, 0, 0), new Color(0, 0, 0), new Color(0, 0, 0), new Color(0, 0, 0)));
		panel.setBounds(0, 0, 796, 447);
		panel.setSize(796, 447);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		
		panel_1 = new JPanel();
		panel_1.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK));
		panel_1.setBounds(69, 0, 727, 70);
		panel_1.setSize(727, 70);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
	
		
		progressBar = new JProgressBar();
		progressBar.setBounds(-26, -18, 768, 88);
		progressBar.setSize(768, 88);
		progressBar.setBackground(new Color(26, 26, 26));
		progressBar.setForeground(new Color(4, 26, 76));
		panel_1.add(progressBar);
		
		panel_2 = new JPanel();
		panel_2.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0), new Color(0, 0, 0), new Color(0, 0, 0)));
		panel_2.setBounds(0, 0, 71, 358);
		panel_2.setSize(71,358);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		progressBar_1 = new JProgressBar();
		progressBar_1.setBackground(new Color(26, 26, 26));
		progressBar_1.setForeground(new Color(4, 26, 76));//33, 61, 107
		progressBar_1.setBounds(-15, -16, 98, 399);
		progressBar_1.setOrientation(SwingConstants.VERTICAL);
		progressBar_1.setSize(98, 399);
		panel_2.add(progressBar_1);
		
		panel_3 = new JPanel();
		panel_3.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK));
		panel_3.setBounds(-2, 358, 650, 90);
		panel_3.setSize(650, 90);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		progressBar_2 = new JProgressBar();
		progressBar_2.setBounds(-16, -11, 684, 101);
		progressBar_2.setBackground(new Color(33, 61, 107));
		progressBar_2.setForeground(new Color(26, 26, 26));
		progressBar_2.setSize(684, 101);
		panel_3.add(progressBar_2);
		
	    panel_4 = new JPanel();
	    panel_4.setBackground(Color.WHITE);
		panel_4.setBounds(648, 70, 149, 380);
		panel_4.setSize(149, 385);
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		progressBar_3 = new JProgressBar();
		progressBar_3.setBackground(new Color(33, 61, 107));
		progressBar_3.setForeground(new Color(26, 26, 26));
		progressBar_3.setOrientation(SwingConstants.VERTICAL);
		progressBar_3.setBounds(-13, -12, 170, 395);
		panel_4.add(progressBar_3);
		
		
		JPanelSlider panelSlider = new JPanelSlider();
		panelSlider.setBounds(116, 102, 492, 225);
		panel.add(panelSlider);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(16, 18, 42));  
		panel_5.setForeground(new Color(16, 18, 42)); 
		panelSlider.add(panel_5, "Pane5");
		panel_5.setLayout(null);
		
		JLabel LabelGif = new JLabel("");
		LabelGif.setSize(new Dimension(488, 222));
		LabelGif.setForeground(Color.WHITE);
		LabelGif.setLocation(0, 0);
		LabelGif.setSize(488, 222);
		LabelGif.setHorizontalAlignment(SwingConstants.CENTER);
		LabelGif.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\PageAcInter.gif"));
		
		panel_5.add(LabelGif);
		this.pack();
		LabelGif.setLocation(0, -2);
		
		panel_6 = new JPanel();
		panel_6.setBackground(Color.WHITE);
		panel_6.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE));
		panelSlider.add(panel_6, "Pane6");
		panel_6.setLayout(null);
		
		LabelIcone = new JLabel("");
		LabelIcone.setBackground(Color.WHITE);
		
		
		ImageIcon icon = new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\LogoRdim.png");
		Image img = icon.getImage();
		Image dimImg= img.getScaledInstance(160, 160, Image.SCALE_SMOOTH);
		ImageIcon RedimImg = new ImageIcon(dimImg);
		LabelIcone.setIcon(RedimImg);
		LabelIcone.setHorizontalAlignment(SwingConstants.CENTER);
		LabelIcone.setBounds(155, 56, 160, 160);
		panel_6.add(LabelIcone);
		
		LibelleApp = new JLabel("");
		LibelleApp.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		LibelleApp.setBackground(Color.WHITE);
		LibelleApp.setHorizontalAlignment(SwingConstants.CENTER);
		LibelleApp.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\Lib.PNG"));
		LibelleApp.setBounds(0, 0, 489, 44);
		panel_6.add(LibelleApp);
		
		panel.setBackground(new Color(152, 16, 57));
		
		setVisible(true);
		
			Jslider.start();
			try {
				Jslider.join();
			} catch (InterruptedException e1) {
				
				e1.printStackTrace();
			}
			
			
		panelSlider.nextPanel(95, panel_6, JPanelSlider.right);
		
			this.pack();
			LibelleApp.setBounds(0, 0, 489, 45);
		
		
	
		Prgbar.start();
		
		try {
			Prgbar.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		
		RealUsers user = new RealUsers("","");
		Window vueWindows = new Window();
		ControleurWindow f = new ControleurWindow(user,vueWindows);
		f.run();
		
		this.dispose();
		
	}
	
	
	
	
	//Mes Threads de Gestion 
	
	class ralentie extends Thread{
		
		ralentie(){
			
		}
		
		@Override
		  public void run() {
			
			try {
				sleep(4000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		
		
	}
	
		
	
	class MThread extends Thread{
		
	  JProgressBar progBar;
	  JProgressBar progrBar_1;
	  JProgressBar progrBar_2;
	  JProgressBar progBar_3;
	  
	    MThread (JProgressBar progBar,JProgressBar progrBar_1,JProgressBar progrBar_2,JProgressBar progBar_3) {
		  
		  progBar = progressBar;
		  progrBar_1=progressBar_1;
		  progrBar_2 =progressBar_2;
		  progBar_3=progressBar_3;
	  }
	    
	  
	  @Override
	  public void run() {
		  
		  int min_1=30; int min_2=24;
		  int min_3=25; int min_4=32;
		  int max=100;
		  
		  progressBar.setValue(min_1);
		  progressBar_1.setValue(min_2);
		  progressBar_2.setValue(min_3);
		  progressBar_3.setValue(min_4);
		  
		  for(int i=3; i<max; i++)
		  {
			  progressBar.setValue(min_1++);
			  progressBar_1.setValue(min_2++);
			  progressBar_2.setValue(min_3++);
			  progressBar_3.setValue(min_4++);
			  
			  try {
				  
				sleep(60);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			  
		  } 
		    
		  
	  }
		
		
	}
}

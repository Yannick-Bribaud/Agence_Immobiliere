package app.interfaces.vue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;

public class OptionGestionLocat extends JFrame {
	
	private JButton btnModifierLocat;
	private JButton btnSupprimerLocat;
	
	private static final long serialVersionUID = 1L;
	
	public OptionGestionLocat() {
		getContentPane().setMinimumSize(new Dimension(300, 150));
		getContentPane().setBackground(Color.WHITE);
		setMinimumSize(new Dimension(300, 140));
		
		this.setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 btnModifierLocat = new JButton("Modifier Locataire");
		 btnSupprimerLocat= new JButton("Supprimer Locataire");
		
		JPanel panel = new JPanel();
		panel.setSize(new Dimension(300, 150));
		panel.setMinimumSize(new Dimension(0, 0));
		panel.setBackground(new Color(49, 54, 70));
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		btnModifierLocat.setBackground(new Color(4, 26, 76));
		btnModifierLocat.setForeground(Color.white);
		btnModifierLocat.setFont(new Font("Rockwell", Font.BOLD, 16));
		btnModifierLocat.setBounds(25, 10, 240, 42);
		panel.add(btnModifierLocat);
		
		
		btnSupprimerLocat.setFont(new Font("Rockwell", Font.BOLD, 16));
		btnSupprimerLocat.setForeground(Color.WHITE);
		btnSupprimerLocat.setBackground(new Color(4, 26, 76));
		btnSupprimerLocat.setBounds(25, 62, 240, 38);
		panel.add(btnSupprimerLocat);
	}
	
	
	public void run()
	{
		this.setVisible(true);
	}
	
	public JButton getBtnModifierLocat() {
		return btnModifierLocat;
	}

	public void setBtnModifierLocat(JButton btnModifierLocat) {
		this.btnModifierLocat = btnModifierLocat;
	}

	public JButton getBtnSupprimerLocat() {
		return btnSupprimerLocat;
	}

	public void setBtnSupprimerLocat(JButton btnSupprimerLocat) {
		this.btnSupprimerLocat = btnSupprimerLocat;
	}


	public void addEcouteurBtnModifier(ActionListener actionListener) {
		btnModifierLocat.addActionListener(actionListener);
		
	}


	public void MessageEX(String message) {
		JOptionPane.showMessageDialog(null, message,"Suppression Locataire"
				,JOptionPane.ERROR_MESSAGE);
		
	}


	public void addEcouteurBtnSupprimer(ActionListener actionListener) {
		btnSupprimerLocat.addActionListener(actionListener);
		
	}


	public void MessageReusste() {
		JOptionPane.showMessageDialog(null, " Suppression Effectu�e ","Suppression Locataire"
				,JOptionPane.INFORMATION_MESSAGE);
	}


	public void MessageReussite() {
		JOptionPane.showMessageDialog(null, " Mis A jour Effectu�e ","Mis A Jour"
				,JOptionPane.INFORMATION_MESSAGE);
		
		
	}
	
	
	
	
}

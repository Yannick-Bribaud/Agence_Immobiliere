package app.interfaces.vue;

import javax.swing.JFrame;


import java.awt.Dimension;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import diu.swe.habib.JPanelSlider.JPanelSlider;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class PaiementInterface extends JFrame {

	private JPanelSlider panelSlider;
	private JPanel panelChoix;
	private JPanel panelAffichePaiement;
	private static final long serialVersionUID = 1L;
	private JPanel panel;
	private JRadioButton radiobtnNvoPaiement;
	private JTextField NumPiecesField;
	private JButton btnRechercher;
	private JRadioButton rdioBtnAjoutPaiement;
	private JPanel panelAcceuil;
	private JPanel panelPaiement_LongTerme;
	private JPanelSlider panelSliderPaiementField;
	private JPanel panelCaution;
	private JTextField textFieldCaution;
	private JTextField textFieldMensualit�;
	private JButton btnPayer;
	private JPanel panelJournaliere_tranche;
	private JTextField textFieldMontant_Journalier;
	private JLabel lblNewLabel_3;
	private JTextField tranche_1_Field;
	private JLabel lblNewLabel_4;
	private JTextField tranche_2_Field;
	private JLabel lblNewLabel_5;
	private JTextField tranche_3_Field;
	private JLabel lblNewLabel_6;
	private JSeparator separator_3;
	private JSeparator separator_4;
	private JSeparator separator_5;
	private JSeparator separator_6;
	private JButton btnPayerJournalier;
	private JLabel LabelAfficheNom;
	private JLabel lblNewLabel_8;
	private JLabel lblLabelPrenom;
	private JLabel labelAffichePrenom;
	private JLabel lblNewLabel_9;
	private JLabel LabelContrat;
	private JLabel lblNewLabel_10;
	private JLabel LabelAfficheDetails;
	private JLabel lblNewLabel_11;
	private JLabel labelAfficheMontant;
	private JLabel labelLoyer;
	private JLabel labelAfficheLoyer;
	private JLabel lblNewLabel_12;
	private JLabel LabelAfficheNbrePieces;
	private JButton BtnTerminer;

	public PaiementInterface() {
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setMinimumSize(new Dimension(600, 360));
		getContentPane().setSize(new Dimension(500, 400));
		getContentPane().setMinimumSize(new Dimension(500, 400));
		btnPayerJournalier = new JButton("Payer");
		btnPayerJournalier.setVisible(false);
		btnPayerJournalier.setForeground(Color.WHITE);
		panelAcceuil = new JPanel();
		panelAcceuil.setBorder(null);
		panelAcceuil.setBackground(new Color(49, 54, 70));
		panelCaution = new JPanel();
		panelCaution.setBackground(new Color(49, 54, 70));
		btnPayer = new JButton("Payer");
		btnPayer.setForeground(Color.WHITE);
		btnPayer.setBackground(new Color(152, 16, 57));
		panelJournaliere_tranche = new JPanel();
		panelJournaliere_tranche.setBackground(new Color(49, 54, 70));
		panelAffichePaiement = new JPanel();
		BtnTerminer = new JButton("Terminer");
		BtnTerminer.setBorderPainted(false);
		BtnTerminer.setBackground(new Color(152, 16, 57));

		panelSlider = new JPanelSlider();
		panelSliderPaiementField = new JPanelSlider();
		panelPaiement_LongTerme = new JPanel();
		panelPaiement_LongTerme.setBackground(new Color(49, 54, 70));
		getContentPane().add(panelSlider, BorderLayout.CENTER);

		panelChoix = new JPanel();
		panelChoix.setBackground(Color.BLACK);
		panelSlider.add(panelChoix, "name_316552099193300");
		panelChoix.setLayout(null);

		panelAffichePaiement.setBackground(Color.WHITE);
		panelAffichePaiement.setBounds(-6, 0, 609, 35);
		panelChoix.add(panelAffichePaiement);
		rdioBtnAjoutPaiement = new JRadioButton("Ajout Paiement");
		
		rdioBtnAjoutPaiement.setForeground(Color.WHITE);
		radiobtnNvoPaiement = new JRadioButton("Nouveau Paiement");
		
		radiobtnNvoPaiement.setBackground(new Color(49, 54, 70));
		rdioBtnAjoutPaiement.setBackground(new Color(49, 54, 70));

		JLabel lblNewLabel = new JLabel("PAIEMENT");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 22));
		lblNewLabel.setForeground(new Color(49, 54, 70));
		panelAffichePaiement.add(lblNewLabel);

		panel = new JPanel();
		panel.setBackground(new Color(49, 54, 70));
		panel.setBounds(0, 35, 340, 290);
		panelChoix.add(panel);
		panel.setLayout(null);
		btnRechercher = new JButton("");

		radiobtnNvoPaiement.setForeground(Color.WHITE);
		radiobtnNvoPaiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		radiobtnNvoPaiement.setHorizontalAlignment(SwingConstants.CENTER);
		radiobtnNvoPaiement.setBounds(0, 4, 173, 20);

		panel.add(radiobtnNvoPaiement);

		rdioBtnAjoutPaiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		rdioBtnAjoutPaiement.setHorizontalAlignment(SwingConstants.CENTER);
		rdioBtnAjoutPaiement.setBounds(180, 4, 155, 20);
		panel.add(rdioBtnAjoutPaiement);

		NumPiecesField = new JTextField();
		NumPiecesField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				if(NumPiecesField.getText().length()<=0 ||NumPiecesField.getText().length()<5 )
				{
					panelSliderPaiementField.nextPanel(1, panelAcceuil, JPanelSlider.left);
				}
			}
		});
		
		NumPiecesField.setSelectedTextColor(Color.DARK_GRAY);
		NumPiecesField.setToolTipText("num\u00E9ro de la piece d'identit\u00E9");
		NumPiecesField.setForeground(Color.WHITE);
		NumPiecesField.setHorizontalAlignment(SwingConstants.CENTER);
		NumPiecesField.setFont(new Font("Rockwell", Font.BOLD, 14));
		NumPiecesField.setBorder(null);
		NumPiecesField.setBounds(107, 34, 150, 20);
		NumPiecesField.setBackground(new Color(49, 54, 70));
		panel.add(NumPiecesField);
		NumPiecesField.setColumns(10);

		btnRechercher.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\search_32px.png"));
		btnRechercher.setBorderPainted(false);
		btnRechercher.setBackground(Color.WHITE);
		btnRechercher.setBounds(278, 34, 42, 25);
		panel.add(btnRechercher);

		JSeparator separator = new JSeparator();
		separator.setBorder(new LineBorder(Color.WHITE, 3, true));
		separator.setBounds(103, 57, 158, 2);
		panel.add(separator);

		panelSliderPaiementField.setBorder(null);
		panelSliderPaiementField.setBounds(-1, 70, 341, 220);
		panel.add(panelSliderPaiementField);

		panelSliderPaiementField.add(panelAcceuil, "name_2416104222700");
		panelAcceuil.setLayout(null);
		
		
		BtnTerminer.setForeground(Color.WHITE);
		BtnTerminer.setFont(new Font("Rockwell", Font.BOLD, 14));
		BtnTerminer.setBounds(5, 199, 115, 20);
		panelAcceuil.add(BtnTerminer);

		panelSliderPaiementField.add(panelPaiement_LongTerme, "name_2879828709200");
		panelPaiement_LongTerme.setLayout(null);

		panelCaution.setBounds(0, 15, 341, 47);
		panelPaiement_LongTerme.add(panelCaution);
		panelCaution.setLayout(null);

		textFieldCaution = new JTextField();
		textFieldCaution.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldCaution.setForeground(Color.WHITE);
		textFieldCaution.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldCaution.setBorder(null);
		textFieldCaution.setBounds(133, 11, 140, 20);
		textFieldCaution.setBackground(new Color(49, 54, 70));
		panelCaution.add(textFieldCaution);
		textFieldCaution.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Caution");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(49, 12, 81, 20);
		panelCaution.add(lblNewLabel_1);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBorder(new LineBorder(Color.WHITE, 3));
		separator_1.setBounds(133, 34, 140, 2);
		panelCaution.add(separator_1);

		textFieldMensualit� = new JTextField();
		textFieldMensualit�.setForeground(Color.WHITE);
		textFieldMensualit�.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldMensualit�.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldMensualit�.setBorder(null);
		textFieldMensualit�.setBounds(133, 68, 140, 27);
		textFieldMensualit�.setBackground(new Color(49, 54, 70));
		panelPaiement_LongTerme.add(textFieldMensualit�);
		textFieldMensualit�.setColumns(10);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBorder(new LineBorder(Color.WHITE, 3));
		separator_2.setBounds(133, 97, 140, 2);
		panelPaiement_LongTerme.add(separator_2);

		JLabel lblNewLabel_2 = new JLabel("Mensualit\u00E9");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(34, 71, 97, 20);
		panelPaiement_LongTerme.add(lblNewLabel_2);

		btnPayer.setFont(new Font("Rockwell", Font.BOLD, 18));
		btnPayer.setBounds(134, 152, 122, 25);
		panelPaiement_LongTerme.add(btnPayer);

		panelSliderPaiementField.add(panelJournaliere_tranche, "name_7008035863400");
		panelJournaliere_tranche.setLayout(null);

		textFieldMontant_Journalier = new JTextField();
		textFieldMontant_Journalier.setForeground(Color.WHITE);
		textFieldMontant_Journalier.setBorder(null);
		textFieldMontant_Journalier.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldMontant_Journalier.setFont(new Font("Rockwell", Font.PLAIN, 14));
		textFieldMontant_Journalier.setBounds(176, 32, 120, 20);
		textFieldMontant_Journalier.setBackground(new Color(49, 54, 70));
		panelJournaliere_tranche.add(textFieldMontant_Journalier);
		textFieldMontant_Journalier.setColumns(10);

		lblNewLabel_3 = new JLabel("Montant Journalier");
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(15, 32, 148, 20);
		panelJournaliere_tranche.add(lblNewLabel_3);

		tranche_1_Field = new JTextField();
		tranche_1_Field.setForeground(Color.WHITE);
		tranche_1_Field.setHorizontalAlignment(SwingConstants.CENTER);
		tranche_1_Field.setFont(new Font("Rockwell", Font.PLAIN, 14));
		tranche_1_Field.setBorder(null);
		tranche_1_Field.setBounds(176, 59, 120, 20);
		tranche_1_Field.setBackground(new Color(49, 54, 70));
		panelJournaliere_tranche.add(tranche_1_Field);
		tranche_1_Field.setColumns(10);

		lblNewLabel_4 = new JLabel("Tranche n\u00B01");
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 59, 163, 26);
		panelJournaliere_tranche.add(lblNewLabel_4);

		tranche_2_Field = new JTextField();
		tranche_2_Field.setForeground(Color.WHITE);
		tranche_2_Field.setFont(new Font("Rockwell", Font.PLAIN, 14));
		tranche_2_Field.setHorizontalAlignment(SwingConstants.CENTER);
		tranche_2_Field.setBorder(null);
		tranche_2_Field.setBounds(175, 96, 120, 20);
		tranche_2_Field.setBackground(new Color(49, 54, 70));
		panelJournaliere_tranche.add(tranche_2_Field);
		tranche_2_Field.setColumns(10);

		lblNewLabel_5 = new JLabel("Tranche n\u00B02");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNewLabel_5.setBounds(0, 95, 163, 25);
		panelJournaliere_tranche.add(lblNewLabel_5);

		tranche_3_Field = new JTextField();
		tranche_3_Field.setForeground(Color.WHITE);
		tranche_3_Field.setHorizontalAlignment(SwingConstants.CENTER);
		tranche_3_Field.setFont(new Font("Rockwell", Font.PLAIN, 14));
		tranche_3_Field.setBorder(null);
		tranche_3_Field.setBounds(175, 130, 120, 20);
		tranche_3_Field.setBackground(new Color(49, 54, 70));
		panelJournaliere_tranche.add(tranche_3_Field);
		tranche_3_Field.setColumns(10);

		lblNewLabel_6 = new JLabel("Tranche n\u00B03");
		lblNewLabel_6.setForeground(Color.WHITE);
		lblNewLabel_6.setBackground(Color.WHITE);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNewLabel_6.setBounds(0, 130, 163, 24);
		panelJournaliere_tranche.add(lblNewLabel_6);

		separator_3 = new JSeparator();
		separator_3.setBorder(new LineBorder(Color.WHITE, 3));
		separator_3.setBounds(175, 53, 120, 2);
		panelJournaliere_tranche.add(separator_3);

		separator_4 = new JSeparator();
		separator_4.setBorder(new LineBorder(Color.WHITE, 3));
		separator_4.setBounds(175, 83, 120, 2);
		panelJournaliere_tranche.add(separator_4);

		separator_5 = new JSeparator();
		separator_5.setBorder(new LineBorder(Color.WHITE, 3));
		separator_5.setBounds(175, 120, 120, 2);
		panelJournaliere_tranche.add(separator_5);

		separator_6 = new JSeparator();
		separator_6.setBorder(new LineBorder(Color.WHITE, 3));
		separator_6.setBounds(175, 152, 120, 2);
		panelJournaliere_tranche.add(separator_6);

		btnPayerJournalier.setBackground(new Color(152, 16, 57));
		btnPayerJournalier.setFont(new Font("Rockwell", Font.BOLD, 16));
		btnPayerJournalier.setBounds(90, 184, 142, 20);
		panelJournaliere_tranche.add(btnPayerJournalier);

		JLabel lblNewLabel_7 = new JLabel("n\u00B0 Pi\u00E8ces");
		lblNewLabel_7.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(10, 39, 80, 20);
		panel.add(lblNewLabel_7);

		LabelAfficheNom = new JLabel("");
		LabelAfficheNom.setForeground(Color.WHITE);
		LabelAfficheNom.setFont(new Font("Rockwell", Font.BOLD, 13));
		LabelAfficheNom.setBounds(431, 64, 159, 23);
		panelChoix.add(LabelAfficheNom);

		lblNewLabel_8 = new JLabel("Nom :");
		lblNewLabel_8.setForeground(Color.WHITE);
		lblNewLabel_8.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_8.setBounds(352, 63, 69, 25);
		panelChoix.add(lblNewLabel_8);

		lblLabelPrenom = new JLabel("Pr\u00E9nom :");
		lblLabelPrenom.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblLabelPrenom.setForeground(Color.WHITE);
		lblLabelPrenom.setBounds(352, 100, 69, 25);
		panelChoix.add(lblLabelPrenom);

		labelAffichePrenom = new JLabel("");
		labelAffichePrenom.setFont(new Font("Rockwell", Font.BOLD, 13));
		labelAffichePrenom.setForeground(Color.WHITE);
		labelAffichePrenom.setBounds(431, 101, 159, 24);
		panelChoix.add(labelAffichePrenom);

		lblNewLabel_9 = new JLabel("Contrat :");
		lblNewLabel_9.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_9.setForeground(Color.WHITE);
		lblNewLabel_9.setBounds(352, 140, 69, 23);
		panelChoix.add(lblNewLabel_9);

		LabelContrat = new JLabel("");
		LabelContrat.setFont(new Font("Rockwell", Font.BOLD, 13));
		LabelContrat.setForeground(Color.WHITE);
		LabelContrat.setBounds(425, 140, 165, 23);
		panelChoix.add(LabelContrat);

		lblNewLabel_10 = new JLabel("Immobilier :");
		lblNewLabel_10.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_10.setForeground(Color.WHITE);
		lblNewLabel_10.setBounds(352, 180, 95, 22);
		panelChoix.add(lblNewLabel_10);

		LabelAfficheDetails = new JLabel("");
		LabelAfficheDetails.setFont(new Font("Rockwell", Font.BOLD, 13));
		LabelAfficheDetails.setForeground(Color.WHITE);
		LabelAfficheDetails.setBounds(452, 180, 138, 21);
		panelChoix.add(LabelAfficheDetails);

		lblNewLabel_11 = new JLabel("Montant :");
		lblNewLabel_11.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_11.setForeground(Color.WHITE);
		lblNewLabel_11.setBounds(352, 218, 82, 20);
		panelChoix.add(lblNewLabel_11);

		labelAfficheMontant = new JLabel("");
		labelAfficheMontant.setFont(new Font("Rockwell", Font.BOLD, 13));
		labelAfficheMontant.setForeground(Color.WHITE);
		labelAfficheMontant.setBounds(431, 218, 159, 20);
		panelChoix.add(labelAfficheMontant);

		labelLoyer = new JLabel("Loyer :");
		labelLoyer.setForeground(Color.WHITE);
		labelLoyer.setFont(new Font("Rockwell", Font.BOLD, 14));
		labelLoyer.setBounds(353, 253, 69, 20);
		panelChoix.add(labelLoyer);

		labelAfficheLoyer = new JLabel("");
		labelAfficheLoyer.setFont(new Font("Rockwell", Font.BOLD, 13));
		labelAfficheLoyer.setForeground(Color.WHITE);
		labelAfficheLoyer.setBounds(415, 254, 175, 20);
		panelChoix.add(labelAfficheLoyer);
		
		lblNewLabel_12 = new JLabel("Piece(s) :");
		lblNewLabel_12.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_12.setForeground(Color.WHITE);
		lblNewLabel_12.setBounds(352, 290, 69, 20);
		panelChoix.add(lblNewLabel_12);
		
		LabelAfficheNbrePieces = new JLabel("");
		LabelAfficheNbrePieces.setForeground(Color.WHITE);
		LabelAfficheNbrePieces.setFont(new Font("Rockwell", Font.BOLD, 13));
		LabelAfficheNbrePieces.setBounds(431, 290, 114, 20);
		panelChoix.add(LabelAfficheNbrePieces);
		this.setLocationRelativeTo(null);

		this.setResizable(false);
	}
	
	
	

	public JPanel getPanelPaiement_LongTerme() {
		return panelPaiement_LongTerme;
	}

	public void setPanelPaiement_LongTerme(JPanel panelPaiement_LongTerme) {
		this.panelPaiement_LongTerme = panelPaiement_LongTerme;
	}

	public JPanel getPanelJournaliere_tranche() {
		return panelJournaliere_tranche;
	}

	public void setPanelJournaliere_tranche(JPanel panelJournaliere_tranche) {
		this.panelJournaliere_tranche = panelJournaliere_tranche;
	}

	public JLabel getLabelAfficheNbrePieces() {
		return LabelAfficheNbrePieces;
	}

	public void setLabelAfficheNbrePieces(JLabel labelAfficheNbrePieces) {
		LabelAfficheNbrePieces = labelAfficheNbrePieces;
	}

	public JLabel getLabelAfficheDetails() {
		return LabelAfficheDetails;
	}

	public void setLabelAfficheDetails(JLabel labelAfficheDetails) {
		LabelAfficheDetails = labelAfficheDetails;
	}

	public JLabel getLabelAfficheMontant() {
		return labelAfficheMontant;
	}

	public void setLabelAfficheMontant(JLabel labelAfficheMontant) {
		this.labelAfficheMontant = labelAfficheMontant;
	}

	public JLabel getLabelAfficheLoyer() {
		return labelAfficheLoyer;
	}

	public void setLabelAfficheLoyer(JLabel labelAfficheLoyer) {
		this.labelAfficheLoyer = labelAfficheLoyer;
	}

	public JLabel getLabelAffichePrenom() {
		return labelAffichePrenom;
	}

	public void setLabelAffichePrenom(JLabel labelAffichePrenom) {
		this.labelAffichePrenom = labelAffichePrenom;
	}

	public JLabel getLabelContrat() {
		return LabelContrat;
	}

	public void setLabelContrat(JLabel labelContrat) {
		LabelContrat = labelContrat;
	}

	public JLabel getLabelAfficheNom() {
		return LabelAfficheNom;
	}

	public void setLabelAfficheNom(JLabel labelAfficheNom) {
		LabelAfficheNom = labelAfficheNom;
	}

	public JPanelSlider getPanelSlider() {
		return panelSlider;
	}

	public void setPanelSlider(JPanelSlider panelSlider) {
		this.panelSlider = panelSlider;
	}

	public JPanel getPanelChoix() {
		return panelChoix;
	}

	public void setPanelChoix(JPanel panelChoix) {
		this.panelChoix = panelChoix;
	}

	public JRadioButton getRadiobtnNvoPaiement() {
		return radiobtnNvoPaiement;
	}

	public void setRadiobtnNvoPaiement(JRadioButton radiobtnNvoPaiement) {
		this.radiobtnNvoPaiement = radiobtnNvoPaiement;
	}

	public String getNumPiecesField() {

		String value = NumPiecesField.getText();
		return value;
	}

	public void setNumPiecesField(JTextField numPiecesField) {
		NumPiecesField = numPiecesField;
	}

	public JButton getBtnRechercher() {
		return btnRechercher;
	}

	public void setBtnRechercher(JButton btnRechercher) {
		this.btnRechercher = btnRechercher;
	}

	public JRadioButton getRdioBtnAjoutPaiement() {
		return rdioBtnAjoutPaiement;
	}

	public void setRdioBtnAjoutPaiement(JRadioButton rdioBtnAjoutPaiement) {
		this.rdioBtnAjoutPaiement = rdioBtnAjoutPaiement;
	}

	public JPanel getPanelAcceuil() {
		return panelAcceuil;
	}

	public void setPanelAcceuil(JPanel panelAcceuil) {
		this.panelAcceuil = panelAcceuil;
	}

	public JPanelSlider getPanelSliderPaiementField() {
		return panelSliderPaiementField;
	}

	public void setPanelSliderPaiementField(JPanelSlider panelSliderPaiementField) {
		this.panelSliderPaiementField = panelSliderPaiementField;
	}

	public JPanel getPanelCaution() {
		return panelCaution;
	}

	public void setPanelCaution(JPanel panelCaution) {
		this.panelCaution = panelCaution;
	}

	public JTextField getTextFieldCaution() {
		return textFieldCaution;
	}

	public void setTextFieldCaution(JTextField textFieldCaution) {
		this.textFieldCaution = textFieldCaution;
	}

	public JTextField getTextFieldMensualit�() {
		return textFieldMensualit�;
	}

	public void setTextFieldMensualit�(JTextField textFieldMensualit�) {
		this.textFieldMensualit� = textFieldMensualit�;
	}

	public JButton getBtnPayer() {
		return btnPayer;
	}

	public void setBtnPayer(JButton btnPayer) {
		this.btnPayer = btnPayer;
	}

	public JTextField getTextFieldMontant_Journalier() {
		return textFieldMontant_Journalier;
	}

	public void setTextFieldMontant_Journalier(JTextField textFieldMontant_Journalier) {
		this.textFieldMontant_Journalier = textFieldMontant_Journalier;
	}

	public JTextField getTranche_1_Field() {
		return tranche_1_Field;
	}

	public void setTranche_1_Field(JTextField tranche_1_Field) {
		this.tranche_1_Field = tranche_1_Field;
	}

	public JTextField getTranche_2_Field() {
		return tranche_2_Field;
	}

	public void setTranche_2_Field(JTextField tranche_2_Field) {
		this.tranche_2_Field = tranche_2_Field;
	}

	public JTextField getTranche_3_Field() {
		return tranche_3_Field;
	}

	public void setTranche_3_Field(JTextField tranche_3_Field) {
		this.tranche_3_Field = tranche_3_Field;
	}

	public JButton getBtnPayerJournalier() {
		return btnPayerJournalier;
	}

	public void setBtnPayerJournalier(JButton btnPayerJournalier) {
		this.btnPayerJournalier = btnPayerJournalier;
	}
	
	
	

	public void addEcouteurBtnRechercher(ActionListener actionListener) {

		btnRechercher.addActionListener(actionListener);
	}
	
	public void run() {
		this.setVisible(true);
	}
	
public void EcouteurBtnRadio(ActionListener actionListener) {
		
		radiobtnNvoPaiement.addActionListener(actionListener);
	}

public void EcouteurBtnRadioAjoutPaiement(ActionListener actionListener) {
	
	rdioBtnAjoutPaiement.addActionListener(actionListener);
	
}

public void EcouteurbtnPayerLongtermeNvoPaiment(ActionListener actionListener) {
	btnPayer.addActionListener(actionListener);
	
}

public void clear() {
	
	this.getTextFieldCaution().setText(null);
	this.getTextFieldMensualit�().setText(null);
	this.getTranche_1_Field().setText(null);
	this.getTranche_2_Field().setText(null);
	this.getTranche_3_Field().setText(null);
	this.getTextFieldMontant_Journalier().setText(null);

}

public void addEcouteurBtnPayerJournalier(ActionListener actionListener) {
	btnPayerJournalier.addActionListener(actionListener);
}



public void MessageExceptionIllegal() {
	
	JOptionPane.showMessageDialog(null, "ENTREZ UNE VALEUR SVP!!!", "Champs vide", JOptionPane.ERROR_MESSAGE);
}

public void MessageNoncorrespondance() {
	
	JOptionPane.showMessageDialog(null, "NUMERO INVALIDE", "Erreur de correspondance", JOptionPane.ERROR_MESSAGE);
	
}



/////////////////////////////////////////////////////
public void Excption(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Exception Bouton Radio", JOptionPane.ERROR_MESSAGE);
}




public void MessageInexistantLocat(String message) {
	JOptionPane.showMessageDialog(null, message, "locataire Introuvable", JOptionPane.ERROR_MESSAGE);
	
}




public void Avertissement(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Exception Bouton Radio", JOptionPane.ERROR_MESSAGE);
}




public void inexistLocat(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Locataire Inexistant", JOptionPane.ERROR_MESSAGE);
	
}




public void MessIllegalargument(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Mauvais Format de Donn�e", JOptionPane.ERROR_MESSAGE);
}




public void MessageNullPointer(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Introuvable", JOptionPane.ERROR_MESSAGE);
}




public void MessExceptions(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Exception_2", JOptionPane.ERROR_MESSAGE);	
}




public void MessChampsvide(String message) {

	JOptionPane.showMessageDialog(null, message, "Champs non renseign�", JOptionPane.ERROR_MESSAGE);
	
}


public void MessageErrPaiement(String message) {
	JOptionPane.showMessageDialog(null, message, "Erreur d'enregistrement", JOptionPane.ERROR_MESSAGE);		
}


public void Succes() {
	JOptionPane.showMessageDialog(null, "Paiement Enregistr�", "Succes", JOptionPane.INFORMATION_MESSAGE);	
}


public void MessageErrorss(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Exception Couche Metier", JOptionPane.ERROR_MESSAGE);	
}

public void MessageErrors(String message) {
	JOptionPane.showMessageDialog(null, message, "Exception Metier", JOptionPane.ERROR_MESSAGE);	
	
}

public void MessageError(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Exception Metier Tranche 3 ", JOptionPane.ERROR_MESSAGE);
}


public void MessageIndication() {
	
	JOptionPane.showMessageDialog(null, "Veuillez selectionner le type du paiement", "Indication", JOptionPane.ERROR_MESSAGE);
	
}


public void MessageSError(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Exception Metier Mensualit�", JOptionPane.ERROR_MESSAGE);		
}


public void messageErreur(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Exception Couche Metier 3", JOptionPane.ERROR_MESSAGE);
	
}


public void MessageExceptionMetieer(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Erreur niveau recherche", JOptionPane.ERROR_MESSAGE);
	
}


public void MessageException(String message) {
	
	JOptionPane.showMessageDialog(null, message, "Recherche Locataire", JOptionPane.ERROR_MESSAGE);
	
}


public void Excption() {
	JOptionPane.showMessageDialog(null, "ENTREZ LE NUMERO DE LA PIECE SVP!", "Recherche Locataire", JOptionPane.ERROR_MESSAGE);
	
}

public void MessageInexistantLocat() {
	JOptionPane.showMessageDialog(null, "Locataire Inexistant!", "Recherche Locataire", JOptionPane.ERROR_MESSAGE);
	
}

public void Avertissement() {
	JOptionPane.showMessageDialog(null, "ENTREZ LE NUMERO DE LA PIECE", "EXCEPTION", JOptionPane.ERROR_MESSAGE);
	
}

public void inexistLocat() {
	JOptionPane.showMessageDialog(null, "LOCATAIRE INEXISTANT", "EXCEPTION", JOptionPane.ERROR_MESSAGE);	
}




public void ecouteurBtnTerminer(ActionListener actionListener) {
	BtnTerminer.addActionListener(actionListener);
	
}




}

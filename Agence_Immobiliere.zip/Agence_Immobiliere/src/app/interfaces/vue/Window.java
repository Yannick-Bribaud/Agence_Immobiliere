package app.interfaces.vue;

import java.awt.Dimension;





import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import diu.swe.habib.JPanelSlider.JPanelSlider;
import javax.swing.JButton;
import java.awt.Insets;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.awt.BorderLayout;
import org.jdesktop.swingx.JXCollapsiblePane;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import javax.swing.JTextArea;

public class Window extends JFrame {
	
	private static final long serialVersionUID = -3678574052154010341L;
	
	private  JPanel panelMenuAdmin;
	private  JPanel PanelAfficheMenu;
	private  JPanel panelSousMenu;
	private  JPanel PanelSousMenu2Admin;
	private  JPanel panelGestionnaire;
	private  JPanel panelbtnfonctionalite;
	private  JPanelSlider panelSliderGesbtn;
	private  JPanelSlider panelSliderDebord;
	private  JPanel panelAdminTab;
	private  TableauImmobilier PaneTabImmo;
	private  JTable tableUsers;
	private  JXCollapsiblePane collapsiblePane;
	private  JButton btnCollapse;
	private  JPanel panelRacine;
	private  JPanelSlider panelSliderMenu;
	private  JButton btnEteindre;
	private  JPanel panelbtnMenu;
	private  JButton btnAuthentification;
	private  JButton btnConsulterBien;
	private  JPanel panelBoutonGestionnaire;
	private  JButton btnConsultGestionnaire;
	private  JButton btnConsultPaiement;
	private  JButton btnAppuyerMoi;
	private  JButton btnEnregistrerPaiement;
	private  JButton btnConsultLocataireSansException;
	private  JButton btnAffection;
	private  JButton btnModifierPaiement;
	private  JButton btnSuppPaiement;
	private  JButton btnaddUser;
	private  JButton btnSuppressionUser;
	private  JButton btnaddBienImmo;
	private  JButton btnGestionUser;
	private  JButton btnDesactiverBiensImmo;
	private  JPanel PanneauAccueil;
	private  JPanel panelTableaud;
	private  JScrollPane scrollPane;
	private  JButton BtnGestionImmo;
	private  JButton btnConsultLocataire;
	private JPanel panelConsulterPaiement;
	private JPanel panelTabImmo;
	private JPanel panelLocataire;
	private JTable tableImmoNonMisEnLocation;
	private  JPanel panelBienNonLocation;
	private JTable TableGestLocataire;
	private JPanel panelListeLocataire;
	private JTextField textFieldModifNomLocat;
	private JTextField textFieldModifPrenom;
	private JTextField textFieldModifNumPieces;
	private JTextField textFieldModifGenre;
	private JTextField textFieldModifDate;
	private JTextField textFieldModifTelph;
	private JTextField textFieldModifEmail;
	private JPanel panelModificationLocat;
	private JPanel panelModif;
	private JTextField textFieldId;
	private JLabel lblNewLabel_7;
	private  JButton btnModifier ;
	private JTextField textFieldIdUser;
	private JTextField textFieldUsername;
	private JTextField textFieldUserLastname;
	private JTextField textFieldUserLogin;
	private JTextField textFieldUserMdp;
	private JTextField textFieldUserAdress;
	private JTextField textFieldUserNaissance;
	private JTextField textFieldNumTelphUser;
	private JTextField textFieldUserEmail;
	private JPanel panelModifUserPane;
	private JPanel panelUserModif;
	private JButton btnModifAdmin;
	private JButton btnModifUser;
	private JPanel panelModifImmo;
	private JPanel panel;
	private JTextField textFieldIdImmo;
	private JTextField textFieldAdressImmo;
	private JTextField textFieldNbrePiece;
	private JTextField textFieldMontantImmo;
	private JTextField textFieldLoyerImmo;
	private JTextArea textAreaDetaisImmo;  
	private JButton btnModifImmoS;
	private JTextField textFieldIdPaiement;
	private JTextField textFieldCautionPaiement;
	private JTextField textFieldNumPiecesPaiement;
	private JTextField textFieldTranche3Paiement;
	private JTextField textFieldMntantJrnPaiemnt;
	private JTextField textFieldTranche1Paiement;
	private JTextField textFieldLoyerPaiement;
	private JTextField textFieldTranche2Paiement;
	private JPanel panelModifPaiement;
	private JPanel panelPaiModifie;
	private JPanel panelTabPaiement;
	private JTable tablePaiementGestion;
	private JTable tableConsulterPaiement;
	private JScrollPane scrollPane_1;
	private JPanel panel_1;
	private JLabel lblNewLabel_33;
	private JTable tableLocataire;
	private JScrollPane scrollPane_3;
	private JPanel panel_2;
	private JLabel lblNewLabel_34;
	private JTable tableImmobilier;
	private JPanel panel_AffichePaiement;
	private JLabel lblNewLabel_36;
	private JButton btnModifPaye;
	private JLabel lblHours;
	
	
	
	
	public Window()  {
		
		 panelConsulterPaiement = new JPanel();
		 panelSliderDebord = new JPanelSlider();
		 panelAdminTab = new JPanel();
		 panelAdminTab.setBackground(Color.WHITE);
		 collapsiblePane = new JXCollapsiblePane();
		 PaneTabImmo = new TableauImmobilier();
		 PaneTabImmo.getTableImmobilier().setSelectionBackground(new Color(0, 153, 255));
		 PaneTabImmo.getTableImmobilier().setSelectionForeground(Color.BLACK);
		 
		 
		 JPanel panelHautenBleu = new JPanel();
		 panelSliderMenu = new JPanelSlider();
		 btnEteindre = new JButton("");
		 btnEteindre.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
	int reponse = JOptionPane.showConfirmDialog(null, "Voulez-vraiment Eteindre l'Application", "Confirmation",JOptionPane.YES_NO_OPTION);
	
		 	if(reponse == JOptionPane.YES_OPTION)
		 	{
		 		dispose();
		 	}
		 	
		 	
		 	}
		 });
		 panelbtnMenu = new JPanel();
		 btnAuthentification = new JButton("Authentification");
		 btnConsulterBien = new JButton("Consulter Biens");
		 panelGestionnaire = new JPanel();
		 panelBoutonGestionnaire = new JPanel();
		 btnConsultGestionnaire = new JButton("");
		 btnConsultGestionnaire.setToolTipText("Consulter les biens ");
		 btnConsultPaiement = new JButton("Consulter Paiements");
		 btnAppuyerMoi = new JButton("Appuyer Ici");
		 panelbtnfonctionalite = new JPanel();
		 panelSliderGesbtn = new JPanelSlider();
		 btnEnregistrerPaiement = new JButton("");
		 btnEnregistrerPaiement.setToolTipText("paiement");
		 btnEnregistrerPaiement.setFont(new Font("Tahoma", Font.PLAIN, 5));
		 btnConsultLocataireSansException = new JButton("");
		 btnConsultLocataireSansException.setToolTipText("Consulter Les locataires");
		 btnAffection = new JButton("");
		 btnAffection.setToolTipText("Faire une affectation");
		 btnModifierPaiement = new JButton("");
	
		 btnModifierPaiement.setToolTipText("Modifier paiement");
		 btnSuppPaiement = new JButton("");
		 btnSuppPaiement.setToolTipText("Supprimer paiement");
		 btnaddUser = new JButton("");
		 btnSuppressionUser = new JButton("");
		 btnaddBienImmo = new JButton("");
		 btnGestionUser = new JButton("");
		 btnDesactiverBiensImmo = new JButton("");
		 PanneauAccueil = new JPanel();
		 panelTableaud = new JPanel();
		 panelTableaud.setBackground(Color.WHITE);
		 scrollPane = new JScrollPane();
		 scrollPane.setAutoscrolls(true);
		 scrollPane.setBackground(Color.BLACK);
		 BtnGestionImmo = new JButton("");
		 tableUsers = new JTable();
		 textAreaDetaisImmo = new JTextArea();
		 textAreaDetaisImmo = new JTextArea();
		 
		 btnModifImmoS = new JButton("Modifier");
		 btnModifImmoS.setHorizontalTextPosition(SwingConstants.CENTER);
		 btnModifImmoS.setBackground(new Color(178, 34, 34));
		 panelModifPaiement = new JPanel();
		 panelModifPaiement.setBackground(new Color(9, 37, 64));
		 panelPaiModifie = new JPanel();
		 panelPaiModifie.setBackground(new Color(9, 37, 64));
		 
		 
		 tableUsers.setShowGrid(false);
		 tableUsers.setShowHorizontalLines(false);
		 tableUsers.setSelectionForeground(Color.BLACK);
		 tableUsers.setSelectionBackground(new Color(0, 128, 128));
		 tableUsers.setIntercellSpacing(new Dimension(0, 0));
		 tableUsers.setRowHeight(25);
		 tableUsers.setGridColor(Color.WHITE);
		 tableUsers.setForeground(Color.BLACK);
		 tableUsers.setBackground((Color.WHITE));
		 tableUsers.setFont(new Font("Rockwell", Font.BOLD,12));
		 btnConsultLocataire = new JButton("Consulter Locataires");
		 panelBienNonLocation = new JPanel();
		 panelListeLocataire = new JPanel();
		 panelModificationLocat = new JPanel();
		 panelModificationLocat.setBackground(new Color(9, 37, 64));
		 panelModif = new JPanel();
		 panelModif.setBackground(new Color(22, 64, 114));
		 btnModifier = new JButton("Modifier");
		 panelModifUserPane = new JPanel();
		 panelModifUserPane.setBackground(new Color(9, 37, 64));
		 panelUserModif = new JPanel();
		 panelUserModif.setBackground(new Color(9, 37, 64));
		 btnModifAdmin = new JButton("");
		 btnModifUser = new JButton("Modifier");
		 btnModifUser.setBackground(new Color(152, 16, 57));
		 btnModifUser.setBackground(new Color(178, 34, 34));
		 btnModifUser.setForeground(Color.WHITE);
		 btnModifPaye = new JButton("Modifier");
		 
		 
		  
		   btnCollapse = new JButton("Bouton \u00E0 Bascule");
		  btnCollapse.addMouseListener(new MouseAdapter() {
		   	@Override
		   	public void mouseClicked(MouseEvent e) {
		   		if(tableUsers.getSelectedRow() !=-1)
		   		{
		   			tableUsers.clearSelection();
		   		}
		   		else
		   		{
		   			PaneTabImmo.getTableImmobilier().clearSelection();
		   		}
		   		
		   		
		   	}
		   });
		   btnCollapse.setBorderPainted(false);
		   btnCollapse.setBackground(Color.WHITE);
		   btnCollapse.setForeground(new Color(48, 62, 71));
		   btnCollapse.setFont(new Font("Rockwell", Font.BOLD, 14));
		   panelRacine = new JPanel();
		
		setResizable(false);
		setSize(new Dimension(1083, 578));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		
		this.setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		panelRacine.setBackground(Color.WHITE);
		
		panelRacine.setBounds(0, 0, 1079, 559);
		panelRacine.setPreferredSize(new Dimension(1200, 600));
		getContentPane().add(panelRacine);
		panelRacine.setLayout(null);
		
		JPanel panelGaucheBleu = new JPanel();
		panelGaucheBleu.setBackground(new Color(4, 26, 76));
		panelGaucheBleu.setBounds(0, 0, 131, 551);
		panelGaucheBleu.setPreferredSize(new Dimension(142, 665));
		panelRacine.add(panelGaucheBleu);
		panelGaucheBleu.setLayout(null);
		
		
		btnEteindre.setContentAreaFilled(false);
		btnEteindre.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\shutdown_32px.png"));
		btnEteindre.setBorderPainted(false);
		btnEteindre.setBounds(10, 500, 40, 40);
		panelGaucheBleu.add(btnEteindre);
		
		//-------------------------------------------------111--------------------------------------------------------------
		
		
		panelHautenBleu.setBackground(new Color(4, 26, 76));
		panelHautenBleu.setBounds(131, 0, 950, 21);
		panelHautenBleu.setPreferredSize(new Dimension(1143, 21));
		panelRacine.add(panelHautenBleu);
		
		
		panelSliderMenu.setBounds(131, 144, 236, 407);
		panelRacine.add(panelSliderMenu);
		
		
		panelbtnMenu.setBackground(new Color(26, 26, 26));
		panelSliderMenu.add(panelbtnMenu, "name_272127392819100");
		panelbtnMenu.setLayout(null);
		
		
		
		
//-------------------------------------------------------------------2222-------------------------------------------------------------------------
		btnAuthentification.setMargin(new Insets(1, 14, 1, 14));
		btnAuthentification.setFont(new Font("Stencil", Font.PLAIN, 12));
		btnAuthentification.setForeground(Color.WHITE);
		btnAuthentification.setBackground(Color.BLACK);
		btnAuthentification.setBounds(24, 52, 177, 33);
		panelbtnMenu.add(btnAuthentification);
		
		
		btnConsulterBien.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				btnConsulterBien.setBackground(new Color(49, 54, 70));	
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				btnConsulterBien.setBackground(Color.BLACK);
			}
		});
		btnConsulterBien.setForeground(Color.WHITE);
		btnConsulterBien.setFont(new Font("Stencil", Font.PLAIN, 12));
		btnConsulterBien.setBackground(Color.BLACK);
		btnConsulterBien.setBounds(24, 122, 177, 33);
		panelbtnMenu.add(btnConsulterBien);
		
		
		btnConsultPaiement.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnConsultPaiement.setBackground(new Color(49, 54, 70));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				btnConsultPaiement.setBackground(Color.BLACK);
			}
		});
		btnConsultPaiement.setForeground(Color.WHITE);
		btnConsultPaiement.setFont(new Font("Stencil", Font.PLAIN, 12));
		btnConsultPaiement.setBackground(Color.BLACK);
		btnConsultPaiement.setBounds(24, 188, 177, 33);
		panelbtnMenu.add(btnConsultPaiement);
		
		
		btnConsultLocataire.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				btnConsultLocataire.setBackground(new Color(49, 54, 70));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				btnConsultLocataire.setBackground(Color.BLACK);
			}
		});
		btnConsultLocataire.setFont(new Font("Stencil", Font.PLAIN, 11));
		btnConsultLocataire.setForeground(Color.WHITE);
		btnConsultLocataire.setBackground(Color.BLACK);
		btnConsultLocataire.setBounds(24, 255, 177, 33);
		panelbtnMenu.add(btnConsultLocataire);
		//----------------------------------------------------------3333333--------------------------------------------------------------
		
		panelGestionnaire.setBackground(new Color(49, 51, 54));
		panelSliderMenu.add(panelGestionnaire, "name_3");
		panelGestionnaire.setLayout(null);
		
		
		panelSliderGesbtn.setBounds(0, 53, 180, 350);
		panelGestionnaire.add(panelSliderGesbtn);
		
		
		panelSliderGesbtn.add(panelBoutonGestionnaire, "name_366263478195100");
		panelBoutonGestionnaire.setLayout(null);
		
		
		btnAppuyerMoi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			
				panelSliderGesbtn.nextPanel(1, panelbtnfonctionalite,JPanelSlider.right );
				
			}
		});
		btnAppuyerMoi.setBounds(6, 76, 156, 194);
		panelBoutonGestionnaire.add(btnAppuyerMoi);
		
		JLabel QuitterBtnAppuyer = new JLabel("");
		QuitterBtnAppuyer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelSliderGesbtn.setVisible(false);
				panelSliderMenu.nextPanel(1, panelbtnMenu, JPanelSlider.left);
				panelSliderDebord.nextPanel(1, PanneauAccueil, JPanelSlider.left);
				panelSliderGesbtn.setVisible(true);
			}
		});
		QuitterBtnAppuyer.setBounds(136, 0, 40, 32);
		ImageIcon Quit= new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\right_32px.png");
		Image Quitt= Quit.getImage();
		Image Rdme = Quitt.getScaledInstance(41, 43, Image.SCALE_SMOOTH);
		ImageIcon Rdme_I = new ImageIcon(Rdme);
		QuitterBtnAppuyer.setIcon(Rdme_I);
		panelBoutonGestionnaire.add(QuitterBtnAppuyer);
		
	   
		panelSliderGesbtn.add(panelbtnfonctionalite, "name_366680085581000");
		panelbtnfonctionalite.setLayout(null);
		
		
		//--------------------------------------------444444-------------------------------------------------------------------------------
		
		btnConsultGestionnaire.setBackground(new Color(240, 240, 240));
		btnConsultGestionnaire.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\property_script_32px.png"));
		btnConsultGestionnaire.setBounds(10, 56, 69, 69);
		panelbtnfonctionalite.add(btnConsultGestionnaire);
		
		
		btnEnregistrerPaiement.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\cash_in_hand_64px.png"));
		btnEnregistrerPaiement.setBounds(10, 148, 69, 69);
		panelbtnfonctionalite.add(btnEnregistrerPaiement);
		
		
		btnConsultLocataireSansException.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\Locataire_48px.png"));
		btnConsultLocataireSansException.setBounds(10, 245, 69, 69);
		panelbtnfonctionalite.add(btnConsultLocataireSansException);
		
		
		btnAffection.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\Affectation_52px.png"));
		btnAffection.setBounds(111, 56, 55, 69);
		panelbtnfonctionalite.add(btnAffection);
		
		
		btnModifierPaiement.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\edit_file_48px.png"));
		btnModifierPaiement.setBounds(111, 148, 55, 69);
		panelbtnfonctionalite.add(btnModifierPaiement);
		
		
		btnSuppPaiement.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\SuppPayment_48px.png"));
		btnSuppPaiement.setBounds(111, 245, 55, 69);
		panelbtnfonctionalite.add(btnSuppPaiement);
		
		JLabel PreviousToAppuyerIci = new JLabel("");
		PreviousToAppuyerIci.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				panelSliderGesbtn.nextPanel(1, panelBoutonGestionnaire, JPanelSlider.left);
				
			}
		});
		
	//----------------------------------------------------5555555555-----------------------------------------------------------------------------------
		PreviousToAppuyerIci.setBounds(138, 4, 38, 24);
		ImageIcon iconPrevious = new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\right_32px.png");
		Image ImgPrevious =iconPrevious.getImage();
		Image Rdim = ImgPrevious.getScaledInstance(38, 32, Image.SCALE_SMOOTH);
		ImageIcon RedimImgs = new ImageIcon(Rdim);
		PreviousToAppuyerIci.setIcon(RedimImgs);
		panelbtnfonctionalite.add(PreviousToAppuyerIci);
		
		panelMenuAdmin = new JPanel();
		panelSliderMenu.add(panelMenuAdmin, "name");
		panelMenuAdmin.setLayout(null);
		
		JLabel LabelPrevious = new JLabel("");
		LabelPrevious.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelSousMenu.setVisible(false);
				PanelSousMenu2Admin.setVisible(false);
				panelSliderMenu.nextPanel(3, panelMenuAdmin, JPanelSlider.right);
				panelSliderDebord.nextPanel(1, PanneauAccueil, JPanelSlider.right);
				
			}
		});
		LabelPrevious.setBounds(3, 7, 36, 32);
		ImageIcon icon = new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\long_arrow_left_32px.png");
		Image img = icon.getImage();
		Image dimImg= img.getScaledInstance(36, 32, Image.SCALE_SMOOTH);
		ImageIcon RedimImg = new ImageIcon(dimImg);
		LabelPrevious.setIcon(RedimImg);
		panelMenuAdmin.add(LabelPrevious);
		
		
		btnGestionUser.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SousMenus();	
			}
		});
		btnGestionUser.setBackground(Color.WHITE);
		btnGestionUser.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\people_52px.png"));
		btnGestionUser.setBounds(82, 20, 73, 73);
		panelMenuAdmin.add(btnGestionUser);
		
		 panelSousMenu = new JPanel();
		 panelSousMenu.setVisible(false);
		 panelSousMenu.setBounds(15, 93, 207, 68);
		 panelMenuAdmin.add(panelSousMenu);
		 panelSousMenu.setLayout(null);
		
		
		btnaddUser.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\add_user_male_52px.png"));
		btnaddUser.setRolloverEnabled(false);
		btnaddUser.setBackground(Color.WHITE);
		btnaddUser.setBounds(0, 0, 70, 68);
		panelSousMenu.add(btnaddUser);
		
		
//-----------------------------------------------------666666------------------------------------------------------------------------------
		
		btnSuppressionUser.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\delete_user_male_48px.png"));
		btnSuppressionUser.setBackground(Color.WHITE);
		btnSuppressionUser.setBounds(137, 0, 70, 68);
		panelSousMenu.add(btnSuppressionUser);
		
		PanelSousMenu2Admin = new JPanel();
		PanelSousMenu2Admin.setBounds(15, 240, 207, 68);
		PanelSousMenu2Admin.setVisible(false);
		panelMenuAdmin.add(PanelSousMenu2Admin);
		PanelSousMenu2Admin.setLayout(null);
		
		
		btnaddBienImmo.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\plus_48px.png"));
		btnaddBienImmo.setRolloverEnabled(false);
		btnaddBienImmo.setBackground(Color.WHITE);
		btnaddBienImmo.setBounds(0, 0, 70, 68);
		PanelSousMenu2Admin.add(btnaddBienImmo);
		
		
		btnDesactiverBiensImmo.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\home_safety_48px.png"));
		btnDesactiverBiensImmo.setRolloverEnabled(false);
		btnDesactiverBiensImmo.setBackground(Color.WHITE);
		btnDesactiverBiensImmo.setBounds(137, 0, 70, 68);
		PanelSousMenu2Admin.add(btnDesactiverBiensImmo);
		
		
		BtnGestionImmo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SousMenus_2();
			}
		});
		BtnGestionImmo.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\property_48px.png"));
		BtnGestionImmo.setBackground(Color.WHITE);
		BtnGestionImmo.setBounds(80, 309, 73, 73);
		panelMenuAdmin.add(BtnGestionImmo);
		
		
		btnModifAdmin.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\edit_file_48px.png"));
		btnModifAdmin.setBounds(82, 164, 73, 73);
		panelMenuAdmin.add(btnModifAdmin);
		
		PanelAfficheMenu = new JPanel();
		PanelAfficheMenu.setBackground(new Color(139, 0, 0));
		PanelAfficheMenu.setBounds(131, 116, 234, 30);
		panelRacine.add(PanelAfficheMenu);
		
		JLabel LabelMenu = new JLabel("Menu");
		LabelMenu.setForeground(Color.WHITE);
		LabelMenu.setFont(new Font("Stencil", Font.PLAIN, 20));
		LabelMenu.setHorizontalAlignment(SwingConstants.CENTER);
		PanelAfficheMenu.add(LabelMenu);
		
		
		panelSliderDebord.setBounds(365, 22, 716, 528);
		panelRacine.add(panelSliderDebord);
		
		
		PanneauAccueil.setBackground(Color.BLACK);
		panelSliderDebord.add(PanneauAccueil, "name_293489761403000");
		PanneauAccueil.setLayout(null);
		
		JLabel lblPaneAcc = new JLabel("New label");
		lblPaneAcc.setHorizontalAlignment(SwingConstants.CENTER);
		lblPaneAcc.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\Ac3Gif.gif"));
		lblPaneAcc.setBounds(0, 38, 710, 490);
		
		PanneauAccueil.add(lblPaneAcc);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(Color.WHITE);
		panel_6.setBounds(0, 0, 712, 37);
		PanneauAccueil.add(panel_6);
		
		JLabel lblNewLabel_38 = new JLabel("Bienvenue");
		lblNewLabel_38.setForeground(new Color(0, 0, 128));
		lblNewLabel_38.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_38.setFont(new Font("Stencil", Font.BOLD, 26));
		panel_6.add(lblNewLabel_38);
		
		
		panelSliderDebord.add(panelAdminTab, "name_72122188390400");
		panelAdminTab.setLayout(new BorderLayout(0, 0));
		
		
		collapsiblePane.getContentPane().setVisible(false);
		panelAdminTab.add(collapsiblePane, BorderLayout.NORTH);
		collapsiblePane.setLayout(new BorderLayout());
		collapsiblePane.add(PaneTabImmo,BorderLayout.CENTER);
		
		
		
		panelAdminTab.add(btnCollapse, BorderLayout.SOUTH);
		
		
		panelAdminTab.add(panelTableaud, BorderLayout.CENTER);
		panelTableaud.setLayout(new BorderLayout(0, 0));
		
		
		panelTableaud.add(scrollPane, BorderLayout.CENTER);
		
		
		tableUsers.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Identifiant", "Nom", "Pr\u00E9nom", "Date Naissance", "Password", "Login", "Email", "Statut", "Adresse", "T\u00E9l\u00E9phone"
			}
		) {
			
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableUsers.getTableHeader().setBackground(new Color(3, 118, 114));
		tableUsers.getTableHeader().setForeground(new Color(238, 237, 243));
		tableUsers.getTableHeader().setFont(new Font("Rockwell",Font.BOLD, 14));
		
		scrollPane.setViewportView(tableUsers);
		
		
		panelSliderDebord.add(panelConsulterPaiement, "name_100879441592900");
		panelConsulterPaiement.setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(77, 87, 575, 355);
		panelConsulterPaiement.setBackground(new Color(9, 37, 64));
		panelConsulterPaiement.add(scrollPane_1);
		
		tableConsulterPaiement = new JTable();
		tableConsulterPaiement.setSelectionBackground(new Color(135, 206, 235));
		tableConsulterPaiement.setSelectionForeground(Color.BLACK);
		tableConsulterPaiement.setGridColor(Color.GRAY);
		tableConsulterPaiement.setShowHorizontalLines(false);
		tableConsulterPaiement.setFont(new Font("Rockwell",Font.BOLD, 14));
		tableConsulterPaiement.getTableHeader().setBackground(new Color(92, 201, 230));
		tableConsulterPaiement.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"N\u00B0 Pi\u00E8ces", "Caution", "Loyer", "Montant Journalier", "Tranche 1", "Tranche 2", "Tranche 3"
			}
		) {
			
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane_1.setViewportView(tableConsulterPaiement);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 712, 37);
		panelConsulterPaiement.add(panel_1);
		
		lblNewLabel_33 = new JLabel("Table Des Paiements");
		lblNewLabel_33.setForeground(new Color(0, 0, 128));
		lblNewLabel_33.setFont(new Font("Rockwell", Font.BOLD, 22));
		panel_1.add(lblNewLabel_33);
		
		panelTabImmo = new JPanel();
		
		panelSliderDebord.add(panelTabImmo, "name_133848267488999");
		panelTabImmo.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(78, 93, 559, 361);
		panelTabImmo.add(scrollPane_2);
		panelTabImmo.setBackground(new Color(9, 37, 64));
		
		tableImmobilier = new JTable();
		tableImmobilier.setSelectionBackground(new Color(0, 128, 128));
		tableImmobilier.setSelectionForeground(Color.BLACK);
		tableImmobilier.setShowGrid(false);
		tableImmobilier.getTableHeader().setBackground(new Color(0,128,128));
		tableImmobilier.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Adresse Immobilier", "Nombre Pi\u00E8ces", "Montant", "Loyer", "Details", "Statut"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane_2.setViewportView(tableImmobilier);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(0, 0, 712, 39);
		panelTabImmo.add(panel_3);
		
		JLabel lblNewLabel_35 = new JLabel("Table Des Biens Immobiliers");
		lblNewLabel_35.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_35.setForeground(new Color(0, 128, 128));
		lblNewLabel_35.setFont(new Font("Rockwell", Font.BOLD, 22));
		panel_3.add(lblNewLabel_35);
		
		panelLocataire = new JPanel();
		panelLocataire.setBackground(new Color(9, 37, 64));
		panelSliderDebord.add(panelLocataire, "name_145985116150000");
		panelLocataire.setLayout(null);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(55, 73, 618, 337);
		panelLocataire.add(scrollPane_3);
		
		tableLocataire = new JTable();
		tableLocataire.setSelectionBackground(new Color(178, 34, 34));
		tableLocataire.setSelectionForeground(Color.BLACK);
		tableLocataire.setShowVerticalLines(false);
		tableLocataire.setShowGrid(false);
		tableLocataire.setShowHorizontalLines(false);
		tableLocataire.getTableHeader().setBackground(new Color(139, 12, 61));
		tableLocataire.setFont(new Font("Rockwell", Font.BOLD,14));
		tableLocataire.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Identifiant", "Nom", "Prenom", "N\u00B0 Pi\u00E8ce", "Genre", "Date Naissance", "T\u00E9l\u00E9phone", "Email", "Contrat"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane_3.setViewportView(tableLocataire);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(0, 0, 712, 35);
		panelLocataire.add(panel_2);
		
		lblNewLabel_34 = new JLabel("Table des Locataires");
		lblNewLabel_34.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_34.setForeground(new Color(47, 79, 79));
		lblNewLabel_34.setFont(new Font("Rockwell", Font.BOLD, 22));
		panel_2.add(lblNewLabel_34);
		
		
		panelSliderDebord.add(panelBienNonLocation, "name_149528058267200");
		panelBienNonLocation.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane_4 = new JScrollPane();
		panelBienNonLocation.add(scrollPane_4, BorderLayout.CENTER);
		
		tableImmoNonMisEnLocation = new JTable();
		tableImmoNonMisEnLocation.setFont(new Font("Rockwell", Font.BOLD,14));
		tableImmoNonMisEnLocation.setShowGrid(false);
		tableImmoNonMisEnLocation.setGridColor(Color.BLACK);
		tableImmoNonMisEnLocation.setFont(new Font("Rockwell", Font.BOLD, 14));
		tableImmoNonMisEnLocation.setGridColor(SystemColor.desktop);
		tableImmoNonMisEnLocation.getTableHeader().setBackground(new Color(229, 48, 90));
		tableImmoNonMisEnLocation.setShowGrid(false);
		
		tableImmoNonMisEnLocation.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Adresse Immobilier", "Nombre Pi\u00E8ces", "Loyer", "Montant", "Details", "Statut"
			}
		) {
			
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, true, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		scrollPane_4.setViewportView(tableImmoNonMisEnLocation);
		
		
		panelSliderDebord.add(panelListeLocataire, "name_783864985953800");
		panelListeLocataire.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane_5 = new JScrollPane();
		panelListeLocataire.add(scrollPane_5, BorderLayout.CENTER);
		
		PaneTabImmo.getTableImmobilier().setFont(new Font("Rockwell",Font.BOLD,14));
		PaneTabImmo.getTableImmobilier().setGridColor(SystemColor.desktop);
		PaneTabImmo.getTableImmobilier().setShowGrid(false);
		PaneTabImmo.getTableImmobilier().getTableHeader().setBackground(new Color(14, 139, 218));
		
		TableGestLocataire = new JTable();
		
		TableGestLocataire.setFont(new Font("Rockwell", Font.BOLD,14));
		TableGestLocataire.setGridColor(SystemColor.desktop);
		TableGestLocataire.setShowGrid(false);
		TableGestLocataire.getTableHeader().setBackground(new Color(229, 48, 90));
		TableGestLocataire.setFont(new Font("Rockwell", Font.BOLD, 13));
		
		TableGestLocataire.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Identifiant", "Nom Locataire", "Pr\u00E9nom Locataire", "Num\u00E9ro Pi\u00E9ces", "Genre", "Date Naissance", "T\u00E9l\u00E9phone", "Email", "Contrat Location"
			}
		) {
			
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, true, true, true, true, true, true, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane_5.setViewportView(TableGestLocataire);
		
		
		panelSliderDebord.add(panelModificationLocat, "name_802605833305700");
		panelModificationLocat.setLayout(null);
		
		
		panelModif.setBounds(363, 0, 349, 537);
		panelModificationLocat.add(panelModif);
		panelModif.setLayout(null);
		
		textFieldModifNomLocat = new JTextField();
		textFieldModifNomLocat.setFont(new Font("Rockwell", Font.BOLD, 13));
		textFieldModifNomLocat.setForeground(Color.WHITE);
		textFieldModifNomLocat.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldModifNomLocat.setBorder(null);
		textFieldModifNomLocat.setBounds(39, 30, 165, 26);
		textFieldModifNomLocat.setBackground(new Color(22, 64, 114));
		panelModif.add(textFieldModifNomLocat);
		textFieldModifNomLocat.setColumns(10);
		
		textFieldModifPrenom = new JTextField();
		textFieldModifPrenom.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldModifPrenom.setForeground(Color.WHITE);
		textFieldModifPrenom.setFont(new Font("Rockwell", Font.BOLD, 13));
		textFieldModifPrenom.setBorder(null);
		textFieldModifPrenom.setBounds(39, 100, 165, 26);
		textFieldModifPrenom.setBackground(new Color(22, 64, 114));
		panelModif.add(textFieldModifPrenom);
		textFieldModifPrenom.setColumns(10);
		
		textFieldModifNumPieces = new JTextField();
		textFieldModifNumPieces.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldModifNumPieces.setFont(new Font("Rockwell", Font.BOLD, 13));
		textFieldModifNumPieces.setForeground(Color.WHITE);
		textFieldModifNumPieces.setBorder(null);
		textFieldModifNumPieces.setBounds(39, 180, 165, 26);
		textFieldModifNumPieces.setBackground(new Color(22, 64, 114));
		panelModif.add(textFieldModifNumPieces);
		textFieldModifNumPieces.setColumns(10);
		
		textFieldModifGenre = new JTextField();
		textFieldModifGenre.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldModifGenre.setFont(new Font("Rockwell", Font.BOLD, 13));
		textFieldModifGenre.setForeground(Color.WHITE);
		textFieldModifGenre.setBorder(null);
		textFieldModifGenre.setBounds(39, 255, 165, 26);
		textFieldModifGenre.setBackground(new Color(22, 64, 114));
		panelModif.add(textFieldModifGenre);
		textFieldModifGenre.setColumns(10);
		
		textFieldModifDate = new JTextField();
		textFieldModifDate.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldModifDate.setFont(new Font("Rockwell", Font.BOLD, 13));
		textFieldModifDate.setForeground(Color.WHITE);
		textFieldModifDate.setBorder(null);
		textFieldModifDate.setBounds(39, 330, 165, 26);
		textFieldModifDate.setBackground(new Color(22, 64, 114));
		panelModif.add(textFieldModifDate);
		textFieldModifDate.setColumns(10);
		
		textFieldModifTelph = new JTextField();
		textFieldModifTelph.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldModifTelph.setForeground(Color.WHITE);
		textFieldModifTelph.setFont(new Font("Rockwell", Font.BOLD, 13));
		textFieldModifTelph.setBorder(null);
		textFieldModifTelph.setBounds(39, 400, 165, 26);
		textFieldModifTelph.setBackground(new Color(22, 64, 114));
		panelModif.add(textFieldModifTelph);
		textFieldModifTelph.setColumns(10);
		
		textFieldModifEmail = new JTextField();
		textFieldModifEmail.setForeground(Color.WHITE);
		textFieldModifEmail.setFont(new Font("Rockwell", Font.BOLD, 13));
		textFieldModifEmail.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldModifEmail.setBorder(null);
		textFieldModifEmail.setBounds(39, 470, 165, 26);
		textFieldModifEmail.setBackground(new Color(22, 64, 114));
		panelModif.add(textFieldModifEmail);
		textFieldModifEmail.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nom");
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.white);
		lblNewLabel.setBounds(219, 33, 96, 20);
		panelModif.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Prenom");
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.white);
		lblNewLabel_1.setBounds(219, 103, 96, 20);
		panelModif.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("N\u00B0 Pieces");
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.white);
		lblNewLabel_2.setBounds(219, 183, 96, 20);
		panelModif.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Genre");
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.white);
		lblNewLabel_3.setBounds(219, 252, 96, 26);
		panelModif.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Naissance");
		lblNewLabel_4.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setForeground(Color.white);
		lblNewLabel_4.setBounds(219, 333, 96, 20);
		panelModif.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Telephone");
		lblNewLabel_5.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setForeground(Color.white);
		lblNewLabel_5.setBounds(219, 403, 96, 20);
		panelModif.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Email");
		lblNewLabel_6.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setForeground(Color.white);
		lblNewLabel_6.setBounds(231, 473, 84, 20);
		panelModif.add(lblNewLabel_6);
		
		JSeparator separator = new JSeparator();
		separator.setBorder(new LineBorder(Color.WHITE, 3));
		separator.setBounds(39, 58, 165, 2);
		panelModif.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBorder(new LineBorder(Color.WHITE, 3));
		separator_1.setBounds(39, 128, 165, 2);
		panelModif.add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBorder(new LineBorder(Color.WHITE, 3));
		separator_2.setBounds(39, 207, 165, 2);
		panelModif.add(separator_2);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBorder(new LineBorder(Color.WHITE, 3));
		separator_3.setBounds(39, 282, 165, 2);
		panelModif.add(separator_3);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBorder(new LineBorder(Color.WHITE, 3));
		separator_4.setBounds(39, 358, 165, 2);
		panelModif.add(separator_4);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setBorder(new LineBorder(Color.WHITE, 3));
		separator_5.setBounds(39, 427, 165, 2);
		panelModif.add(separator_5);
		
		JSeparator separator_6 = new JSeparator();
		separator_6.setBorder(new LineBorder(Color.WHITE, 3));
		separator_6.setBounds(40, 497, 164, 2);
		panelModif.add(separator_6);
		
		textFieldId = new JTextField();
		textFieldId.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldId.setBorder(null);
		textFieldId.setEditable(false);
		textFieldId.setForeground(Color.WHITE);
		textFieldId.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldId.setBounds(241, 1, 123, 24);
		textFieldId.setBackground(new Color(22, 64, 114));
		panelModificationLocat.add(textFieldId);
		textFieldId.setColumns(10);
		
		lblNewLabel_7 = new JLabel("Identifiant");
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(116, 5, 123, 20);
		panelModificationLocat.add(lblNewLabel_7);
		
		
		btnModifier.setBackground(new Color(220, 20, 60));
		btnModifier.setForeground(Color.WHITE);
		btnModifier.setFont(new Font("Rockwell", Font.BOLD, 17));
		btnModifier.setBounds(125, 215, 115, 115);
		panelModificationLocat.add(btnModifier);
		
		
		panelSliderDebord.add(panelModifUserPane, "name_841021203958000");
		panelModifUserPane.setLayout(null);
		
		
		panelUserModif.setBounds(94, 49, 618, 396);
		panelModifUserPane.add(panelUserModif);
		panelUserModif.setLayout(null);
		
		textFieldIdUser = new JTextField();
		textFieldIdUser.setForeground(Color.WHITE);
		textFieldIdUser.setEditable(false);
		textFieldIdUser.setFont(new Font("Rockwell", Font.BOLD, 15));
		textFieldIdUser.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldIdUser.setBorder(null);
		textFieldIdUser.setBackground(new Color(9, 37, 64));
		textFieldIdUser.setBounds(231, 16, 146, 26);
		panelUserModif.add(textFieldIdUser);
		textFieldIdUser.setColumns(10);
		
		textFieldUsername = new JTextField();
		textFieldUsername.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldUsername.setForeground(Color.WHITE);
		textFieldUsername.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldUsername.setBorder(null);
		textFieldUsername.setText("");
		textFieldUsername.setBounds(100, 79, 146, 26);
		textFieldUsername.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldUsername);
		textFieldUsername.setColumns(10);
		
		textFieldUserLastname = new JTextField();
		textFieldUserLastname.setForeground(Color.WHITE);
		textFieldUserLastname.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldUserLastname.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldUserLastname.setBorder(null);
		textFieldUserLastname.setBounds(100, 152, 146, 26);
		textFieldUserLastname.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldUserLastname);
		textFieldUserLastname.setColumns(10);
		
		textFieldUserLogin = new JTextField();
		textFieldUserLogin.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldUserLogin.setForeground(Color.WHITE);
		textFieldUserLogin.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldUserLogin.setBorder(null);
		textFieldUserLogin.setBounds(100, 222, 146, 26);
		textFieldUserLogin.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldUserLogin);
		textFieldUserLogin.setColumns(10);
		
		textFieldUserMdp = new JTextField();
		textFieldUserMdp.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldUserMdp.setForeground(Color.WHITE);
		textFieldUserMdp.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldUserMdp.setBorder(null);
		textFieldUserMdp.setBounds(100, 294, 146, 26);
		textFieldUserMdp.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldUserMdp);
		textFieldUserMdp.setColumns(10);
		
		textFieldUserAdress = new JTextField();
		textFieldUserAdress.setForeground(Color.WHITE);
		textFieldUserAdress.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldUserAdress.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldUserAdress.setBorder(null);
		textFieldUserAdress.setBounds(387, 79, 146, 26);
		textFieldUserAdress.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldUserAdress);
		textFieldUserAdress.setColumns(10);
		
		textFieldUserNaissance = new JTextField();
		textFieldUserNaissance.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldUserNaissance.setForeground(Color.WHITE);
		textFieldUserNaissance.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldUserNaissance.setBorder(null);
		textFieldUserNaissance.setBounds(390, 152, 142, 26);
		textFieldUserNaissance.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldUserNaissance);
		textFieldUserNaissance.setColumns(10);
		
		textFieldNumTelphUser = new JTextField();
		textFieldNumTelphUser.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldNumTelphUser.setForeground(Color.WHITE);
		textFieldNumTelphUser.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNumTelphUser.setBorder(null);
		textFieldNumTelphUser.setBounds(387, 222, 146, 26);
		textFieldNumTelphUser.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldNumTelphUser);
		textFieldNumTelphUser.setColumns(10);
		
		textFieldUserEmail = new JTextField();
		textFieldUserEmail.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldUserEmail.setForeground(Color.WHITE);
		textFieldUserEmail.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldUserEmail.setBorder(null);
		textFieldUserEmail.setBounds(387, 292, 146, 26);
		textFieldUserEmail.setBackground(new Color(9, 37, 64));
		panelUserModif.add(textFieldUserEmail);
		textFieldUserEmail.setColumns(10);
		
		JSeparator separator_7 = new JSeparator();
		separator_7.setBorder(new LineBorder(Color.WHITE, 3));
		separator_7.setBounds(101, 107, 145, 2);
		panelUserModif.add(separator_7);
		
		JSeparator separator_8 = new JSeparator();
		separator_8.setBorder(new LineBorder(Color.WHITE, 3));
		separator_8.setBounds(100, 180, 146, 2);
		panelUserModif.add(separator_8);
		
		JSeparator separator_9 = new JSeparator();
		separator_9.setBorder(new LineBorder(Color.WHITE, 3));
		separator_9.setBounds(100, 250, 146, 2);
		panelUserModif.add(separator_9);
		
		JSeparator separator_10 = new JSeparator();
		separator_10.setBorder(new LineBorder(Color.WHITE, 3));
		separator_10.setBounds(101, 322, 145, 2);
		panelUserModif.add(separator_10);
		
		JSeparator separator_11 = new JSeparator();
		separator_11.setBorder(new LineBorder(Color.WHITE, 3));
		separator_11.setBounds(390, 107, 142, 2);
		panelUserModif.add(separator_11);
		
		JSeparator separator_12 = new JSeparator();
		separator_12.setBorder(new LineBorder(Color.WHITE, 3));
		separator_12.setBounds(390, 180, 142, 2);
		panelUserModif.add(separator_12);
		
		JSeparator separator_13 = new JSeparator();
		separator_13.setBorder(new LineBorder(Color.WHITE, 3));
		separator_13.setBounds(386, 250, 146, 2);
		panelUserModif.add(separator_13);
		
		JSeparator separator_14 = new JSeparator();
		separator_14.setBorder(new LineBorder(Color.WHITE, 3));
		separator_14.setBounds(387, 320, 146, 2);
		panelUserModif.add(separator_14);
		
		JSeparator separator_15 = new JSeparator();
		separator_15.setBorder(new LineBorder(Color.WHITE, 3));
		separator_15.setBounds(232, 44, 145, 2);
		panelUserModif.add(separator_15);
		
		JLabel lblNewLabel_8 = new JLabel("Nom");
		lblNewLabel_8.setForeground(Color.WHITE);
		lblNewLabel_8.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setBounds(0, 84, 85, 20);
		panelUserModif.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Prenom");
		lblNewLabel_9.setForeground(Color.WHITE);
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_9.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_9.setBounds(0, 157, 85, 20);
		panelUserModif.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Login");
		lblNewLabel_10.setForeground(Color.WHITE);
		lblNewLabel_10.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_10.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_10.setBounds(0, 227, 85, 20);
		panelUserModif.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Password");
		lblNewLabel_11.setForeground(Color.WHITE);
		lblNewLabel_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_11.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_11.setBounds(0, 299, 97, 20);
		panelUserModif.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Adresse");
		lblNewLabel_12.setForeground(Color.WHITE);
		lblNewLabel_12.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_12.setBounds(294, 84, 69, 20);
		panelUserModif.add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("DateNaissance");
		lblNewLabel_13.setForeground(Color.WHITE);
		lblNewLabel_13.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_13.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_13.setBounds(276, 155, 114, 20);
		panelUserModif.add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("Telephone");
		lblNewLabel_14.setForeground(Color.WHITE);
		lblNewLabel_14.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_14.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_14.setBounds(278, 228, 99, 20);
		panelUserModif.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("Email");
		lblNewLabel_15.setForeground(Color.WHITE);
		lblNewLabel_15.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_15.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_15.setBounds(278, 297, 94, 20);
		panelUserModif.add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("Identifiant");
		lblNewLabel_16.setForeground(Color.WHITE);
		lblNewLabel_16.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_16.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_16.setBounds(114, 21, 114, 20);
		panelUserModif.add(lblNewLabel_16);
		
		
		btnModifUser.setBounds(253, 456, 210, 29);
		panelModifUserPane.add(btnModifUser);
		btnModifUser.setFont(new Font("Rockwell", Font.BOLD, 16));
		
		JLabel RetourPaneAdmin = new JLabel("");
		RetourPaneAdmin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				panelSliderDebord.nextPanel(1, panelAdminTab, JPanelSlider.left);
				btnModifImmoS.setVisible(true);
			}
		});
		RetourPaneAdmin.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\backspace_60px.png"));
		RetourPaneAdmin.setBounds(8, 5, 65, 45);
		panelModifUserPane.add(RetourPaneAdmin);
		
		panelModifImmo = new JPanel();
		panelModifImmo.setBackground(new Color(9, 37, 64));
		panelSliderDebord.add(panelModifImmo, "name_866090524362800");
		panelModifImmo.setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(285, 0, 427, 524);
		panelModifImmo.add(panel);
		panel.setLayout(null);
		
		textFieldIdImmo = new JTextField();
		textFieldIdImmo.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldIdImmo.setBackground(Color.BLACK);
		textFieldIdImmo.setEditable(false);
		textFieldIdImmo.setBorder(null);
		textFieldIdImmo.setForeground(Color.WHITE);
		textFieldIdImmo.setFont(new Font("Rockwell", Font.BOLD, 15));
		textFieldIdImmo.setBounds(195, 28, 172, 26);
		panel.add(textFieldIdImmo);
		textFieldIdImmo.setColumns(10);
		
		textFieldAdressImmo = new JTextField();
		textFieldAdressImmo.setBackground(Color.BLACK);
		textFieldAdressImmo.setForeground(Color.WHITE);
		textFieldAdressImmo.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldAdressImmo.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldAdressImmo.setBorder(null);
		textFieldAdressImmo.setBounds(195, 102, 172, 26);
		panel.add(textFieldAdressImmo);
		textFieldAdressImmo.setColumns(10);
		
		textFieldNbrePiece = new JTextField();
		textFieldNbrePiece.setBackground(Color.BLACK);
		textFieldNbrePiece.setForeground(Color.WHITE);
		textFieldNbrePiece.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNbrePiece.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldNbrePiece.setBorder(null);
		textFieldNbrePiece.setBounds(195, 178, 172, 26);
		panel.add(textFieldNbrePiece);
		textFieldNbrePiece.setColumns(10);
		
		textFieldMontantImmo = new JTextField();
		textFieldMontantImmo.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldMontantImmo.setBackground(Color.BLACK);
		textFieldMontantImmo.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldMontantImmo.setForeground(Color.WHITE);
		textFieldMontantImmo.setBorder(null);
		textFieldMontantImmo.setBounds(195, 260, 172, 26);
		panel.add(textFieldMontantImmo);
		textFieldMontantImmo.setColumns(10);
		
		textFieldLoyerImmo = new JTextField();
		textFieldLoyerImmo.setBackground(Color.BLACK);
		textFieldLoyerImmo.setForeground(Color.WHITE);
		textFieldLoyerImmo.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldLoyerImmo.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldLoyerImmo.setBorder(null);
		textFieldLoyerImmo.setBounds(195, 340, 172, 26);
		panel.add(textFieldLoyerImmo);
		textFieldLoyerImmo.setColumns(10);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBorder(null);
		scrollPane_6.setBounds(169, 405, 198, 71);
		panel.add(scrollPane_6);
		
		
		textAreaDetaisImmo.setBackground(Color.BLACK);
		textAreaDetaisImmo.setFont(new Font("Rockwell", Font.BOLD, 12));
		textAreaDetaisImmo.setForeground(Color.WHITE);
		textAreaDetaisImmo.setBorder(null);
		scrollPane_6.setViewportView(textAreaDetaisImmo);
		
		JLabel lblNewLabel_17 = new JLabel("Identifiant");
		lblNewLabel_17.setForeground(Color.WHITE);
		lblNewLabel_17.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_17.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_17.setBounds(47, 31, 112, 20);
		panel.add(lblNewLabel_17);
		
		JSeparator separator_16 = new JSeparator();
		separator_16.setBorder(new LineBorder(Color.WHITE, 3));
		separator_16.setBounds(195, 56, 172, 2);
		panel.add(separator_16);
		
		JSeparator separator_17 = new JSeparator();
		separator_17.setBorder(new LineBorder(Color.WHITE, 3));
		separator_17.setBounds(195, 131, 172, 2);
		panel.add(separator_17);
		
		JSeparator separator_18 = new JSeparator();
		separator_18.setBorder(new LineBorder(Color.WHITE, 3));
		separator_18.setBounds(195, 206, 172, 2);
		panel.add(separator_18);
		
		JSeparator separator_19 = new JSeparator();
		separator_19.setBorder(new LineBorder(Color.WHITE, 3));
		separator_19.setBounds(195, 288, 172, 2);
		panel.add(separator_19);
		
		JSeparator separator_20 = new JSeparator();
		separator_20.setBorder(new LineBorder(Color.WHITE, 3));
		separator_20.setBounds(195, 368, 172, 2);
		panel.add(separator_20);
		
		JSeparator separator_21 = new JSeparator();
		separator_21.setBorder(new LineBorder(Color.WHITE, 3));
		separator_21.setBounds(171, 479, 196, 2);
		panel.add(separator_21);
		
		JLabel lblNewLabel_18 = new JLabel("Adresse Immobilier");
		lblNewLabel_18.setForeground(Color.WHITE);
		lblNewLabel_18.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_18.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_18.setBounds(15, 104, 165, 20);
		panel.add(lblNewLabel_18);
		
		JLabel lblNewLabel_19 = new JLabel("Nombre Pieces");
		lblNewLabel_19.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_19.setForeground(Color.WHITE);
		lblNewLabel_19.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_19.setBounds(33, 184, 126, 20);
		panel.add(lblNewLabel_19);
		
		
		PaneTabImmo.getTableImmobilier().setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Identifiant", "Adresse Immobilier", "Nombre Pieces", "Montant", "Loyer", "details", "Statut"
			}
		) {
			
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JLabel lblNewLabel_20 = new JLabel("Montant");
		lblNewLabel_20.setForeground(Color.WHITE);
		lblNewLabel_20.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_20.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_20.setBounds(47, 262, 100, 20);
		panel.add(lblNewLabel_20);
		
		JLabel lblNewLabel_21 = new JLabel("Loyer");
		lblNewLabel_21.setForeground(Color.WHITE);
		lblNewLabel_21.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_21.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_21.setBounds(47, 347, 100, 20);
		panel.add(lblNewLabel_21);
		
		JLabel lblNewLabel_22 = new JLabel("Details");
		lblNewLabel_22.setForeground(Color.WHITE);
		lblNewLabel_22.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_22.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_22.setBounds(47, 433, 100, 20);
		panel.add(lblNewLabel_22);
		
		
		btnModifImmoS.setForeground(Color.WHITE);
		btnModifImmoS.setFont(new Font("Rockwell", Font.BOLD, 16));
		btnModifImmoS.setBounds(127, 346, 93, 93);
		panelModifImmo.add(btnModifImmoS);
		
		JLabel lblNewLabel_23 = new JLabel("");
		lblNewLabel_23.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				panelSliderDebord.nextPanel(2, panelAdminTab, JPanelSlider.left);
				btnModifImmoS.setVisible(false);
			}
		});
		lblNewLabel_23.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\backspace_60px.png"));
		lblNewLabel_23.setBounds(10, 5, 66, 44);
		panelModifImmo.add(lblNewLabel_23);
		
		
		panelSliderDebord.add(panelModifPaiement, "name_928695618631700");
		panelModifPaiement.setLayout(null);
		
		
		panelPaiModifie.setBounds(0, 74, 712, 381);
		panelModifPaiement.add(panelPaiModifie);
		panelPaiModifie.setLayout(null);
		
		textFieldIdPaiement = new JTextField();
		textFieldIdPaiement.setForeground(Color.WHITE);
		textFieldIdPaiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldIdPaiement.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldIdPaiement.setEditable(false);
		textFieldIdPaiement.setBorder(null);
		textFieldIdPaiement.setBackground(new Color(9, 37, 64));
		textFieldIdPaiement.setBounds(268, 5, 157, 26);
		panelPaiModifie.add(textFieldIdPaiement);
		textFieldIdPaiement.setColumns(10);
		
		textFieldCautionPaiement = new JTextField();
		textFieldCautionPaiement.setForeground(Color.WHITE);
		textFieldCautionPaiement.setFont(new Font("Rockwell", Font.BOLD, 16));
		textFieldCautionPaiement.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldCautionPaiement.setBorder(null);
		textFieldCautionPaiement.setBounds(101, 75, 146, 26);
		textFieldCautionPaiement.setBackground(new Color(9, 37, 64));
		panelPaiModifie.add(textFieldCautionPaiement);
		textFieldCautionPaiement.setColumns(10);
		
		textFieldNumPiecesPaiement = new JTextField();
		textFieldNumPiecesPaiement.setForeground(Color.WHITE);
		textFieldNumPiecesPaiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldNumPiecesPaiement.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNumPiecesPaiement.setBorder(null);
		textFieldNumPiecesPaiement.setBounds(268, 150, 157, 26);
		textFieldNumPiecesPaiement.setBackground(new Color(9, 37, 64));
		panelPaiModifie.add(textFieldNumPiecesPaiement);
		textFieldNumPiecesPaiement.setColumns(10);
		
		textFieldTranche3Paiement = new JTextField();
		textFieldTranche3Paiement.setForeground(Color.WHITE);
		textFieldTranche3Paiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldTranche3Paiement.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldTranche3Paiement.setBorder(null);
		textFieldTranche3Paiement.setBounds(451, 309, 146, 26);
		textFieldTranche3Paiement.setBackground(new Color(9, 37, 64));
		panelPaiModifie.add(textFieldTranche3Paiement);
		textFieldTranche3Paiement.setColumns(10);
		
		textFieldMntantJrnPaiemnt = new JTextField();
		textFieldMntantJrnPaiemnt.setForeground(Color.WHITE);
		textFieldMntantJrnPaiemnt.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldMntantJrnPaiemnt.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldMntantJrnPaiemnt.setBorder(null);
		textFieldMntantJrnPaiemnt.setBounds(101, 309, 146, 26);
		textFieldMntantJrnPaiemnt.setBackground(new Color(9, 37, 64));
		panelPaiModifie.add(textFieldMntantJrnPaiemnt);
		textFieldMntantJrnPaiemnt.setColumns(10);
		
		textFieldTranche1Paiement = new JTextField();
		textFieldTranche1Paiement.setForeground(Color.WHITE);
		textFieldTranche1Paiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldTranche1Paiement.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldTranche1Paiement.setBorder(null);
		textFieldTranche1Paiement.setBounds(451, 75, 146, 26);
		textFieldTranche1Paiement.setBackground(new Color(9, 37, 64));
		panelPaiModifie.add(textFieldTranche1Paiement);
		textFieldTranche1Paiement.setColumns(10);
		
		textFieldLoyerPaiement = new JTextField();
		textFieldLoyerPaiement.setForeground(Color.WHITE);
		textFieldLoyerPaiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldLoyerPaiement.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldLoyerPaiement.setBorder(null);
		textFieldLoyerPaiement.setBounds(101, 200, 146, 26);
		textFieldLoyerPaiement.setBackground(new Color(9, 37, 64));
		panelPaiModifie.add(textFieldLoyerPaiement);
		textFieldLoyerPaiement.setColumns(10);
		
		textFieldTranche2Paiement = new JTextField();
		textFieldTranche2Paiement.setForeground(Color.WHITE);
		textFieldTranche2Paiement.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldTranche2Paiement.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldTranche2Paiement.setBorder(null);
		textFieldTranche2Paiement.setBounds(451, 200, 146, 26);
		textFieldTranche2Paiement.setBackground(new Color(9, 37, 64));
		panelPaiModifie.add(textFieldTranche2Paiement);
		textFieldTranche2Paiement.setColumns(10);
		
		JLabel lblNewLabel_24 = new JLabel("Identifiant");
		lblNewLabel_24.setForeground(Color.WHITE);
		lblNewLabel_24.setHorizontalAlignment(SwingConstants.CENTER);
		
		lblNewLabel_24.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_24.setBounds(158, 8, 90, 20);
		panelPaiModifie.add(lblNewLabel_24);
		
		JLabel lblNewLabel_25 = new JLabel("Caution");
		lblNewLabel_25.setForeground(Color.WHITE);
		lblNewLabel_25.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_25.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_25.setBounds(15, 78, 69, 20);
		panelPaiModifie.add(lblNewLabel_25);
		
		JLabel lblNewLabel_26 = new JLabel("N\u00B0 Pi\u00E8ce");
		lblNewLabel_26.setForeground(Color.WHITE);
		lblNewLabel_26.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_26.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_26.setBounds(268, 125, 146, 20);
		panelPaiModifie.add(lblNewLabel_26);
		
		JLabel lblNewLabel_27 = new JLabel("Tranche 1");
		lblNewLabel_27.setForeground(Color.WHITE);
		lblNewLabel_27.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_27.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_27.setBounds(612, 78, 85, 20);
		panelPaiModifie.add(lblNewLabel_27);
		
		JLabel lblNewLabel_28 = new JLabel("Loyer");
		lblNewLabel_28.setForeground(Color.WHITE);
		lblNewLabel_28.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_28.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_28.setBounds(17, 203, 69, 20);
		panelPaiModifie.add(lblNewLabel_28);
		
		JLabel lblNewLabel_29 = new JLabel("Montant Jrn");
		lblNewLabel_29.setForeground(Color.WHITE);
		lblNewLabel_29.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_29.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_29.setBounds(0, 312, 99, 20);
		panelPaiModifie.add(lblNewLabel_29);
		
		JLabel lblNewLabel_30 = new JLabel("Tranche 2");
		lblNewLabel_30.setForeground(Color.WHITE);
		lblNewLabel_30.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_30.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_30.setBounds(612, 203, 85, 20);
		panelPaiModifie.add(lblNewLabel_30);
		
		JLabel lblNewLabel_31 = new JLabel("Tranche 3");
		lblNewLabel_31.setForeground(Color.WHITE);
		lblNewLabel_31.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_31.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_31.setBounds(612, 312, 85, 20);
		panelPaiModifie.add(lblNewLabel_31);
		
		JSeparator separator_22 = new JSeparator();
		separator_22.setBorder(new LineBorder(Color.WHITE, 3));
		separator_22.setBounds(270, 32, 153, 2);
		panelPaiModifie.add(separator_22);
		
		JSeparator separator_23 = new JSeparator();
		separator_23.setBorder(new LineBorder(Color.WHITE, 3));
		separator_23.setBounds(103, 103, 143, 2);
		panelPaiModifie.add(separator_23);
		
		JSeparator separator_24 = new JSeparator();
		separator_24.setBorder(new LineBorder(Color.WHITE, 3));
		separator_24.setBounds(453, 104, 146, 2);
		panelPaiModifie.add(separator_24);
		
		JSeparator separator_25 = new JSeparator();
		separator_25.setBorder(new LineBorder(Color.WHITE, 3));
		separator_25.setBounds(270, 179, 152, 2);
		panelPaiModifie.add(separator_25);
		
		JSeparator separator_26 = new JSeparator();
		separator_26.setBorder(new LineBorder(Color.WHITE, 3));
		separator_26.setBounds(100, 227, 145, 2);
		panelPaiModifie.add(separator_26);
		
		JSeparator separator_27 = new JSeparator();
		separator_27.setBorder(new LineBorder(Color.WHITE, 3));
		separator_27.setBounds(453, 228, 146, 2);
		panelPaiModifie.add(separator_27);
		
		JSeparator separator_28 = new JSeparator();
		separator_28.setBorder(new LineBorder(Color.WHITE, 3));
		separator_28.setBounds(101, 337, 146, 2);
		panelPaiModifie.add(separator_28);
		
		JSeparator separator_29 = new JSeparator();
		separator_29.setBorder(new LineBorder(Color.WHITE, 3));
		separator_29.setBounds(453, 337, 143, 2);
		panelPaiModifie.add(separator_29);
		
		
		btnModifPaye.setBackground(new Color(128, 0, 0));
		btnModifPaye.setForeground(Color.WHITE);
		btnModifPaye.setFont(new Font("Rockwell", Font.BOLD, 14));
		btnModifPaye.setBounds(299, 241, 93, 93);
		panelPaiModifie.add(btnModifPaye);
		
		panel_AffichePaiement = new JPanel();
		panel_AffichePaiement.setBackground(Color.WHITE);
		panel_AffichePaiement.setBounds(0, 0, 712, 40);
		panelModifPaiement.add(panel_AffichePaiement);
		
		lblNewLabel_36 = new JLabel("Modification Des Paiements");
		lblNewLabel_36.setForeground(new Color(4, 26, 76));
		lblNewLabel_36.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_36.setFont(new Font("Rockwell", Font.BOLD, 22));
		panel_AffichePaiement.add(lblNewLabel_36);
		
		JLabel lblNewLabel_37 = new JLabel("");
		lblNewLabel_37.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			getPanelSliderDebord().nextPanel(1, getPanelTabPaiement(), JPanelSlider.right);
			
			}
		});
		lblNewLabel_37.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_37.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\backspace_32px.png"));
		lblNewLabel_37.setBounds(0, 46, 45, 25);
		panelModifPaiement.add(lblNewLabel_37);
		
		panelTabPaiement = new JPanel();
		panelTabPaiement.setBackground(new Color(22, 64, 114));
		panelSliderDebord.add(panelTabPaiement, "name_933045792560100");
		
		panelTabPaiement.setLayout(null);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(42, 88, 626, 365);
		panelTabPaiement.add(scrollPane_7);
		
		tablePaiementGestion = new JTable();
		tablePaiementGestion.setSelectionBackground(new Color(0, 139, 139));
		tablePaiementGestion.setShowHorizontalLines(false);
		tablePaiementGestion.setSelectionForeground(Color.BLACK);
		tablePaiementGestion.setFont(new Font("Rockwell", Font.BOLD,14));
		tablePaiementGestion.setGridColor(SystemColor.desktop);
		tablePaiementGestion.getTableHeader().setBackground(new Color(3, 118, 114));
		
		tablePaiementGestion.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Identifiant", "N\u00B0 Pi\u00E8ces", "Caution", "Loyer", "Montant Journalier", "Tranche 1", "Tranche 3", "Tranche 3"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane_7.setViewportView(tablePaiementGestion);
		
		JPanel panelAffiche = new JPanel();
		panelAffiche.setBackground(Color.WHITE);
		panelAffiche.setBounds(0, 0, 712, 35);
		panelTabPaiement.add(panelAffiche);
		
		JLabel lblNewLabel_32 = new JLabel("Table Des Paiements");
		lblNewLabel_32.setFont(new Font("Rockwell", Font.BOLD, 22));
		lblNewLabel_32.setForeground(new Color(0, 128, 128));
		lblNewLabel_32.setHorizontalAlignment(SwingConstants.CENTER);
		panelAffiche.add(lblNewLabel_32);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.BLACK);
		panel_4.setBounds(132, 22, 235, 93);
		panelRacine.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel LabelGifTimeHours = new JLabel("");
	LabelGifTimeHours.setSize(new Dimension(235, 93));
		
		LabelGifTimeHours.setSize(new Dimension(233, 94));
		LabelGifTimeHours.setForeground(Color.WHITE);
		LabelGifTimeHours.setLocation(0, 0);
		LabelGifTimeHours.setSize(235, 92);
		LabelGifTimeHours.setHorizontalAlignment(SwingConstants.CENTER);
		LabelGifTimeHours.setIcon(new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\AppIMage.jpg"));
		LabelGifTimeHours.setBounds(0, 1, 233, 65);
		panel_4.add(LabelGifTimeHours);
		
		lblHours = new JLabel("New label");
		lblHours.setFont(new Font("Stencil", Font.BOLD, 18));
		lblHours.setForeground(new Color(0, 139, 139));
		lblHours.setHorizontalAlignment(SwingConstants.CENTER);
		lblHours.setBounds(0, 70, 220, 20);
		panel_4.add(lblHours);
		
		MonHeur();
		
		
		
		MonCollapse();
		this.setVisible(true);	
	}
	

	
	void MonHeur()
	{
		new Timer (0,new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				Date maDate = new Date();
				SimpleDateFormat FormatDat = new  SimpleDateFormat("dd/MM/YY  hh:mm:ss a");
				lblHours.setText(FormatDat.format(maDate));
			}
			
		}).start();
	}
	
	
	private void SousMenus() {
		
		if(panelSousMenu.isVisible()==false ) {
			
			panelSousMenu.setVisible(true);
		}
		else {
			panelSousMenu.setVisible(false);
			
		}
		
		
	}
	
	private void SousMenus_2() {
		
		if( PanelSousMenu2Admin.isVisible()==false) {
			
			PanelSousMenu2Admin.setVisible(true);
		}
		else {
			PanelSousMenu2Admin.setVisible(false);
		}
			
	}
	
	private void MonCollapse() {
		
		collapsiblePane.setLayout(new BorderLayout());
		collapsiblePane.add(PaneTabImmo,BorderLayout.CENTER);
		btnCollapse.addActionListener(collapsiblePane.getActionMap().get(JXCollapsiblePane.TOGGLE_ACTION));
		
		 panelAdminTab.addComponentListener(new ComponentAdapter() {
			  	@Override
			  	public void componentResized(ComponentEvent e) {
			  		
			  		
			  		
			  		if(collapsiblePane.isCollapsed())
					{
			  			PaneTabImmo.setPreferredSize(panelAdminTab.getSize());
			  			
					}
					else {
							btnCollapse.doClick();
							 
						int width = panelAdminTab.getWidth();
						int height = panelAdminTab.getHeight()-btnCollapse.getHeight(); 
						PaneTabImmo.setPreferredSize(new Dimension(width,height));
						
						
					}
			  	}
			});
	}
	
	
	
	
	
	
	
	
	
	
	
	
	public JPanel getPanelTabPaiement() {
		return panelTabPaiement;
	}


	public void setPanelTabPaiement(JPanel panelTabPaiement) {
		this.panelTabPaiement = panelTabPaiement;
	}


	public JTable getTablePaiementGestion() {
		return tablePaiementGestion;
	}


	public void setTablePaiementGestion(JTable tablePaiementGestion) {
		this.tablePaiementGestion = tablePaiementGestion;
	}


	public JButton getBtnModifImmoS() {
		return btnModifImmoS;
	}


	public void setBtnModifImmoS(JButton btnModifImmoS) {
		this.btnModifImmoS = btnModifImmoS;
	}


	public JTextField getTextFieldIdPaiement() {
		return textFieldIdPaiement;
	}


	public void setTextFieldIdPaiement(JTextField textFieldIdPaiement) {
		this.textFieldIdPaiement = textFieldIdPaiement;
	}


	public JTextField getTextFieldCautionPaiement() {
		return textFieldCautionPaiement;
	}


	public void setTextFieldCautionPaiement(JTextField textFieldCautionPaiement) {
		this.textFieldCautionPaiement = textFieldCautionPaiement;
	}


	public JTextField getTextFieldNumPiecesPaiement() {
		return textFieldNumPiecesPaiement;
	}


	public void setTextFieldNumPiecesPaiement(JTextField textFieldNumPiecesPaiement) {
		this.textFieldNumPiecesPaiement = textFieldNumPiecesPaiement;
	}


	public JTextField getTextFieldTranche3Paiement() {
		return textFieldTranche3Paiement;
	}


	public void setTextFieldTranche3Paiement(JTextField textFieldTranche3Paiement) {
		this.textFieldTranche3Paiement = textFieldTranche3Paiement;
	}


	public JTextField getTextFieldMntantJrnPaiemnt() {
		return textFieldMntantJrnPaiemnt;
	}


	public void setTextFieldMntantJrnPaiemnt(JTextField textFieldMntantJrnPaiemnt) {
		this.textFieldMntantJrnPaiemnt = textFieldMntantJrnPaiemnt;
	}


	public JTextField getTextFieldTranche1Paiement() {
		return textFieldTranche1Paiement;
	}


	public void setTextFieldTranche1Paiement(JTextField textFieldTranche1Paiement) {
		this.textFieldTranche1Paiement = textFieldTranche1Paiement;
	}


	public JTextField getTextFieldLoyerPaiement() {
		return textFieldLoyerPaiement;
	}


	public void setTextFieldLoyerPaiement(JTextField textFieldLoyerPaiement) {
		this.textFieldLoyerPaiement = textFieldLoyerPaiement;
	}


	public JTextField getTextFieldTranche2Paiement() {
		return textFieldTranche2Paiement;
	}


	public void setTextFieldTranche2Paiement(JTextField textFieldTranche2Paiement) {
		this.textFieldTranche2Paiement = textFieldTranche2Paiement;
	}


	public JPanel getPanelModifPaiement() {
		return panelModifPaiement;
	}


	public void setPanelModifPaiement(JPanel panelModifPaiement) {
		this.panelModifPaiement = panelModifPaiement;
	}


	public JPanel getPanelPaiModifie() {
		return panelPaiModifie;
	}


	public void setPanelPaiModifie(JPanel panelPaiModifie) {
		this.panelPaiModifie = panelPaiModifie;
	}


	public JButton getBtnModifImmo() {
		return btnModifImmoS;
	}


	public void setBtnModifImmo(JButton btnModifImmo) {
		this.btnModifImmoS = btnModifImmo;
	}


	public TableauImmobilier getPaneTabImmo() {
		return PaneTabImmo;
	}


	public void setPaneTabImmo(TableauImmobilier paneTabImmo) {
		PaneTabImmo = paneTabImmo;
	}


	public JPanel getPanelModifImmo() {
		return panelModifImmo;
	}


	public void setPanelModifImmo(JPanel panelModifImmo) {
		this.panelModifImmo = panelModifImmo;
	}


	public JPanel getPanel() {
		return panel;
	}


	public void setPanel(JPanel panel) {
		this.panel = panel;
	}


	public JTextField getTextFieldIdImmo() {
		return textFieldIdImmo;
	}


	public void setTextFieldIdImmo(JTextField textFieldIdImmo) {
		this.textFieldIdImmo = textFieldIdImmo;
	}


	public JTextField getTextFieldAdressImmo() {
		return textFieldAdressImmo;
	}


	public void setTextFieldAdressImmo(JTextField textFieldAdressImmo) {
		this.textFieldAdressImmo = textFieldAdressImmo;
	}


	public JTextField getTextFieldNbrePiece() {
		return textFieldNbrePiece;
	}


	public void setTextFieldNbrePiece(JTextField textFieldNbrePiece) {
		this.textFieldNbrePiece = textFieldNbrePiece;
	}


	public JTextField getTextFieldMontantImmo() {
		return textFieldMontantImmo;
	}


	public void setTextFieldMontantImmo(JTextField textFieldMontantImmo) {
		this.textFieldMontantImmo = textFieldMontantImmo;
	}


	public JTextField getTextFieldLoyerImmo() {
		return textFieldLoyerImmo;
	}


	public void setTextFieldLoyerImmo(JTextField textFieldLoyerImmo) {
		this.textFieldLoyerImmo = textFieldLoyerImmo;
	}


	public JTextArea getTextAreaDetaisImmo() {
		return textAreaDetaisImmo;
	}


	public void setTextAreaDetaisImmo(JTextArea textAreaDetaisImmo) {
		this.textAreaDetaisImmo = textAreaDetaisImmo;
	}


	public JButton getBtnModifAdmin() {
		return btnModifAdmin;
	}


	public void setBtnModifAdmin(JButton btnModifAdmin) {
		this.btnModifAdmin = btnModifAdmin;
	}


	public JButton getBtnModifUser() {
		return btnModifUser;
	}


	public void setBtnModifUser(JButton btnModifUser) {
		this.btnModifUser = btnModifUser;
	}


	public JButton getBtnModifier() {
		return btnModifier;
	}


	public void setBtnModifier(JButton btnModifier) {
		this.btnModifier = btnModifier;
	}


	public JTextField getTextFieldIdUser() {
		return textFieldIdUser;
	}


	public void setTextFieldIdUser(JTextField textFieldIdUser) {
		this.textFieldIdUser = textFieldIdUser;
	}


	public JTextField getTextFieldUsername() {
		return textFieldUsername;
	}


	public void setTextFieldUsername(JTextField textFieldUsername) {
		this.textFieldUsername = textFieldUsername;
	}


	public JTextField getTextFieldUserLastname() {
		return textFieldUserLastname;
	}


	public void setTextFieldUserLastname(JTextField textFieldUserLastname) {
		this.textFieldUserLastname = textFieldUserLastname;
	}


	public JTextField getTextFieldUserLogin() {
		return textFieldUserLogin;
	}


	public void setTextFieldUserLogin(JTextField textFieldUserLogin) {
		this.textFieldUserLogin = textFieldUserLogin;
	}


	public JTextField getTextFieldUserMdp() {
		return textFieldUserMdp;
	}


	public void setTextFieldUserMdp(JTextField textFieldUserMdp) {
		this.textFieldUserMdp = textFieldUserMdp;
	}


	public JTextField getTextFieldUserAdress() {
		return textFieldUserAdress;
	}


	public void setTextFieldUserAdress(JTextField textFieldUserAdress) {
		this.textFieldUserAdress = textFieldUserAdress;
	}


	public JTextField getTextFieldUserNaissance() {
		return textFieldUserNaissance;
	}


	public void setTextFieldUserNaissance(JTextField textFieldUserNaissance) {
		this.textFieldUserNaissance = textFieldUserNaissance;
	}


	public JTextField getTextFieldNumTelphUser() {
		return textFieldNumTelphUser;
	}


	public void setTextFieldNumTelphUser(JTextField textFieldNumTelphUser) {
		this.textFieldNumTelphUser = textFieldNumTelphUser;
	}


	public JTextField getTextFieldUserEmail() {
		return textFieldUserEmail;
	}


	public void setTextFieldUserEmail(JTextField textFieldUserEmail) {
		this.textFieldUserEmail = textFieldUserEmail;
	}


	public JPanel getPanelModifUserPane() {
		return panelModifUserPane;
	}


	public void setPanelModifUserPane(JPanel panelModifUserPane) {
		this.panelModifUserPane = panelModifUserPane;
	}


	public JPanel getPanelUserModif() {
		return panelUserModif;
	}


	public void setPanelUserModif(JPanel panelUserModif) {
		this.panelUserModif = panelUserModif;
	}


	public JTextField getTextFieldId() {
		return textFieldId;
	}


	public void setTextFieldId(JTextField textFieldId) {
		this.textFieldId = textFieldId;
	}


	public JTextField getTextFieldModifNomLocat() {
		return textFieldModifNomLocat;
	}


	public void setTextFieldModifNomLocat(JTextField textFieldModifNomLocat) {
		this.textFieldModifNomLocat = textFieldModifNomLocat;
	}


	public JTextField getTextFieldModifPrenom() {
		return textFieldModifPrenom;
	}


	public void setTextFieldModifPrenom(JTextField textFieldModifPrenom) {
		this.textFieldModifPrenom = textFieldModifPrenom;
	}


	public JTextField getTextFieldModifNumPieces() {
		return textFieldModifNumPieces;
	}


	public void setTextFieldModifNumPieces(JTextField textFieldModifNumPieces) {
		this.textFieldModifNumPieces = textFieldModifNumPieces;
	}


	public JTextField getTextFieldModifGenre() {
		return textFieldModifGenre;
	}


	public void setTextFieldModifGenre(JTextField textFieldModifGenre) {
		this.textFieldModifGenre = textFieldModifGenre;
	}


	public JTextField getTextFieldModifDate() {
		return textFieldModifDate;
	}


	public void setTextFieldModifDate(JTextField textFieldModifDate) {
		this.textFieldModifDate = textFieldModifDate;
	}


	public JTextField getTextFieldModifTelph() {
		return textFieldModifTelph;
	}


	public void setTextFieldModifTelph(JTextField textFieldModifTelph) {
		this.textFieldModifTelph = textFieldModifTelph;
	}


	public JTextField getTextFieldModifEmail() {
		return textFieldModifEmail;
	}


	public void setTextFieldModifEmail(JTextField textFieldModifEmail) {
		this.textFieldModifEmail = textFieldModifEmail;
	}


	public JPanel getPanelModificationLocat() {
		return panelModificationLocat;
	}


	public void setPanelModificationLocat(JPanel panelModificationLocat) {
		this.panelModificationLocat = panelModificationLocat;
	}


	public JPanel getPanelModif() {
		return panelModif;
	}


	public void setPanelModif(JPanel panelModif) {
		this.panelModif = panelModif;
	}


	public JTable getTableGestLocataire() {
		return TableGestLocataire;
	}

	public void setTableGestLocataire(JTable tableGestLocataire) {
		TableGestLocataire = tableGestLocataire;
	}

	public JPanel getPanelListeLocataire() {
		return panelListeLocataire;
	}

	public void setPanelListeLocataire(JPanel panelListeLocataire) {
		this.panelListeLocataire = panelListeLocataire;
	}

	public JPanel getPanelBienNonLocation() {
		return panelBienNonLocation;
	}

	public void setPanelBienNonLocation(JPanel panelBienNonLocation) {
		this.panelBienNonLocation = panelBienNonLocation;
	}

	public JTable getTableImmoNonMisEnLocation() {
		return tableImmoNonMisEnLocation;
	}


	public void setTableImmoNonMisEnLocation(JTable tableImmoNonMisEnLocation) {
		this.tableImmoNonMisEnLocation = tableImmoNonMisEnLocation;
	}


	public JPanel getPanelLocataire() {
		return panelLocataire;
	}


	public void setPanelLocataire(JPanel panelLocataire) {
		this.panelLocataire = panelLocataire;
	}


	public JTable getTableLocataire() {
		return tableLocataire;
	}


	public void setTableLocataire(JTable tableLocataire) {
		this.tableLocataire = tableLocataire;
	}


	public JPanel getPanelTabImmo() {
		return panelTabImmo;
	}


	public void setPanelTabImmo(JPanel panelTabImmo) {
		this.panelTabImmo = panelTabImmo;
	}


	public JTable getTableImmobilier() {
		return tableImmobilier;
	}


	public void setTableImmobilier(JTable tableImmobilier) {
		this.tableImmobilier = tableImmobilier;
	}


	public JTable getTableConsulterPaiement() {
		return tableConsulterPaiement;
	}


	public void setTableConsulterPaiement(JTable tableConsulterPaiement) {
		this.tableConsulterPaiement = tableConsulterPaiement;
	}


	public JPanel getPanelConsulterPaiement() {
		return panelConsulterPaiement;
	}


	public void setPanelConsulterPaiement(JPanel panelConsulterPaiement) {
		this.panelConsulterPaiement = panelConsulterPaiement;
	}


	public JTable getTableUsers() {
		return tableUsers;
	}


	public void setTableUsers(JTable tableUsers) {
		this.tableUsers = tableUsers;
	}


	public JPanel getPanelMenuAdmin() {
		return panelMenuAdmin;
	}

	public void setPanelMenuAdmin(JPanel panelMenuAdmin) {
		this.panelMenuAdmin = panelMenuAdmin;
	}

	public JPanel getPanelAfficheMenu() {
		return PanelAfficheMenu;
	}

	public void setPanelAfficheMenu(JPanel panelAfficheMenu) {
		PanelAfficheMenu = panelAfficheMenu;
	}

	public JPanel getPanelSousMenu() {
		return panelSousMenu;
	}

	public void setPanelSousMenu(JPanel panelSousMenu) {
		this.panelSousMenu = panelSousMenu;
	}

	public JPanel getPanelSousMenu2Admin() {
		return PanelSousMenu2Admin;
	}

	public void setPanelSousMenu2Admin(JPanel panelSousMenu2Admin) {
		PanelSousMenu2Admin = panelSousMenu2Admin;
	}

	public JPanel getPanelGestionnaire() {
		return panelGestionnaire;
	}

	public void setPanelGestionnaire(JPanel panelGestionnaire) {
		this.panelGestionnaire = panelGestionnaire;
	}

	public JPanel getPanelbtnfonctionalite() {
		return panelbtnfonctionalite;
	}

	public void setPanelbtnfonctionalite(JPanel panelbtnfonctionalite) {
		this.panelbtnfonctionalite = panelbtnfonctionalite;
	}

	public JPanelSlider getPanelSliderGesbtn() {
		return panelSliderGesbtn;
	}

	public void setPanelSliderGesbtn(JPanelSlider panelSliderGesbtn) {
		this.panelSliderGesbtn = panelSliderGesbtn;
	}

	public JPanelSlider getPanelSliderDebord() {
		return panelSliderDebord;
	}

	public void setPanelSliderDebord(JPanelSlider panelSliderDebord) {
		this.panelSliderDebord = panelSliderDebord;
	}

	public JPanel getPanelAdminTab() {
		return panelAdminTab;
	}

	public void setPanelAdminTab(JPanel panelAdminTab) {
		this.panelAdminTab = panelAdminTab;
	}

	public TableauImmobilier getPane() {
		return PaneTabImmo;
	}

	public void setPane(TableauImmobilier pane) {
		PaneTabImmo = pane;
	}

	public JTable getTable() {
		return tableUsers;
	}

	public void setTable(JTable table) {
		this.tableUsers = table;
	}

	public JXCollapsiblePane getCollapsiblePane() {
		return collapsiblePane;
	}

	public void setCollapsiblePane(JXCollapsiblePane collapsiblePane) {
		this.collapsiblePane = collapsiblePane;
	}

	public JButton getBtnCollapse() {
		return btnCollapse;
	}

	public void setBtnCollapse(JButton btnCollapse) {
		this.btnCollapse = btnCollapse;
	}

	public JPanel getPanelRacine() {
		return panelRacine;
	}

	public void setPanelRacine(JPanel panelRacine) {
		this.panelRacine = panelRacine;
	}

	public JPanelSlider getPanelSliderMenu() {
		return panelSliderMenu;
	}

	public void setPanelSliderMenu(JPanelSlider panelSliderMenu) {
		this.panelSliderMenu = panelSliderMenu;
	}

	public JButton getBtnEteindre() {
		return btnEteindre;
	}

	public void setBtnEteindre(JButton btnEteindre) {
		this.btnEteindre = btnEteindre;
	}

	public JPanel getPanelbtnMenu() {
		return panelbtnMenu;
	}

	public void setPanelbtnMenu(JPanel panelbtnMenu) {
		this.panelbtnMenu = panelbtnMenu;
	}

	public JButton getBtnAuthentification() {
		return btnAuthentification;
	}

	public void setBtnAuthentification(JButton btnAuthentification) {
		this.btnAuthentification = btnAuthentification;
	}

	public JButton getBtnConsulterBien() {
		return btnConsulterBien;
	}

	public void setBtnConsulterBien(JButton btnConsulterBien) {
		this.btnConsulterBien = btnConsulterBien;
	}

	public JPanel getPanelBoutonGestionnaire() {
		return panelBoutonGestionnaire;
	}

	public void setPanelBoutonGestionnaire(JPanel panelBoutonGestionnaire) {
		this.panelBoutonGestionnaire = panelBoutonGestionnaire;
	}

	public JButton getBtnConsultGestionnaire() {
		return btnConsultGestionnaire;
	}

	public void setBtnConsultGestionnaire(JButton btnConsultGestionnaire) {
		this.btnConsultGestionnaire = btnConsultGestionnaire;
	}

	public JButton getBtnConsultPaiement() {
		return btnConsultPaiement;
	}
	
	public void setBtnConsultPaiement(JButton btnConsultPaiement) {
		this.btnConsultPaiement = btnConsultPaiement;
	}

	public JButton getBtnAppuyerMoi() {
		return btnAppuyerMoi;
	}

	public void setBtnAppuyerMoi(JButton btnAppuyerMoi) {
		this.btnAppuyerMoi = btnAppuyerMoi;
	}

	public JButton getBtnEnregistrerPaiement() {
		return btnEnregistrerPaiement;
	}

	public void setBtnEnregistrerPaiement(JButton btnEnregistrerPaiement) {
		this.btnEnregistrerPaiement = btnEnregistrerPaiement;
	}

	public JButton getBtnConsultLocataireSansException() {
		return btnConsultLocataireSansException;
	}

	public void setBtnConsultLocataireSansException(JButton btnConsultLocataireSansException) {
		this.btnConsultLocataireSansException = btnConsultLocataireSansException;
	}

	public JButton getBtnAffection() {
		return btnAffection;
	}

	public void setBtnAffection(JButton btnAffection) {
		this.btnAffection = btnAffection;
	}

	public JButton getBtnModifierPaiement() {
		return btnModifierPaiement;
	}

	public void setBtnModifierPaiement(JButton btnModifierPaiement) {
		this.btnModifierPaiement = btnModifierPaiement;
	}

	public JButton getBtnSuppPaiement() {
		return btnSuppPaiement;
	}

	public void setBtnSuppPaiement(JButton btnSuppPaiement) {
		this.btnSuppPaiement = btnSuppPaiement;
	}

	public JButton getBtnaddUser() {
		return btnaddUser;
	}

	public void setBtnaddUser(JButton btnaddUser) {
		this.btnaddUser = btnaddUser;
	}

	public JButton getBtnSuppressionUser() {
		return btnSuppressionUser;
	}

	public void setBtnSuppressionUser(JButton btnSuppressionUser) {
		this.btnSuppressionUser = btnSuppressionUser;
	}

	public JButton getBtnaddBienImmo() {
		return btnaddBienImmo;
	}

	public void setBtnaddBienImmo(JButton btnaddBienImmo) {
		this.btnaddBienImmo = btnaddBienImmo;
	}

	public JButton getBtnGestionUser() {
		return btnGestionUser;
	}

	public void setBtnGestionUser(JButton btnGestionUser) {
		this.btnGestionUser = btnGestionUser;
	}

	public JButton getBtnDesactiverBiensImmo() {
		return btnDesactiverBiensImmo;
	}

	public void setBtnDesactiverBiensImmo(JButton btnDesactiverBiensImmo) {
		this.btnDesactiverBiensImmo = btnDesactiverBiensImmo;
	}

	public JPanel getPanneauAccueil() {
		return PanneauAccueil;
	}

	public void setPanneauAccueil(JPanel panneauAccueil) {
		PanneauAccueil = panneauAccueil;
	}

	public JPanel getPanelTableaud() {
		return panelTableaud;
	}

	public void setPanelTableaud(JPanel panelTableaud) {
		this.panelTableaud = panelTableaud;
	}

	public JScrollPane getScrollPane() {
		return scrollPane;
	}

	public void setScrollPane(JScrollPane scrollPane) {
		this.scrollPane = scrollPane;
	}

	public JButton getBtnGestionImmo() {
		return BtnGestionImmo;
	}

	public void setBtnGestionImmo(JButton btnGestionImmo) {
		BtnGestionImmo = btnGestionImmo;
	}

	public JButton getBtnConsultLocataire() {
		return btnConsultLocataire;
	}
	
	public void setBtnConsultLocataire(JButton btnConsultLocataire) {
		this.btnConsultLocataire = btnConsultLocataire;
	}

	public void runWindows()
	{
		this.setVisible(true);
	}

	public void addActionBtnAuthentification(ActionListener actionListener) {
		btnAuthentification.addActionListener(actionListener);
		
	}
	public void ecouteurBtnCreerUser(ActionListener actionListener) {
		
		btnaddUser.addActionListener(actionListener);	
	}
	public void ecouteurBtnAddBienImmo(ActionListener actionListener) {
		btnaddBienImmo.addActionListener(actionListener);
	}

	public void EcouteurBtnAffecter(ActionListener actionListener) {
		btnAffection.addActionListener(actionListener);
		
	}

	public void ecouteurBtnEnrgistrmentPaiemnt(ActionListener actionListener) {
		btnEnregistrerPaiement.addActionListener(actionListener);
		
	}

	public void MessageListe(String message) {
	JOptionPane.showMessageDialog(null, message,"Liste Paiements"
				,JOptionPane.ERROR_MESSAGE);		
	}

	public void ecouteurBtnPaiement(ActionListener actionListener) {
		btnConsultPaiement.addActionListener(actionListener);
		
	}


	public void EcouteurBtnConsulterDispo(ActionListener actionListener) {
		btnConsulterBien.addActionListener(actionListener);
		
	}


	public void EcouteurConsulterLocat(ActionListener actionListener) {
		btnConsultLocataire.addActionListener(actionListener);
		
	}


	public void ecouteurBtnConsulterbienGestionnaire(ActionListener actionListener) {
		btnConsultGestionnaire.addActionListener(actionListener);
		
	}


	public void ecouteurBtnListeLocatGest(ActionListener actionListener) {
		
		btnConsultLocataireSansException.addActionListener(actionListener);	
	}

	public void EcouteurTableGestLocat(MouseAdapter mouseAdapter) {
		
		TableGestLocataire.addMouseListener(mouseAdapter);
		
	}

	public void EcouteurBtnModif(ActionListener actionListener) {
		btnModifier.addActionListener(actionListener);
	}
	

	public void MessageErreur(String message) {
		JOptionPane.showMessageDialog(null, message,"Suppression Utilisateur"
				,JOptionPane.ERROR_MESSAGE);	
		
	}

	public void ecouteurBtnSupprimerUser(ActionListener actionListener) {
		btnSuppressionUser.addActionListener(actionListener);
		
	}


	public void MessageExcep(String message) {
		JOptionPane.showMessageDialog(null, message,"Suppression Utilisateur"
				,JOptionPane.ERROR_MESSAGE);	
		
	}



	public void AddEcouteurBtnModifAdmin(ActionListener actionListener) {
	btnModifAdmin.addActionListener(actionListener);
		
	}


	public void MessageException(String message) {
		JOptionPane.showMessageDialog(null, message,"Modifier Utilisateur"
				,JOptionPane.ERROR_MESSAGE);	
		
	}


	public void addEcouteurBtnModifUser(ActionListener actionListener) {
		btnModifUser.addActionListener(actionListener);
		
	}


	public void MessageReussite() {
		JOptionPane.showMessageDialog(null, "Utilisateur Modifi�","Modifier Utilisateur"
				,JOptionPane.INFORMATION_MESSAGE);	
		
	}


	public void clear() {
		
		this.getTextFieldIdUser().setText(null);
		this.getTextFieldUsername().setText(null);
		this.getTextFieldUserNaissance().setText(null);
		this.getTextFieldUserLogin().setText(null);
		this.getTextFieldNumTelphUser().setText(null);
		this.getTextFieldUserMdp().setText(null);
		this.getTextFieldUserAdress().setText(null);
		this.getTextFieldUserEmail().setText(null);
		this.getTextFieldUserLastname().setText(null);
		
	}
	
	public void clearPanelInmmo()
	{
		this.getTextAreaDetaisImmo().setText(null);
		this.getTextFieldIdImmo().setText(null);
		this.getTextFieldLoyerImmo().setText(null);
		this.getTextFieldMontantImmo().setText(null);
		this.getTextFieldAdressImmo().setText(null);
		this.getTextFieldNbrePiece().setText(null);
	}


	public void MessageSelection() {
		JOptionPane.showMessageDialog(null, "Selection une ligne du tableau","D�s�lection"
				,JOptionPane.INFORMATION_MESSAGE);	
		
	}


	public void AddlistenerbtnModifImmo(ActionListener actionListener) {
		
		btnModifImmoS.addActionListener(actionListener);
	}


	public void MessAgeFormat(String message) {
		
		JOptionPane.showMessageDialog(null, message,"Champs Vide"
				,JOptionPane.ERROR_MESSAGE);	
	}


	public void msgError(String message) {
		
		JOptionPane.showMessageDialog(null, message,"Modification Immobilier"
				,JOptionPane.ERROR_MESSAGE);
	}


	public void msgIllegalarg(String message) {
		JOptionPane.showMessageDialog(null, message,"Modification Immobilier"
				,JOptionPane.ERROR_MESSAGE);
			
	}

	public void msgException(String message) {
		JOptionPane.showMessageDialog(null, message,"Manque de donnees"
				,JOptionPane.ERROR_MESSAGE);	
	}

	public void msgsucceModif() {
		
		JOptionPane.showMessageDialog(null, "Modification R�ussie","Immobilier"
				,JOptionPane.INFORMATION_MESSAGE);	
	}

	public void ecouteurBtnPaiementGestion(ActionListener actionListener) {
		btnModifierPaiement.addActionListener(actionListener);
		
	}

	public void msgExceptions(String message) {
		JOptionPane.showMessageDialog(null, message,"Modification Paiement"
				,JOptionPane.ERROR_MESSAGE);
	}

	public void ecouteurBtnModifPaye(ActionListener actionListener) {
		btnModifPaye.addActionListener(actionListener);
		
	}

	public void msgSucce() {
		
		JOptionPane.showMessageDialog(null, "Modification R�ussie","Paiement"
				,JOptionPane.INFORMATION_MESSAGE);	
	}


	public void AddecouteurSupprimerPaimnt(ActionListener actionListener) {
		btnSuppPaiement.addActionListener(actionListener);
		
	}


	public void msgSuccesSupp() {
		
		JOptionPane.showMessageDialog(null, "Paiement Supprim�","Suppresion Paiement"
				,JOptionPane.INFORMATION_MESSAGE);	
		
	}


	public void msgSuceesuppUser() {
		JOptionPane.showMessageDialog(null, "Utilisateur Supprim�","Suppresion Utilisateur"
				,JOptionPane.INFORMATION_MESSAGE);	
		
	}


	public void msExceptionSupp(String message) {
		JOptionPane.showMessageDialog(null, message,"Manque de donnees"
				,JOptionPane.ERROR_MESSAGE);
		
	}
}

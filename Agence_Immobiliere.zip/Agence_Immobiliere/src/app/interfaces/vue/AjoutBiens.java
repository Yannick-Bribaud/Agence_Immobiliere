package app.interfaces.vue;

import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;

public class AjoutBiens extends JFrame {
	
	
	private static final long serialVersionUID = 1L;
	
	private JTextField AdressetextField;
	private JTextField textFieldMontant;
	private JTextField LoyertextField;
	private JTextField textFieldNbrePiece;
	private JScrollPane scrollPane;
	private JButton btnAjouterBien;
	private JCheckBox MisEnLocationCheckBox;
	private JTextArea textArea;
	private JButton btnTerminer;
	
	public AjoutBiens() {
		
		 MisEnLocationCheckBox = new JCheckBox("En Location");
		 btnAjouterBien = new JButton("Ajouter");
		 textArea = new JTextArea();
		  btnTerminer = new JButton("Terminer");
		 
		 setMinimumSize(new Dimension(620, 375));
		this.setLocationRelativeTo(null);
		getContentPane().setMinimumSize(new Dimension(700, 350));
		getContentPane().setLayout(new BorderLayout(0, 0));
		
	    scrollPane = new JScrollPane();
	    scrollPane.setMinimumSize(new Dimension(700, 350));
		getContentPane().add(scrollPane);
		
		JPanel panel = new JPanel();
		panel.setMinimumSize(new Dimension(700, 350));
		panel.setBackground(new Color(49, 54, 70));
		scrollPane.setViewportView(panel);
		panel.setLayout(null);
		
		JLabel lblAdressBien = new JLabel(" Adresse");
		lblAdressBien.setForeground(Color.WHITE);
		lblAdressBien.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblAdressBien.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdressBien.setBounds(21, 64, 77, 31);
		panel.add(lblAdressBien);
		
		AdressetextField = new JTextField();
		AdressetextField.setToolTipText("Ecrivez l'adresse du bien Immobilier");
		AdressetextField.setForeground(Color.WHITE);
		AdressetextField.setBorder(null);
		AdressetextField.setBounds(106, 70, 145, 20);
		AdressetextField.setBackground(new Color(49, 54, 70));
		panel.add(AdressetextField);
		AdressetextField.setColumns(10);
		
		JSeparator separatorAdresse = new JSeparator();
		separatorAdresse.setBorder(new LineBorder(Color.WHITE, 3));
		separatorAdresse.setBounds(106, 90, 145, 1);
		panel.add(separatorAdresse);
		
		JLabel lblMontant = new JLabel("Montant ");
		lblMontant.setHorizontalAlignment(SwingConstants.CENTER);
		lblMontant.setForeground(Color.WHITE);
		lblMontant.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblMontant.setBounds(314, 64, 77, 31);
		panel.add(lblMontant);
		
		textFieldMontant = new JTextField();
		textFieldMontant.setToolTipText("Donnez le montant du bien");
		textFieldMontant.setForeground(Color.WHITE);
		textFieldMontant.setBorder(null);
		textFieldMontant.setBounds(401, 70, 149, 20);
		textFieldMontant.setBackground(new Color(49, 54, 70));
		panel.add(textFieldMontant);
		textFieldMontant.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBorder(new LineBorder(Color.WHITE, 3));
		separator.setBounds(401, 90, 149, 1);
		panel.add(separator);
		
		JLabel lblNewLabel = new JLabel("Loyer");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(21, 111, 77, 41);
		panel.add(lblNewLabel);
		
		LoyertextField = new JTextField();
		LoyertextField.setToolTipText("Donner la somme/mois");
		LoyertextField.setBorder(null);
		LoyertextField.setForeground(Color.WHITE);
		LoyertextField.setColumns(10);
		LoyertextField.setBackground(new Color(49, 54, 70));
		LoyertextField.setBounds(106, 120, 149, 20);
		panel.add(LoyertextField);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBorder(new LineBorder(Color.WHITE, 3));
		separator_1.setBounds(106, 145, 149, 2);
		panel.add(separator_1);
		
		JLabel lblNombrePieces = new JLabel("Nbre Pieces");
		lblNombrePieces.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombrePieces.setForeground(Color.WHITE);
		lblNombrePieces.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNombrePieces.setBounds(293, 112, 90, 41);
		panel.add(lblNombrePieces);
		
		textFieldNbrePiece = new JTextField();
		textFieldNbrePiece.setToolTipText("Nombre des pieces du Bien");
		textFieldNbrePiece.setForeground(Color.WHITE);
		textFieldNbrePiece.setColumns(10);
		textFieldNbrePiece.setBorder(null);
		textFieldNbrePiece.setBackground(new Color(49, 54, 70));
		textFieldNbrePiece.setBounds(401, 123, 149, 20);
		panel.add(textFieldNbrePiece);
		
		JSeparator separator_1_1 = new JSeparator();
		separator_1_1.setBorder(new LineBorder(Color.WHITE, 3));
		separator_1_1.setBounds(401, 146, 149, 1);
		panel.add(separator_1_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 692, 33);
		panel.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNAjoutBien = new JLabel("AJOUT BIEN IMMOBILIER");
		lblNAjoutBien.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNAjoutBien.setHorizontalAlignment(SwingConstants.CENTER);
		lblNAjoutBien.setForeground(new Color(49, 54, 70));
		panel_1.add(lblNAjoutBien, BorderLayout.CENTER);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBorder(null);
		scrollPane_1.setBounds(325, 185, 227, 58);
		panel.add(scrollPane_1);
		
		
		textArea.setToolTipText("Commentaire sur le Bien");
		textArea.setForeground(Color.WHITE);
		textArea.setBorder(null);
		textArea.setBackground(new Color(49, 54, 70));
		scrollPane_1.setViewportView(textArea);
		
		JLabel lblDetails = new JLabel("Details");
		lblDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblDetails.setForeground(Color.WHITE);
		lblDetails.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblDetails.setBounds(231, 180, 70, 52);
		panel.add(lblDetails);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBorder(new LineBorder(new Color(255, 255, 255), 3));
		separator_2.setBounds(323, 244, 231, 2);
		panel.add(separator_2);
		
		
		btnAjouterBien.setToolTipText("Appuyer pour Ajouter un nouveau Bien");
		btnAjouterBien.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnAjouterBien.setForeground(Color.WHITE);
		btnAjouterBien.setBackground(new Color(152, 16, 57));
		btnAjouterBien.setFont(new Font("Rockwell", Font.BOLD, 13));
		btnAjouterBien.setBounds(59, 305, 134, 25);
		panel.add(btnAjouterBien);
		
		
		MisEnLocationCheckBox.setToolTipText("Indiquer si le Bien est d\u00E9ja en location");
		MisEnLocationCheckBox.setForeground(Color.WHITE);
		MisEnLocationCheckBox.setFont(new Font("Rockwell", Font.BOLD, 14));
		MisEnLocationCheckBox.setHorizontalAlignment(SwingConstants.LEFT);
		MisEnLocationCheckBox.setBounds(39, 217, 134, 31);
		MisEnLocationCheckBox.setBackground(new Color(49, 54, 70));
		panel.add(MisEnLocationCheckBox);
		
		
		btnTerminer.setForeground(Color.WHITE);
		btnTerminer.setFont(new Font("Rockwell", Font.BOLD, 15));
		btnTerminer.setBounds(446, 305, 114, 25);
		btnTerminer.setBackground(new Color(152, 16, 57));
		panel.add(btnTerminer);
		
	}
	
	
	

	public JButton getBtnTerminer() {
		return btnTerminer;
	}

	public void setBtnTerminer(JButton btnTerminer) {
		this.btnTerminer = btnTerminer;
	}


	public String getAdressetextField() {
		
		String valeur = AdressetextField.getText(); 
		return valeur;
	}

	public void setAdressetextField(JTextField adressetextField) {
		AdressetextField = adressetextField;
	}

	public String getTextFieldMontant() {
		
		String valeur = textFieldMontant.getText();
			return valeur;
	} 

	public void setTextFieldMontant(JTextField textFieldMontant) {
		this.textFieldMontant = textFieldMontant;
	}

	public String getLoyertextField() {
		
		String valeur = LoyertextField.getText();
		return valeur;
	}  

	public void setLoyertextField(JTextField loyertextField) {
		LoyertextField = loyertextField;
	}

	public String getTextFieldNbrePiece() {
		String valeur = textFieldNbrePiece.getText();
		return valeur;
	}   

	public void setTextFieldNbrePiece(JTextField textFieldNbrePiece) {
		this.textFieldNbrePiece = textFieldNbrePiece;
	}

	public JButton getBtnAjouterBien() {
		return btnAjouterBien;
	}

	public void setBtnAjouterBien(JButton btnAjouterBien) {
		this.btnAjouterBien = btnAjouterBien;
	}

	public String getMisEnLocationCheckBox() {
		
			String statut;
		if(MisEnLocationCheckBox.isSelected())  
		{
			 statut = "En Location/Oui";
		}
		else
		{
			statut = "En Location/Non";
		}
		return statut;
	}

	public void setMisEnLocationCheckBox(JCheckBox misEnLocationCheckBox) {
		MisEnLocationCheckBox = misEnLocationCheckBox;
	}

	public String getTextArea() {
		
		String value = textArea.getText();
		
		return value;
	}  

	public void setTextArea(JTextArea textArea) {
		this.textArea = textArea;
	}

	public void MessageError(String message) {
		
		JOptionPane.showMessageDialog(null, message,"Mauvais Format"
				,JOptionPane.ERROR_MESSAGE);
		
	}

	public void MessageException(String message) {
		
		JOptionPane.showMessageDialog(null, message,"Erreur Immobilier"
				,JOptionPane.ERROR_MESSAGE);
	}

	public void addEcouteurBtnAjouter(ActionListener actionListener) {
		btnAjouterBien.addActionListener(actionListener);
		
	}
	
	public void run() {
		this.setVisible(true);
	}
	

	public void MessageExcption(String message) {
		JOptionPane.showMessageDialog(null, message,"Invalide Champs"
				,JOptionPane.ERROR_MESSAGE);	
	}

	public void MessageSucces() {
		
		JOptionPane.showMessageDialog(null, "Bien immobilier ajout�.","REUSSITE"
				,JOptionPane.INFORMATION_MESSAGE);	
		
	}

	public void MessageEchec() {
		JOptionPane.showMessageDialog(null, "Echec ajout bien immobilier.","ECHEC"
				,JOptionPane.ERROR_MESSAGE);
		
	}

	public void clear() {
		
		AdressetextField.setText(null); 
		textFieldMontant.setText(null); 
		LoyertextField.setText(null);
		textFieldNbrePiece.setText(null); 
		MisEnLocationCheckBox.setSelected(false); 
		textArea.setText(null);
		
	}

	public void addEcouteurBtnTerminer(ActionListener actionListener) {
		
		btnTerminer.addActionListener(actionListener);
		
	}
}

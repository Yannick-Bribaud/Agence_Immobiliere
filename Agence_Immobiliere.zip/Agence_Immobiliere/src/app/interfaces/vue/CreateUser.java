package app.interfaces.vue;

import javax.swing.JFrame;

import java.awt.Dimension;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import java.awt.Cursor;

public class CreateUser extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JScrollPane scrollPane;
	private JTextField NomtextField;
	private JTextField PrenomtextField;
	private JTextField LogintextField;
	private JPasswordField passwordField;
	private JTextField AdressetextField;
	private JTextField EmailtextField;
	private JTextField NumTelField;
	private JComboBox<String> comboBoxJours;
	private JComboBox<String> comboBoxMois;
	private JComboBox<String> comboBoxAnnee;
	private JCheckBox AdminCheckBox;
	private JButton btnCreer;
	private JButton btnTerminer;
	
	public CreateUser() {
		
		
		
		 comboBoxJours = new JComboBox<String>();
		 comboBoxMois = new JComboBox<String>();
		 comboBoxAnnee = new JComboBox<String>();
		 AdminCheckBox = new JCheckBox("Administrateur ?");
		 btnCreer = new JButton("Cr\u00E9er");
		 btnCreer.setBorderPainted(false);
		  btnTerminer = new JButton("Terminer");
		  btnTerminer.setBorderPainted(false);
		 
		setSize(new Dimension(800, 500));
		setOpacity(0.99f);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		scrollPane = new JScrollPane();
		
		
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setForeground(Color.WHITE);
		scrollPane.setBackground(Color.BLACK);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		panel.setSize(new Dimension(800, 500));
		panel.setLayout(null);
		panel.setPreferredSize(new Dimension(800, 500));
		panel.setMinimumSize(new Dimension(800, 500));
		panel.setBackground(new Color(49, 54, 70));
		getContentPane().add(panel, BorderLayout.NORTH);
		
		NomtextField = new JTextField();
		NomtextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		NomtextField.setHorizontalAlignment(SwingConstants.CENTER);
		NomtextField.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
		NomtextField.setToolTipText("Entrez le nom");
		NomtextField.setForeground(Color.WHITE);
		NomtextField.setColumns(10);
		NomtextField.setBorder(null);
		NomtextField.setBackground(new Color(49, 54, 70));
		NomtextField.setBounds(126, 99, 206, 23);
		panel.add(NomtextField);
		
		JSeparator separatorNom = new JSeparator();
		separatorNom.setBorder(new LineBorder(Color.WHITE, 3));
		separatorNom.setBounds(126, 122, 208, 2);
		panel.add(separatorNom);
		
		JLabel lblNomUser = new JLabel("Nom User");
		lblNomUser.setHorizontalAlignment(SwingConstants.CENTER);
		lblNomUser.setForeground(Color.WHITE);
		lblNomUser.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNomUser.setBorder(null);
		lblNomUser.setBounds(10, 99, 106, 27);
		panel.add(lblNomUser);
		
		PrenomtextField = new JTextField();
		PrenomtextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		PrenomtextField.setHorizontalAlignment(SwingConstants.CENTER);
		PrenomtextField.setForeground(Color.WHITE);
		PrenomtextField.setColumns(10);
		PrenomtextField.setBorder(null);
		PrenomtextField.setBackground(new Color(49, 54, 70));
		PrenomtextField.setBounds(501, 98, 206, 23);
		panel.add(PrenomtextField);
		
		JLabel lblPrenomUser = new JLabel("Pr\u00E9nom User");
		lblPrenomUser.setHorizontalAlignment(SwingConstants.CENTER);
		lblPrenomUser.setForeground(Color.WHITE);
		lblPrenomUser.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblPrenomUser.setBorder(null);
		lblPrenomUser.setBounds(385, 99, 106, 27);
		panel.add(lblPrenomUser);
		
		JSeparator separatorPrenom = new JSeparator();
		separatorPrenom.setBorder(new LineBorder(Color.WHITE, 3));
		separatorPrenom.setBackground(Color.BLACK);
		separatorPrenom.setBounds(501, 122, 208, 2);
		panel.add(separatorPrenom);
		
		LogintextField = new JTextField();
		LogintextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		LogintextField.setHorizontalAlignment(SwingConstants.CENTER);
		LogintextField.setForeground(Color.WHITE);
		LogintextField.setColumns(10);
		LogintextField.setBorder(null);
		LogintextField.setBackground(new Color(49, 54, 70));
		LogintextField.setBounds(126, 156, 206, 23);
		panel.add(LogintextField);
		
		JLabel lblLoginUser = new JLabel("Login User");
		lblLoginUser.setHorizontalAlignment(SwingConstants.CENTER);
		lblLoginUser.setForeground(Color.WHITE);
		lblLoginUser.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblLoginUser.setBorder(null);
		lblLoginUser.setBounds(10, 153, 106, 27);
		panel.add(lblLoginUser);
		
		JSeparator separatorLogin = new JSeparator();
		separatorLogin.setBorder(new LineBorder(Color.WHITE, 3));
		separatorLogin.setBounds(126, 182, 208, 2);
		panel.add(separatorLogin);
		
		JLabel lblPasswordUser = new JLabel("Password ");
		lblPasswordUser.setHorizontalAlignment(SwingConstants.CENTER);
		lblPasswordUser.setForeground(Color.WHITE);
		lblPasswordUser.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblPasswordUser.setBorder(null);
		lblPasswordUser.setBounds(385, 153, 105, 27);
		panel.add(lblPasswordUser);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setForeground(Color.WHITE);
		passwordField.setBorder(null);
		passwordField.setBackground(new Color(49, 54, 70));
		passwordField.setBounds(501, 156, 206, 23);
		panel.add(passwordField);
		
		JPanel paneIndicationDate = new JPanel();
		paneIndicationDate.setBorder(null);
		paneIndicationDate.setBackground(new Color(49, 54, 70));
		paneIndicationDate.setBounds(10, 205, 776, 40);
		panel.add(paneIndicationDate);
		paneIndicationDate.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_2 = new JLabel("Entrez la date de naissace");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		paneIndicationDate.add(lblNewLabel_2, BorderLayout.CENTER);
		
		JLabel labelJourNaissance = new JLabel("Jour");
		labelJourNaissance.setHorizontalAlignment(SwingConstants.LEFT);
		labelJourNaissance.setForeground(Color.WHITE);
		labelJourNaissance.setFont(new Font("Rockwell", Font.BOLD | Font.ITALIC, 14));
		labelJourNaissance.setBounds(108, 256, 53, 23);
		panel.add(labelJourNaissance);
		
		
		comboBoxJours.setFont(new Font("Rockwell", Font.BOLD, 15));
		comboBoxJours.setModel(new DefaultComboBoxModel<String>(new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBoxJours.setBounds(171, 257, 85, 22);
		panel.add(comboBoxJours);
		
		JLabel lblMoisNaissance = new JLabel("Mois");
		lblMoisNaissance.setHorizontalAlignment(SwingConstants.CENTER);
		lblMoisNaissance.setForeground(Color.WHITE);
		lblMoisNaissance.setFont(new Font("Rockwell", Font.BOLD | Font.ITALIC, 14));
		lblMoisNaissance.setBounds(277, 256, 73, 23);
		panel.add(lblMoisNaissance);
		
		
		comboBoxMois.setModel(new DefaultComboBoxModel<String>(new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBoxMois.setFont(new Font("Rockwell", Font.BOLD, 16));
		comboBoxMois.setBounds(374, 256, 85, 22);
		panel.add(comboBoxMois);
		
		JLabel LabelAnnee = new JLabel("Ann\u00E9e");
		LabelAnnee.setHorizontalAlignment(SwingConstants.CENTER);
		LabelAnnee.setForeground(Color.WHITE);
		LabelAnnee.setFont(new Font("Rockwell", Font.BOLD | Font.ITALIC, 14));
		LabelAnnee.setBounds(483, 256, 71, 24);
		panel.add(LabelAnnee);
		
		
		comboBoxAnnee.setModel(new DefaultComboBoxModel<String>(new String[] {"2020", "2019", "2018", "2017", "2016", "2015", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009"}));
		comboBoxAnnee.setFont(new Font("Rockwell", Font.BOLD, 15));
		comboBoxAnnee.setBounds(564, 256, 85, 22);
		panel.add(comboBoxAnnee);
		
		JLabel lblNewLabel = new JLabel(" Adresse");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel.setBorder(null);
		lblNewLabel.setBounds(30, 310, 106, 24);
		panel.add(lblNewLabel);
		
		AdressetextField = new JTextField();
		AdressetextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		AdressetextField.setHorizontalAlignment(SwingConstants.CENTER);
		AdressetextField.setForeground(Color.WHITE);
		AdressetextField.setColumns(10);
		AdressetextField.setBorder(null);
		AdressetextField.setBackground(new Color(49, 54, 70));
		AdressetextField.setBounds(126, 312, 233, 23);
		panel.add(AdressetextField);
		
		JSeparator separatorPassword = new JSeparator();
		separatorPassword.setBorder(new LineBorder(Color.WHITE, 3));
		separatorPassword.setBounds(501, 182, 208, 2);
		panel.add(separatorPassword);
		
		JSeparator separatorAdress = new JSeparator();
		separatorAdress.setBorder(new LineBorder(Color.WHITE, 3));
		separatorAdress.setBounds(126, 338, 230, 2);
		panel.add(separatorAdress);
		
		JLabel lblEmail = new JLabel("  Email");
		lblEmail.setHorizontalAlignment(SwingConstants.LEFT);
		lblEmail.setForeground(Color.WHITE);
		lblEmail.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblEmail.setBorder(null);
		lblEmail.setBounds(423, 311, 68, 23);
		panel.add(lblEmail);
		
		EmailtextField = new JTextField();
		EmailtextField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		EmailtextField.setHorizontalAlignment(SwingConstants.CENTER);
		EmailtextField.setForeground(Color.WHITE);
		EmailtextField.setColumns(10);
		EmailtextField.setBorder(null);
		EmailtextField.setBackground(new Color(49, 54, 70));
		EmailtextField.setBounds(489, 312, 233, 23);
		panel.add(EmailtextField);
		
		JSeparator separator = new JSeparator();
		separator.setBorder(new LineBorder(Color.WHITE, 3));
		separator.setBounds(488, 336, 230, 2);
		panel.add(separator);
		
		JPanel panelAudessus = new JPanel();
		panelAudessus.setBackground(Color.WHITE);
		panelAudessus.setBounds(0, 0, 796, 40);
		panel.add(panelAudessus);
		panelAudessus.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("Cr\u00E9ation Utilisateur");
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 22));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panelAudessus.add(lblNewLabel_1);
		
		
		AdminCheckBox.setForeground(Color.WHITE);
		AdminCheckBox.setFont(new Font("Rockwell", Font.BOLD, 15));
		AdminCheckBox.setBounds(54, 379, 186, 23);
		AdminCheckBox.setBackground(new Color(49, 54, 70));
		panel.add(AdminCheckBox);
		
		JLabel lblNewLabel_3 = new JLabel("N\u00B0-Tel");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(411, 379, 73, 23);
		panel.add(lblNewLabel_3);
		
		NumTelField = new JTextField();
		NumTelField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		NumTelField.setHorizontalAlignment(SwingConstants.CENTER);
		NumTelField.setForeground(Color.WHITE);
		NumTelField.setBorder(null);
		NumTelField.setBounds(489, 380, 225, 23);
		NumTelField.setBackground(new Color(49, 54, 70));
		panel.add(NumTelField);
		NumTelField.setColumns(10);
		
		JSeparator separatorTel = new JSeparator();
		separatorTel.setBorder(new LineBorder(Color.WHITE, 3));
		separatorTel.setBounds(489, 405, 230, 2);
		panel.add(separatorTel);
		
		
		btnCreer.setForeground(Color.WHITE);
		btnCreer.setFont(new Font("Rockwell", Font.BOLD, 15));
		btnCreer.setBounds(10, 428, 158, 27);
		btnCreer.setBackground(new Color(152, 16, 57));
		panel.add(btnCreer);
		
		
		
		btnTerminer.setForeground(Color.WHITE);
		btnTerminer.setFont(new Font("Rockwell", Font.BOLD, 15));
		btnTerminer.setBounds(610, 428, 158, 27);
		btnTerminer.setBackground(new Color(152, 16, 57));
		panel.add(btnTerminer);
		setBackground(Color.WHITE);
		setMaximumSize(new Dimension(400, 750));
		setMinimumSize(new Dimension(800, 500));
		
		
		setVisible(true);
		this.setLocationRelativeTo(null);
	}
	
	
	
	public JButton getBtnTerminer() {
		return btnTerminer;
	}

	public void setBtnTerminer(JButton btnTerminer) {
		this.btnTerminer = btnTerminer;
	}

	public String getNomtextField() {
		
		String ValeurNom = NomtextField.getText();  
		
		return ValeurNom;
	}

	public void setNomtextField(JTextField nomtextField) {
		NomtextField = nomtextField;
	}

	public String getPrenomtextField() {
		
		String ValeurPrenom = PrenomtextField.getText();
		return ValeurPrenom;
	}

	public void setPrenomtextField(JTextField prenomtextField) {
		PrenomtextField = prenomtextField;
	}

	public String getLogintextField() {
		
		String ValeurLogin = LogintextField.getText();   
		return ValeurLogin;
	}

	public void setLogintextField(JTextField logintextField) {
		LogintextField = logintextField;
	}

	public String getPasswordField() {
		
		String ValeurPassword = String.valueOf(passwordField.getPassword());
		
		return ValeurPassword;  
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}

	public String getAdressetextField() {
		
		String ValeurAdresse = AdressetextField.getText();
		return ValeurAdresse;
	}   

	public void setAdressetextField(JTextField adressetextField) {
		AdressetextField = adressetextField;
	}

	public String getEmailtextField() {
		
		String ValeurEmail = EmailtextField.getText();
		return ValeurEmail;
	}

	public void setEmailtextField(JTextField emailtextField) {
		EmailtextField = emailtextField;
	}

	public String getNumTelField() {
		
		String ValeurNum = NumTelField.getText();
		return ValeurNum;
	}
	
	public void setNumTelField(JTextField numTelField) {
		NumTelField = numTelField;
	}

	public String getComboBoxJours() {
		
		String ValeurJour = comboBoxJours.getSelectedItem().toString();
		return ValeurJour;
	}
	
	public void setComboBoxJours(JComboBox<String> comboBoxJours) {
		this.comboBoxJours = comboBoxJours;
	}

	public String getComboBoxMois() {
		
		String ValeurMois = comboBoxMois.getSelectedItem().toString();
		return ValeurMois;
	}
 
	public void setComboBoxMois(JComboBox<String> comboBoxMois) {
		this.comboBoxMois = comboBoxMois;
	}

	public String getComboBoxAnnee() {
		
		String ValeurAnnee = comboBoxAnnee.getSelectedItem().toString();
		return ValeurAnnee;
	}
	
	public void setComboBoxAnnee(JComboBox<String> comboBoxAnnee) {
		this.comboBoxAnnee = comboBoxAnnee;
	}

	public String getAdminCheckBox() {
		
		String valchekBox;
		
		if(AdminCheckBox.isSelected())
		{
			valchekBox="Administrateur";
		}
		else
		{
			valchekBox="Gestionnaire";
		}
		
		return valchekBox;
	}
	
	

	public void setAdminCheckBox(JCheckBox adminCheckBox) {
		AdminCheckBox = adminCheckBox;
	}

	public JButton getBtnCreer() {
		return btnCreer;
	}

	public void setBtnCreer(JButton btnCreer) {
		this.btnCreer = btnCreer;
	}


	public void addListenerBtnCreer(ActionListener actionListener) {
		btnCreer.addActionListener(actionListener);
		
	}
	
	public void runCreate()
	{
		this.setVisible(true);
	}

	public void MessageException(String message) {
		JOptionPane.showMessageDialog(null, message,"AUTHENTIFICATION"
				,JOptionPane.ERROR_MESSAGE);
	}


	public void MessageRuntime(String message) {
		
		JOptionPane.showMessageDialog(null, message,"AUTHENTIFICATION"
				,JOptionPane.ERROR_MESSAGE);
	}




	public void MessageDeReussite() {
		
		JOptionPane.showMessageDialog(null, "1 Utilisateur a �t� ajout�","REUSSITE"
				,JOptionPane.INFORMATION_MESSAGE);
	}




	public void MessagEchec() {
		
		JOptionPane.showMessageDialog(null, "Aucun Utilisateur n'a �t� ajout�","ECHEC"
				,JOptionPane.ERROR_MESSAGE);
		
	}

	public void Clear() {
		 
		NomtextField.setText(null);
		PrenomtextField.setText(null); 
		LogintextField.setText(null); 
		passwordField.setText(null); 
		AdressetextField.setText(null); 
		EmailtextField.setText(null); 
		NumTelField.setText(null); 
		comboBoxJours.setSelectedIndex(0);
		comboBoxMois.setSelectedIndex(0);
		comboBoxAnnee.setSelectedIndex(0);
		AdminCheckBox.setSelected(false);
		
	}

	public void ecouteurBtnTerminer(ActionListener actionListener) {
		btnTerminer.addActionListener(actionListener);
		
	}
}

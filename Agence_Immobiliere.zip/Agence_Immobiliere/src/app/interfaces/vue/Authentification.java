package app.interfaces.vue;

import javax.swing.ImageIcon;


import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import javax.swing.SwingConstants;
import diu.swe.habib.JPanelSlider.JPanelSlider;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JPasswordField;

import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.Cursor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Authentification extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JTextField textFieldEmail;
	private JPasswordField passwordField;
	private JPanelSlider panelSlider;
	private JPanel panelPassword;
	private JButton btnValider;
	private JButton btnreessayer;
	private JPanel panelEmail;
	
	public Authentification() {
		
		
		 panelPassword = new JPanel();
		 panelSlider = new JPanelSlider();
		 panelPassword = new JPanel();
		 textFieldEmail = new JTextField();
		 textFieldEmail.setToolTipText("Entrez votre adresse mail");
		 
		 textFieldEmail.setHorizontalAlignment(SwingConstants.CENTER);
		 textFieldEmail.setFont(new Font("Rockwell", Font.PLAIN, 15));
		 panelEmail = new JPanel();
		
		 btnValider = new JButton("Valider");
		 btnreessayer = new JButton("R\u00E9essayer");
		 btnValider.setEnabled(false);
		 

		    setOpacity(0.95f);
			setUndecorated(true);
			getContentPane().setSize(new Dimension(450, 335));
			getContentPane().setPreferredSize(new Dimension(450, 335));
			getContentPane().setMinimumSize(new Dimension(450, 335));
			getContentPane().setLayout(null);
		
			JPanel panel = new JPanel();
			panel.setMinimumSize(new Dimension(450, 400));
			panel.setPreferredSize(new Dimension(450, 400));
			panel.setSize(new Dimension(450, 400));
			panel.setBackground(Color.WHITE);
			panel.setBounds(0, 0, 450, 335);
			getContentPane().add(panel);
			panel.setLayout(null);


		
			JPanel panel_1 = new JPanel();
			panel_1.setBackground(new Color(49, 54, 70));
			panel_1.setBounds(0, 0, 446, 334);
			panel.add(panel_1);
			panel_1.setLayout(null);
		
			JLabel lblAuthentificationIcon = new JLabel("");
			lblAuthentificationIcon.setMinimumSize(new Dimension(118, 129));
			lblAuthentificationIcon.setHorizontalTextPosition(SwingConstants.CENTER);
			lblAuthentificationIcon.setSize(new Dimension(115, 125));
			lblAuthentificationIcon.setHorizontalAlignment(SwingConstants.CENTER);
			lblAuthentificationIcon.setBounds(165, 31, 118, 119);
			ImageIcon icon = new ImageIcon("C:\\Code Programmation\\JavaAPP\\Agence_Immobiliere\\icone\\customer_128px.png");
			Image img = icon.getImage();
			Image dimImg= img.getScaledInstance(lblAuthentificationIcon.getWidth(), lblAuthentificationIcon.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon RedimImg = new ImageIcon(dimImg);
			lblAuthentificationIcon.setIcon(RedimImg);
				
				
		panel_1.add(lblAuthentificationIcon);
		
		
		panelSlider.setBounds(24, 161, 400, 73);
		panel_1.add(panelSlider);
		
		JPanel panelEmail = new JPanel();
		panelEmail.setToolTipText("");
		panelEmail.setBackground(new Color(49, 54, 70));
		panelSlider.add(panelEmail, "name_387563351343100");
		panelEmail.setLayout(null);
		
		textFieldEmail.addKeyListener(new KeyAdapter() {
		 	@Override
		 	public void keyReleased(KeyEvent e) {
		 		
		 		if(textFieldEmail.getText().length() > 0)
				{
					 btnValider.setEnabled(true);
				}
				else
				{
					btnValider.setEnabled(false);
				}
		 	}
		 });
		
		
		textFieldEmail.setForeground(Color.WHITE);
		textFieldEmail.setBorder(null);
		textFieldEmail.setBounds(116, 17, 270, 28);
		textFieldEmail.setBackground(new Color(49, 54, 70));
		panelEmail.add(textFieldEmail);
		textFieldEmail.setColumns(10);
		
		JLabel lblAdresse = new JLabel("Adresse Email");
		lblAdresse.setForeground(Color.WHITE);
		lblAdresse.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblAdresse.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdresse.setBounds(0, 20, 112, 28);
		panelEmail.add(lblAdresse);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.WHITE);
		separator.setBorder(new LineBorder(Color.WHITE, 3, true));
		separator.setBounds(116, 46, 270, 2);
		panelEmail.add(separator);
		
		
		panelPassword.setBackground(new Color(49, 54, 70)); 
		panelSlider.add(panelPassword, "name_398792087790000");
		panelPassword.setLayout(null);
		
		passwordField = new JPasswordField();
		passwordField.setToolTipText("Saisissez votre mot de passe");
		passwordField.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
		passwordField.setFont(new Font("Rockwell", Font.PLAIN, 16));
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				 
				if(passwordField.getPassword().length > 0)
				{
					btnValider.setEnabled(true);
				}
				else
				{
					btnValider.setEnabled(false);
				}
			}
		});
		passwordField.setForeground(Color.WHITE);
		passwordField.setBorder(null);
		passwordField.setBounds(107, 18, 279, 29);
		passwordField.setBackground(new Color(49, 54, 70));
		panelPassword.add(passwordField);
		
		JLabel lblNewLabel = new JLabel("Password");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel.setBounds(2, 22, 95, 22);
		panelPassword.add(lblNewLabel);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBorder(new LineBorder(Color.WHITE, 3));
		separator_1.setBounds(108, 47, 276, 2);
		panelPassword.add(separator_1);
		
		
		btnValider.setForeground(Color.WHITE);
		btnValider.setFont(new Font("Rockwell", Font.BOLD, 13));
		btnValider.setToolTipText("Appuyer pour valider");
		
		btnValider.setBackground(new Color(152, 16, 57));
		btnValider.setBounds(304, 264, 120, 24);
		panel_1.add(btnValider);
		
		JPanel panel_audessu = new JPanel();
		panel_audessu.setBackground(Color.WHITE);
		panel_audessu.setBounds(0, 0, 446, 39);
		panel_1.add(panel_audessu);
		panel_audessu.setLayout(new BorderLayout(0, 0));
		
		JLabel lblAuth = new JLabel("AUTHENTIFICATION");
		lblAuth.setForeground(new Color(49, 54, 70));
		lblAuth.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblAuth.setHorizontalAlignment(SwingConstants.CENTER);
		panel_audessu.add(lblAuth, BorderLayout.CENTER);
		
		
		btnreessayer.setForeground(Color.WHITE);
		btnreessayer.setFont(new Font("Rockwell", Font.BOLD, 14));
		btnreessayer.setBounds(24, 264, 120, 24);
		btnreessayer.setBackground(new Color(152, 16, 57));
		panel_1.add(btnreessayer);
		setMinimumSize(new Dimension(450, 300));
		setResizable(false);
		

		
		 this.setLocationRelativeTo(null);
		setSize(new Dimension(450, 335));
		setPreferredSize(new Dimension(450, 400));
		
	}
	

	public JPanel getPanelEmail() {
		return panelEmail;
	}

	public void setPanelEmail(JPanel panelEmail) {
		this.panelEmail = panelEmail;
	}


	public JTextField getTextFieldEmail() {
		
		return textFieldEmail;
	}

	public void setTextFieldEmail(JTextField textFieldEmail) {
		this.textFieldEmail = textFieldEmail;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}

	public JButton getBtnValider() {
		return btnValider;
	}

	public void setBtnValider(JButton btnValider) {
		this.btnValider = btnValider;
	}

	public JButton getBtnreessayer() {
		return btnreessayer;
	}

	public void setBtnreessayer(JButton btnreessayer) {
		this.btnreessayer = btnreessayer;
	}
	
	public JPanelSlider getPanelSlider() {
		return panelSlider;
	}

	public void setPanelSlider(JPanelSlider panelSlider) {
		this.panelSlider = panelSlider;
	}

	public JPanel getPanelPassword() {
		return panelPassword;
	}

	public void setPanelPassword(JPanel panelPassword) {
		this.panelPassword = panelPassword;
	}
	
	public String getvaleurTextFieldEmail()
	{
		String valeurTextField = this.getTextFieldEmail().getText();
		return valeurTextField;
	}
	
	public String getvaleurTextFieldPassword()
	{  
		String valeurTextPassword=String.valueOf(this.getPasswordField().getPassword());
		return valeurTextPassword;
		
	}
	
	public void ressayerMethode()
	{
		textFieldEmail.setText(null);
		passwordField.setText(null);
	}


	public void PrintEchecAuthentification() {
		
		JOptionPane.showMessageDialog(null, "Echec d'Authentification","AUTHENTIFICATION"
		,JOptionPane.INFORMATION_MESSAGE);
	}

	public void addbtnReessayerListener(ActionListener actionListener) {
		btnreessayer.addActionListener(actionListener);
	}

	public void MessageErreur(String message) {		
		JOptionPane.showMessageDialog(null, message,"AUTHENTIFICATION"
				,JOptionPane.ERROR_MESSAGE);
	}

	public void addValiderListner(ActionListener actionListener) {
		btnValider.addActionListener(actionListener);
	}

	public void run()
	{
		this.setVisible(true);
	}

	
	
	

}

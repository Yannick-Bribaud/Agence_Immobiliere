package app.metier.impl;


import java.util.List;

import javax.swing.JComboBox;

import DaoExceptions.DaoException;
import IDao.interfaces.IUserDao;
import UserDao.Implemente.UserDaoImpl;
import app.IMetier.Imetier;
import app.IMetier.exceptions.metierException;
import app.Modele.BienImmobiliers;
import app.Modele.Locataire;
import app.Modele.Paiement;
import app.Modele.RealUsers;

public class Metier implements Imetier {

	@Override
	public void CreationcompteUser(RealUsers user) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		try {
			coucheDao.CreateUser(user);
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}
	}

	@Override
	public void modifiercompteUser(RealUsers user) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		try {
			coucheDao.MisAjourUser(user);
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}

	}

	@Override
	public void suppressionCompteUser(int id) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		try {
			coucheDao.suppressionCompteUser(id);
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}


	}

	@Override
	public List<RealUsers> ListCompteUsers() throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		List<RealUsers> myUsers = null;
		try {
			myUsers = coucheDao.list();
			
			} catch (DaoException e1) {
			
			}
		
		return myUsers;
	}

	@Override
	public void CreationBienImmo(BienImmobiliers bien) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		try {
			coucheDao.AjouterBienImmo(bien);
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}

	}

	@Override
	public void ModifBienImmo(BienImmobiliers bien) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		try {
			coucheDao.UpdateBienImmo(bien);
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}

	}

	@Override
	public List<BienImmobiliers> listDesBien() throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		
			List<BienImmobiliers> Biens = null;
	try {
			Biens = coucheDao.listBien();
			
		} catch (DaoException e1) {
			
		}
		return Biens;
	}

	

	@Override
	public void AffectationDesBien(Locataire locat,BienImmobiliers bien) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		try {
			coucheDao.Affectation(locat, bien);
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}

	}

	@Override
	public void EnregistrerDesPaiements(Paiement paye, Locataire locat) throws metierException {
		
			IUserDao coucheDao = new UserDaoImpl();
		try {
				coucheDao.EnregistrerPaiement(paye, locat);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}

	}

	@Override
	public void ModificationDesPaiements(Paiement paye, Locataire locat) throws metierException {
			IUserDao coucheDao = new UserDaoImpl();
		try {
				coucheDao.ModifierPaiement(paye, locat);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}

	}

	@Override
	public void SupprimerPaiement(int identifiant) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		try {
				coucheDao.SuppressionPaiement(identifiant);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}

	}

	@Override
	public RealUsers AuthentifiacationUser(RealUsers user) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		RealUsers TestUser;
		try {
			TestUser=coucheDao.authentification(user);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		return TestUser;
		
	}

	@Override
	public int TestExistUser(RealUsers user) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		int reponse;
		try {
			reponse=coucheDao.testReussite(user);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		return reponse;
	}

	@Override
	public int TestExistImmobilier(BienImmobiliers bien) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		int reponse;
		try {
			reponse=coucheDao.TestReussiteBienImmo(bien);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		return reponse;
	}

	@Override
	public void ComboConnexion(JComboBox<String> comboBox) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
	
		try {
				coucheDao.ComboConnexion(comboBox);
			
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		
	}

	@Override
	public BienImmobiliers RechercherSelection(String Selection) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		BienImmobiliers bien=null;
		
		try {
			   bien=coucheDao.recherche(Selection);
			
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		
		return bien;
	}

	@Override
	public int VerificationAffectation(Locataire locat) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		int resultat;
		
		try {
				resultat =coucheDao.VerifAffectation(locat);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		return resultat;
	}

	@Override
	public Locataire RechercherLocat(String piece) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		Locataire resultat;
		
		try {
				resultat =coucheDao.rechercheLocataire(piece);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		return resultat;
	}

	@Override
	public BienImmobiliers RechercherById(int identifiant) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		BienImmobiliers resultat;
		
		try {
				resultat =coucheDao.rechercheId(identifiant);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		return resultat;
		
	}

	@Override
	public Paiement ResearchPaiement(Locataire locat, int identifiantbien) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		Paiement resultat;
		
		try {
				resultat =coucheDao.recherchesPaiementLongTerme(locat, identifiantbien);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		return resultat;
	}

	@Override
	public Paiement ResearchPaiementJournalier(Locataire locat, int identifiantbien) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		Paiement resultat;
		
		try {
				resultat =coucheDao.recherchesPaiementJournalier(locat, identifiantbien);
			} catch (DaoException e) {
				
			throw new metierException(e.getMessage());
		}
		
		return resultat;
	
	}

	@Override
	public int VerificationPaiement(int idPaiement) throws metierException {
		IUserDao coucheDao = new UserDaoImpl();
		
		int resultatrecherche=0;
		try {
			
			resultatrecherche = coucheDao.verificationPaiement(idPaiement);
			
		} catch (DaoException e) {
			
			throw new metierException(e.getMessage());
		}
				
		return resultatrecherche;
	}

	@Override
	public List<Paiement> Paye() throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		
		List<Paiement> Paye = null;
		try {
			
			Paye = coucheDao.Paie();
			
			} catch (DaoException e1) {
		}
		
		return Paye;
		
	}

	@Override
	public List<BienImmobiliers> listDesBienDisponibles(String Statut) throws metierException {
		
			IUserDao coucheDao = new UserDaoImpl();
		
		List<BienImmobiliers>Bien = null;
		try {
			
			Bien = coucheDao.listBienDisponible(Statut);
			
			} catch (DaoException e1) {
		}
		
			return Bien;
		
	}

	@Override
	public List<Locataire> ListeDesLocataire() throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		
		List<Locataire>Locat = null;
		try {
			
			Locat = coucheDao.LocatList();
			
			} catch (DaoException e1) {
		}
		
		return Locat;
		
	}

	@Override
	public void SuppressionLocataire(int id) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		try {
			
			coucheDao.deleteLocataire(id);
			
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}
		
		
	}

	@Override
	public void UpdateLocataire(String nom, String Prenom, String numPiece, String genre, String Dnaissance,
			String numTEL, String Email, int id) throws metierException {
		
		IUserDao coucheDao = new UserDaoImpl();
		try {
			
			coucheDao.UpdateLocataire(nom, Prenom, numPiece, genre, Dnaissance, numTEL, Email, id);
			
		} catch (DaoException e) {
			throw new metierException(e.getMessage());
		}
		
		
		
	}

	

}

package app.Controleur;

import java.awt.event.ActionEvent;


import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import app.IMetier.exceptions.metierException;
import app.Modele.BienImmobiliers;
import app.Modele.Locataire;
import app.Modele.Paiement;
import app.Modele.RealUsers;
import app.interfaces.vue.Affectation;
import app.interfaces.vue.AjoutBiens;
import app.interfaces.vue.Authentification;
import app.interfaces.vue.CreateUser;
import app.interfaces.vue.OptionGestionLocat;
import app.interfaces.vue.PaiementInterface;
import app.interfaces.vue.Window;
import app.metier.impl.Metier;
import diu.swe.habib.JPanelSlider.JPanelSlider;

public class ControleurWindow {
	
	RealUsers User;
	Window vueWindows;
	ralentie MonRalentie;
	
	OptionGestionLocat fenetre = new OptionGestionLocat();public ControleurWindow() {
		
	}
	
	
  public ControleurWindow(RealUsers user, Window vueWindows) {
		super();
		User = user;
		this.vueWindows = vueWindows;
		fenetre.setVisible(false);
		fenetre.dispose();
		
		addActionListener();
		AfficheTab();
		TableauPaiement();
		TableauImmobilierENLocation();
		TableauDesLocataire();
		TableauDesBienNonMisEnLocation();
		TableGestLocataire();
		TableImmoAdmin();
		AfficheTabPaiementGestionnaire();
		
	}
	
	

	private void AfficheTabPaiementGestionnaire() {
	
		Metier CoucheMetier = new Metier();
		
		try {
			
			List<Paiement> list = CoucheMetier.Paye();
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTablePaiementGestion().getModel();
			
			Object [] row =new Object [8];
			
			for(int i=0; i<list.size();i++)
			{
				
				row[0]=list.get(i).getIdentifiantPaiement();
				row[1]=list.get(i).getNumPiece();
				row[2]=list.get(i).getCaution();
				row[3]=list.get(i).getLoyer();
				row[4]=list.get(i).getMontantLocationJournalier();
				row[5]=list.get(i).getTranche_1();
				row[6]=list.get(i).getTranche_2();
				row[7]=list.get(i).getTranche_3();
			
				model.addRow(row);
			}
			
		} catch (metierException e) {
			
			vueWindows.MessageListe(e.getMessage());
		}
		
	
}




	private void TableImmoAdmin() {
	
			Metier CoucheMetier = new Metier();
		
		try {
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getPaneTabImmo().getTableImmobilier().getModel();
				List<BienImmobiliers> list = CoucheMetier.listDesBien();
			
			Object [] row =new Object [7];
			
			for(int i=0; i<list.size();i++)
			{
				row[0]=list.get(i).getIdentifiantBien();
				row[1]=list.get(i).getAdresseBien();
				row[2]=list.get(i).getNombrePieces();
				row[3]=list.get(i).getLoyer();
				row[4]=list.get(i).getMontant();
				row[5]=list.get(i).getDetail();
				row[6]=list.get(i).getStatut();
				
				model.addRow(row);
			}
			
		} catch (metierException e) {
			
		  TableException(e.getMessage());
		}
	}
	
			private void TableException(String message) {
		
			JOptionPane.showMessageDialog(null, message, "Table Exception",JOptionPane.ERROR_MESSAGE);
		}





	private void TableGestLocataire() {
		
		Metier CoucheMetier = new Metier();
		
		try {
			
			List<Locataire> list = CoucheMetier.ListeDesLocataire();
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTableGestLocataire().getModel();
			
			Object [] row =new Object [9];
			
			for(int i=0; i<list.size();i++)
			{ 
				row[0]=list.get(i).getIdentifiant_locataire();
				row[1]=list.get(i).getNom_Locataire();
				row[2]=list.get(i).getPrenom_locataire();
				row[3]=list.get(i).getNum_Pieces_Locataire();
				row[4]=list.get(i).getGenre();
				row[5]=list.get(i).getDate_naissance();
				row[6]=list.get(i).getNum_telephone();
				row[7]=list.get(i).getAdresse_mail();
				row[8]=list.get(i).getD_Location();
				
		
				model.addRow(row);
			}
			
		} catch (metierException e) {
			
			vueWindows.MessageListe(e.getMessage());
		}
		
	}


	private void TableauDesBienNonMisEnLocation() {
		
		Metier CoucheMetier = new Metier();
		String Statut = "En Location/Non";
	
	try {
		
		List<BienImmobiliers> list = CoucheMetier.listDesBienDisponibles(Statut);
		
		DefaultTableModel model = (DefaultTableModel)vueWindows.getTableImmoNonMisEnLocation().getModel();
		
		Object [] row =new Object [6];
		
		for(int i=0; i<list.size();i++)
		{
			row[0]=list.get(i).getAdresseBien();
			row[1]=list.get(i).getNombrePieces();
			row[2]=list.get(i).getLoyer();
			row[3]=list.get(i).getMontant();
			row[4]=list.get(i).getDetail();
			row[5]=list.get(i).getStatut();
	
			model.addRow(row);
		}
		
	} catch (metierException e) {
		
		vueWindows.MessageListe(e.getMessage());
	}
		
		
	}


	private void TableauDesLocataire() {
		
			Metier CoucheMetier = new Metier();
		
		try {
			
			List<Locataire> list = CoucheMetier.ListeDesLocataire();
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTableLocataire().getModel();
			
			Object [] row =new Object [9];
			
			for(int i=0; i<list.size();i++)
			{
				row[0]=list.get(i).getIdentifiant_locataire();
				row[1]=list.get(i).getNom_Locataire();
				row[2]=list.get(i).getPrenom_locataire();
				row[3]=list.get(i).getNum_Pieces_Locataire();
				row[4]=list.get(i).getGenre();
				row[5]=list.get(i).getDate_naissance();
				row[6]=list.get(i).getNum_telephone();
				row[7]=list.get(i).getAdresse_mail();
				row[8]=list.get(i).getD_Location();
				
		
				model.addRow(row);
			}
			
		} catch (metierException e) {
			
			vueWindows.MessageListe(e.getMessage());
		}
		
	}


	
	
	private void TableauImmobilierENLocation() {
		
			Metier CoucheMetier = new Metier();
			String Statut = "En Location/Oui";
		
		try {
			
			List<BienImmobiliers> list = CoucheMetier.listDesBienDisponibles(Statut);
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTableImmobilier().getModel();
			
			Object [] row =new Object [7];
			
			for(int i=0; i<list.size();i++)
			{
				row[0]=list.get(i).getAdresseBien();
				row[1]=list.get(i).getNombrePieces();
				row[2]=list.get(i).getMontant();
				row[3]=list.get(i).getLoyer();
				row[4]=list.get(i).getDetail();
				row[5]=list.get(i).getStatut();
		
				model.addRow(row);
			}
			
		} catch (metierException e) {
			
			vueWindows.MessageListe(e.getMessage());
		}
		
	}



	private void TableauPaiement() {
		
		Metier CoucheMetier = new Metier();
		
		try {
			
			List<Paiement> list = CoucheMetier.Paye();
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTableConsulterPaiement().getModel();
			
			Object [] row =new Object [7];
			
			for(int i=0; i<list.size();i++)
			{
				row[0]=list.get(i).getNumPiece();
				//row[1]=list.get(i).getIdentifiantBien();
				row[1]=list.get(i).getCaution();
				row[2]=list.get(i).getLoyer();
				row[3]=list.get(i).getMontantLocationJournalier();
				row[4]=list.get(i).getTranche_1();
				row[5]=list.get(i).getTranche_2();
				row[6]=list.get(i).getTranche_3();
			
				model.addRow(row);
			}
			
		} catch (metierException e) {
			
			vueWindows.MessageListe(e.getMessage());
		}
		
		
	}

	
	
	public void AfficheTab() {
		
		Metier CoucheMetier = new Metier();
		try {
			
			
			List<RealUsers> list = CoucheMetier.ListCompteUsers();
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTableUsers().getModel();
			
			Object [] row =new Object [10];
			
			for(int i=0; i<list.size();i++)
			{
				row[0]=list.get(i).getIdentifiant();
				row[1]=list.get(i).getNom();
				row[2]=list.get(i).getPrenom();
				row[3]=list.get(i).getDateNaissance();
				row[4]=list.get(i).getMotDepasse();
				row[5]=list.get(i).getLogin();
				row[6]=list.get(i).getEmail();
				row[7]=list.get(i).getStatut();
				row[8]=list.get(i).getAdresse();
				row[9]=list.get(i).getNumero_tel();
				
				model.addRow(row);
			}
			
		} catch (metierException e1) {
			
			vueWindows.MessageListe(e1.getMessage());
		}
		
		
	}




	private void addActionListener() {
		
		vueWindows.addActionBtnAuthentification(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ClikOnBtnAuthentification();
				
			}
			
		});
		
		vueWindows.ecouteurBtnCreerUser(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ClikbtnCreerUser();
				
			}
			
		});
		
		vueWindows.ecouteurBtnAddBienImmo(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ClikOnbtnAddBienImmo();				
			}
			
		});
		
		vueWindows.EcouteurBtnAffecter(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ClikBtnAffecter();	
			}
		});
		
		
		vueWindows.ecouteurBtnEnrgistrmentPaiemnt(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				clikOnbtnPaiement();
				
			}
			
		});
		
		vueWindows.ecouteurBtnPaiement(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ClickOnBtnConsulterPaiement();
				
			}
		});
		
		
		vueWindows.EcouteurBtnConsulterDispo(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ClikOnConsulterBien();
				
				
			}
			
		});
		
		vueWindows.EcouteurConsulterLocat(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ClickOnCOnsulterLocataire();
				
			}
			
		});
		
	vueWindows.ecouteurBtnConsulterbienGestionnaire(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelBienNonLocation(), JPanelSlider.left);
			
		}
		
	});
	
	vueWindows.ecouteurBtnListeLocatGest(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelListeLocataire(), JPanelSlider.left);	
		}
		
	});
	
	vueWindows.EcouteurTableGestLocat(new MouseAdapter() {
		
		@Override
		public void mousePressed(MouseEvent e) {
			
			MonRalentie = new ralentie();
			MonRalentie.start();
					
		}
			
	});
	
	fenetre.addEcouteurBtnModifier(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			ClikOnbtnModifier();
			
		}
		
	});
	
	fenetre.addEcouteurBtnSupprimer(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			ClikOnbtnSupprimer();
			
		}
		
	});
	
	vueWindows.EcouteurBtnModif(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			ClickOnbtnModifLocat();
			
		}
		
	});
	
	
	
	vueWindows.ecouteurBtnSupprimerUser(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			try {
				
				ClickOnbtnSupprimer();
				
			}catch(NullPointerException e1) {
				
				vueWindows.MessageErreur(e1.getMessage());
			}
		}
		
	});
	
	
	vueWindows.AddEcouteurBtnModifAdmin(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
		
			try {
				
					ClikAdminModif();
					
			}catch(IllegalArgumentException e4) {
				
				vueWindows.msgException(e4.getMessage());
			}
			
		}
		
	});
	
	vueWindows.addEcouteurBtnModifUser(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			try
			{
			ClickModifierUser();
			}catch(NumberFormatException exc) {
				
				vueWindows.MessAgeFormat(exc.getMessage());
			}
			
			
		}
		
		
	});
	
	vueWindows.AddlistenerbtnModifImmo(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			try
			{
			ClickBtnModifImmo();
			}catch(IllegalArgumentException e3) {
				
				vueWindows.msgIllegalarg(e3.getMessage());
			}
		}
	});
	
	vueWindows.ecouteurBtnPaiementGestion(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			ClickOnBtnConsltGestPaiement();
			
		}
	});
	
	vueWindows.ecouteurBtnModifPaye(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			  ClikBtnModifPaye();
		}
	});
	
	vueWindows.AddecouteurSupprimerPaimnt(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
			ClikBtnSuppPaiment();
			}catch(NullPointerException e5) {
				
				vueWindows.msExceptionSupp(e5.getMessage());
			}
			
		}
	});
		
	}
	

	protected void ClikBtnSuppPaiment() {
		
		
		if(vueWindows.getTablePaiementGestion().getSelectedRow()==-1)
		{
			throw new NullPointerException("Veuillez selectionner une ligne avant de supprimer");
		}
		else
		{
			int reponse = JOptionPane.showConfirmDialog(null, "Voulez-vraiment suprimer ce paiement?", "Confirmation",JOptionPane.YES_NO_OPTION);
			
		if(reponse == JOptionPane.YES_OPTION)
		{
			Metier CoucheMetier = new Metier();
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTablePaiementGestion().getModel();
			int id = (int) model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 0);
			
			try {
				
				CoucheMetier.SupprimerPaiement(id);
				vueWindows.msgSuccesSupp();
				
			} catch (metierException e) {
				
				vueWindows.MessageExcep(e.getMessage());
			}
		}
	}
		
	}


	protected void ClikBtnModifPaye() {
		
		Metier CoucheMetier = new Metier();
		
		int idPaiement = Integer.valueOf(vueWindows.getTextFieldIdPaiement().getText());
  		String numPieces = vueWindows.getTextFieldNumPiecesPaiement().getText();
  		int caution = Integer.valueOf(vueWindows.getTextFieldCautionPaiement().getText());
  		int Loyer =  Integer.valueOf(vueWindows.getTextFieldLoyerPaiement().getText());
  		int MntantJrnalier = Integer.valueOf(vueWindows.getTextFieldMntantJrnPaiemnt().getText());
  		int Tranche1 = Integer.valueOf(vueWindows.getTextFieldTranche1Paiement().getText());
  		int Trenache2 = Integer.valueOf(vueWindows.getTextFieldTranche2Paiement().getText());
  		int Tranche3 = Integer.valueOf(vueWindows.getTextFieldTranche3Paiement().getText());
  		
  		Paiement paye = new Paiement(caution,Loyer,MntantJrnalier,Tranche1,Trenache2,Tranche3);
  		 paye.setIdentifiantPaiement(idPaiement);
  		Locataire Locat =  new Locataire(numPieces);
  		
  		try {
  			
			CoucheMetier.ModificationDesPaiements(paye, Locat);
			vueWindows.msgSucce();
			vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelTabPaiement(), JPanelSlider.right);
			vueWindows.getTablePaiementGestion().clearSelection();
		} catch (metierException e) {
			
			vueWindows.msgExceptions(e.getMessage());
		}
  		
  		
  		
		
	}


	protected void ClickOnBtnConsltGestPaiement() {
		
		if( vueWindows.getTablePaiementGestion().getSelectedRow() == -1)
		{
			vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelTabPaiement(), JPanelSlider.right);
		}
		else
		{

	    	  DefaultTableModel model = (DefaultTableModel)vueWindows.getTablePaiementGestion().getModel();
	  		
	  		String idPaiement = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 0).toString();
	  		String numPieces = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 1).toString();
	  		String caution = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 2).toString();
	  		String Loyer = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 3).toString();
	  		String MntantJrnalier = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 4).toString();
	  		String Tranche1 = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 5).toString();
	  		String Trenache2 = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 6).toString();
	  		String Tranche3 = model.getValueAt(vueWindows.getTablePaiementGestion().getSelectedRow(), 7).toString();
	  		
	  		
	  		vueWindows.getTextFieldIdPaiement().setText(idPaiement);
	  		vueWindows.getTextFieldNumPiecesPaiement().setText(numPieces);
	  		vueWindows.getTextFieldCautionPaiement().setText(caution);
	  		vueWindows.getTextFieldLoyerPaiement().setText(Loyer);
	  		vueWindows.getTextFieldMntantJrnPaiemnt().setText(MntantJrnalier);
	  		vueWindows.getTextFieldTranche1Paiement().setText(Tranche1);
	  		vueWindows.getTextFieldTranche2Paiement().setText(Trenache2);
	  		vueWindows.getTextFieldTranche3Paiement().setText(Tranche3);
	  		
	  		vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelModifPaiement(), JPanelSlider.right);
	  		
	  		
	  		
		}
		
	}







	protected void ClickBtnModifImmo() {
		
		
		DefaultTableModel model = (DefaultTableModel)vueWindows.getPaneTabImmo().getTableImmobilier().getModel();
		Metier CoucheMetier = new Metier();
		
			int id = Integer.valueOf(vueWindows.getTextFieldIdImmo().getText());
			String Adress = vueWindows.getTextFieldAdressImmo().getText();
			int NbrePiece = Integer.valueOf(vueWindows.getTextFieldNbrePiece().getText());
			int Montant =Integer.valueOf(vueWindows.getTextFieldMontantImmo().getText());
			int  Loyer = Integer.valueOf(vueWindows.getTextFieldLoyerImmo().getText());
			String Detail = vueWindows.getTextAreaDetaisImmo().getText();
			String Statut = model.getValueAt(vueWindows.getPaneTabImmo().getTableImmobilier().getSelectedRow(), 6).toString();
			
  		
  		if(Adress.isEmpty() || NbrePiece ==0 || Montant==0 || Loyer==0 || Detail.isEmpty())
  		{
  			throw new IllegalArgumentException("Fournisser des valeurs svp");
  		}
  		else
  		{
  			BienImmobiliers Immo =  new BienImmobiliers(Adress,NbrePiece,Montant,Loyer,Detail,Statut);
  			Immo.setIdentifiantBien(id);
  		
  			try {
  			
  				CoucheMetier.ModifBienImmo(Immo);
  				vueWindows.msgsucceModif();
  				vueWindows.clearPanelInmmo();
  				vueWindows.getPane().getTableImmobilier().clearSelection();
  				vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelAdminTab(), JPanelSlider.right);
			
  			} catch (metierException e) {
			
			vueWindows.msgError(e.getMessage());
		}
  	}
  		
  		
  		
		
		
	}




	protected void ClickModifierUser() {
		
		
		DefaultTableModel model = (DefaultTableModel)vueWindows.getTableUsers().getModel();
		Metier CoucheMetier = new Metier();
		
		int id = Integer.valueOf(vueWindows.getTextFieldIdUser().getText());
  		String nomUser = vueWindows.getTextFieldUsername().getText();
  		String PrenomUser = vueWindows.getTextFieldUserLastname().getText();
  		String Date =vueWindows.getTextFieldUserNaissance().getText();
  		String Mdp = vueWindows.getTextFieldUserMdp().getText();
  		String Login = vueWindows.getTextFieldUserLogin().getText();
  		String Email = vueWindows.getTextFieldUserEmail().getText();
  		String Adrees = vueWindows.getTextFieldUserAdress().getText();
  		String NumeroTel = vueWindows.getTextFieldNumTelphUser().getText();
  		String Statut = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 7).toString();
  		
  		if(nomUser.isEmpty()|| PrenomUser.isEmpty() || Date.isEmpty() || Mdp.isEmpty() || Login.isEmpty() || Email.isEmpty() || Adrees.isEmpty()
  				|| NumeroTel.isEmpty() || Statut.isEmpty())
  		{
  			throw new NumberFormatException("Veuillez Fournir des donnees svp!!!");
  		}
  		else
  		{
  		
  		User = new RealUsers(nomUser, PrenomUser, Adrees, NumeroTel, Login, Mdp, Date, Email, Statut);
  		User.setIdentifiant(id);
  		
  		try {
  			
			CoucheMetier.modifiercompteUser(User);
			vueWindows.MessageReussite();
			vueWindows.clear();
			vueWindows.getTableUsers().clearSelection();
			vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelAdminTab(), JPanelSlider.left);
			
			
		} catch (metierException e) {
			
			vueWindows.MessageException(e.getMessage());
		}
  	}
  		
	}






	protected void ClikAdminModif() {
		

      if(vueWindows.getTableUsers().getSelectedRow()!=-1 && vueWindows.getPane().getTableImmobilier().getSelectedRow()==-1)
      {
    	  vueWindows.getBtnModifImmo().setVisible(false);
    	  DefaultTableModel model = (DefaultTableModel)vueWindows.getTableUsers().getModel();
  		
  		String id = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 0).toString();
  		String nomUser = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 1).toString();
  		String PrenomUser = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 2).toString();
  		String Date = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 3).toString();
  		String Mdp = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 4).toString();
  		String Login = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 5).toString();
  		String Email = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 6).toString();
  		String Adrees = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 8).toString();
  		String NumeroTel = model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 9).toString();
  		
  		
  		vueWindows.getTextFieldIdUser().setText(id);
  		vueWindows.getTextFieldUsername().setText(nomUser);
  		vueWindows.getTextFieldUserLastname().setText(PrenomUser);
  		vueWindows.getTextFieldUserLogin().setText(Login);
  		vueWindows.getTextFieldUserMdp().setText(Mdp);
  		vueWindows.getTextFieldUserAdress().setText(Adrees);
  		vueWindows.getTextFieldUserNaissance().setText(Date);
  		vueWindows.getTextFieldNumTelphUser().setText(NumeroTel);
  		vueWindows.getTextFieldUserEmail().setText(Email);
  		
  		
    	vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelModifUserPane(), JPanelSlider.left);
    	 
      }
      
      
      
      if(vueWindows.getTableUsers().getSelectedRow()==-1 && vueWindows.getPane().getTableImmobilier().getSelectedRow()!=-1)
      {
    	  
    	  
    	  vueWindows.getBtnModifImmo().setVisible(true);
    	  	DefaultTableModel model = (DefaultTableModel)vueWindows.getPaneTabImmo().getTableImmobilier().getModel();
    		
    		String id = model.getValueAt(vueWindows.getPaneTabImmo().getTableImmobilier().getSelectedRow(), 0).toString();
    		String AddImmo = model.getValueAt(vueWindows.getPaneTabImmo().getTableImmobilier().getSelectedRow(), 1).toString();
    		String NbrePieces = model.getValueAt(vueWindows.getPaneTabImmo().getTableImmobilier().getSelectedRow(), 2).toString();
    		String Montant = model.getValueAt(vueWindows.getPaneTabImmo().getTableImmobilier().getSelectedRow(), 3).toString();
    		String Loyer = model.getValueAt(vueWindows.getPaneTabImmo().getTableImmobilier().getSelectedRow(), 4).toString();
    		String details = model.getValueAt(vueWindows.getPaneTabImmo().getTableImmobilier().getSelectedRow(), 5).toString();
    		
    		vueWindows.getTextFieldIdImmo().setText(id);
    		vueWindows.getTextFieldAdressImmo().setText(AddImmo);
    		vueWindows.getTextFieldLoyerImmo().setText(Loyer);
    		vueWindows.getTextFieldMontantImmo().setText(Montant);
    		vueWindows.getTextFieldNbrePiece().setText(NbrePieces);
    		vueWindows.getTextAreaDetaisImmo().setText(details);
    		
    		
    		vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelModifImmo(), JPanelSlider.left);
    		  
      }
      
      if(vueWindows.getTableUsers().getSelectedRow()==-1 && vueWindows.getPane().getTableImmobilier().getSelectedRow()==-1)
      {
    	  throw new IllegalArgumentException("Aucune ligne � modifier,veuillez selectionner dans le tableau");
      }
      
	
        
	}


	protected void ClickOnbtnSupprimer() {
		
		if(vueWindows.getTableUsers().getSelectedRow()==-1)
		{
			throw new NullPointerException("Veuillez selectionner une ligne avant de supprimer");
		}
		else
		{
			int reponse = JOptionPane.showConfirmDialog(null, "Voulez-vraiment suprimer cet Utilisateur?", "Confirmation",JOptionPane.YES_NO_OPTION);
			
		if(reponse == JOptionPane.YES_OPTION)
		{
			Metier CoucheMetier = new Metier();
			
			DefaultTableModel model = (DefaultTableModel)vueWindows.getTableUsers().getModel();
			int id = (int) model.getValueAt(vueWindows.getTableUsers().getSelectedRow(), 0);
			
			try {
				
				CoucheMetier.suppressionCompteUser(id);
				vueWindows.msgSuceesuppUser();
			} catch (metierException e) {
				
				vueWindows.MessageExcep(e.getMessage());
			}
			
			
			
			
		}
	}
		
	}



	protected void ClickOnbtnModifLocat() {
		
		String nom = vueWindows.getTextFieldModifNomLocat().getText();
		String prenom = vueWindows.getTextFieldModifPrenom().getText();
		String NumP = vueWindows.getTextFieldModifNumPieces().getText();
		String genre = vueWindows.getTextFieldModifGenre().getText();
		String date = vueWindows.getTextFieldModifDate().getText();
		String NumTel = vueWindows.getTextFieldModifTelph().getText();
		String Email = vueWindows.getTextFieldModifEmail().getText();
		int id = Integer.valueOf(vueWindows.getTextFieldId().getText());
		
		Metier CoucheMetier = new Metier();
		
		try {
			
			CoucheMetier.UpdateLocataire(nom, prenom, NumP, genre, date, NumTel, Email, id);
			
			fenetre.MessageReussite();
			
		} catch (metierException e) {
			
			fenetre.MessageEX(e.getMessage());
		}
		
		
		
	}



	protected void ClikOnbtnSupprimer() {
		
		DefaultTableModel model = (DefaultTableModel)vueWindows.getTableGestLocataire().getModel();
		int id = (int) model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 0);
		
		Metier CoucheMetier = new Metier();
		
		try {
			
			int reponse = JOptionPane.showConfirmDialog(null, "Voulez-vraiment suprimer ?", "Confirmation",JOptionPane.YES_NO_OPTION);
			
			if(reponse == JOptionPane.YES_OPTION)
			{
				CoucheMetier.SuppressionLocataire(id);
				fenetre.dispose();
				fenetre.MessageReusste();
			}
			else
			{
				fenetre.dispose();
			}
			
			
		} catch (metierException e) {
			
			fenetre.MessageEX(e.getMessage());
		}
		
	}






	protected void ClikOnbtnModifier() {
		
		DefaultTableModel model = (DefaultTableModel)vueWindows.getTableGestLocataire().getModel();
		
		String id = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 0).toString();
		String nomLocat = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 1).toString();
		String PrenomLocat = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 2).toString();
		String numPiecesLocat = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 3).toString();
		String genre = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 4).toString();
		String Dnaissance = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 5).toString();
		String numTelPhone = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 6).toString();
		String AdressMail = model.getValueAt(vueWindows.getTableGestLocataire().getSelectedRow(), 7).toString();
		
		vueWindows.getTextFieldId().setText(id);
		vueWindows.getTextFieldModifNomLocat().setText(nomLocat);
		vueWindows.getTextFieldModifPrenom().setText(PrenomLocat);
		vueWindows.getTextFieldModifNumPieces().setText(numPiecesLocat);
		vueWindows.getTextFieldModifGenre().setText(genre);
		vueWindows.getTextFieldModifDate().setText(Dnaissance);
		vueWindows.getTextFieldModifTelph().setText(numTelPhone);
		vueWindows.getTextFieldModifEmail().setText(AdressMail);
		
		fenetre.dispose();
		vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelModificationLocat(), JPanelSlider.left);
		
	}



	protected void ClickOnCOnsulterLocataire() {
		
		vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelLocataire(), JPanelSlider.left);
		
	}


	protected void ClikOnConsulterBien() {
		
		vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelTabImmo(), JPanelSlider.left);
		
	}



	protected void ClickOnBtnConsulterPaiement() {
		
		vueWindows.getPanelSliderDebord().nextPanel(1, vueWindows.getPanelConsulterPaiement(), JPanelSlider.left);
		
		
	}


	protected void clikOnbtnPaiement() {
		
		PaiementInterface vue =new PaiementInterface();
		Paiement model= new Paiement();
		
		ControleurPaiement control = new ControleurPaiement(vue,model);
		control.run();
		
	}



	protected void ClikBtnAffecter() {
		
		Affectation vue = new Affectation();
		Locataire model = new Locataire();
		ControleurAffectation controleur = new ControleurAffectation(vue,model);
		controleur.run();
		
	}

	protected void ClikOnbtnAddBienImmo() {
		
		BienImmobiliers model = new BienImmobiliers();
		AjoutBiens vue =new AjoutBiens();
		ControleurAjoutBien controleur = new ControleurAjoutBien(vue,model);
		controleur.run();
	}
	
	
	protected void ClikbtnCreerUser() {
		
		CreateUser vue = new CreateUser();
		RealUsers model = new RealUsers("","");
		ControleurCreateUser controleur = new ControleurCreateUser(vue,model);
		controleur.run();
		
	}
	protected void ClikOnBtnAuthentification() {
		
	      User = new RealUsers("","");
		  Authentification vue =new Authentification();
		  ControleurAuthentification control = new ControleurAuthentification(User,vue,vueWindows);
		  control.run();
	}
	
	
	public void run()
	{
		vueWindows.runWindows();
	}
	
	
	
   class ralentie extends Thread{
		
		ralentie(){	
		}
		
		@Override
		  public void run() {
			
			try {
				
				sleep(700);
				
				if(fenetre.isVisible())
				{
					fenetre.dispose();
					fenetre.run();
				}
				else
				{
					fenetre.run();
				}
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}

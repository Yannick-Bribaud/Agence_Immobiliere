package app.Controleur;

import java.awt.event.ActionEvent;


import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import app.IMetier.exceptions.metierException;
import app.Modele.BienImmobiliers;
import app.Modele.Locataire;
import app.Modele.Paiement;
import app.interfaces.vue.PaiementInterface;
import app.metier.impl.Metier;
import diu.swe.habib.JPanelSlider.JPanelSlider;

public class ControleurPaiement {
	
	PaiementInterface vue;
	Paiement model;
	
	public ControleurPaiement(PaiementInterface vue, Paiement model) {
		super();
		this.vue = vue;
		this.model = model;
		
		addActionListener();
	}

	private void addActionListener() {
		
		vue.addEcouteurBtnRechercher(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
						ClikSurRechercher();
						
				}catch(IllegalArgumentException ex7) {
					
					vue.MessageExceptionIllegal();
					
				}catch(NullPointerException except) {
					
					vue.MessageNoncorrespondance();
					
				}
				
			}
			
		});
		vue.ecouteurBtnTerminer(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				clikbtnTerminer();
				
			}
			
		});
		
		
		
		vue.EcouteurBtnRadio(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(vue.getRadiobtnNvoPaiement().isSelected())
				{ 
					try {
						vue.getBtnPayerJournalier().setVisible(true);
						
							ClickOnradioBtnNvoPaiement();
							
					}catch(IllegalArgumentException excption) {
						
						vue.Excption();
							
					}catch(NullPointerException excpt) {
						
						vue.MessageInexistantLocat();	
					}
				}	
				else
				{
					vue.getRdioBtnAjoutPaiement().setEnabled(true);
					vue.getPanelSliderPaiementField().nextPanel(1, vue.getPanelAcceuil(), JPanelSlider.left);
				}
				
				
			}
			
				
		});
		
		vue.EcouteurBtnRadioAjoutPaiement(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					if(vue.getRdioBtnAjoutPaiement().isSelected())
					{
						ClikbtnradionAjoutPaiement();
					}
					else
					{
						vue.getRadiobtnNvoPaiement().setEnabled(true);
						
						vue.getPanelSliderPaiementField().nextPanel(1, vue.getPanelAcceuil(), JPanelSlider.right);
					}
				}catch(IllegalArgumentException ex4) {
					
					vue.Avertissement();
					
				}catch(NullPointerException excepts) {
					
					vue.inexistLocat();
				}
				
				
			}
			
		});
		
		
		vue.EcouteurbtnPayerLongtermeNvoPaiment(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					ClikBtnOnPayerLngTerme();
					
				}catch(IllegalArgumentException ex3) {
					
					vue.MessIllegalargument(ex3.getMessage());
					
				}catch(NullPointerException e9) {
					
					vue.MessageNullPointer(e9.getMessage());
					
				}
			}
			
		});
		
		
		vue.addEcouteurBtnPayerJournalier(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				try
				{
						ClikOnbtnPayerJournalier();
				
				}catch(IllegalArgumentException ex1) {
					
					vue.MessExceptions(ex1.getMessage());
					
				}catch(NullPointerException ex2) {
					
					vue.MessChampsvide(ex2.getMessage());
				}
				
			}
			
		});
	}

		
		protected void clikbtnTerminer() {
		vue.dispose();
		
	}

		protected void ClikOnbtnPayerJournalier() {
			
			String MontantJrnalier = vue.getTextFieldMontant_Journalier().getText();
			String trancheOne = vue.getTranche_1_Field().getText();
			String trancheTwo = vue.getTranche_2_Field().getText();
			String tranchethree = vue.getTranche_3_Field().getText();
			String Numpiece = vue.getNumPiecesField();
			Locataire locataire = new Locataire();
			Metier CoucheMetier = new Metier();
			Paiement paye = new Paiement();
			int testpaiement=0;int Rsult=0;
			
			
		
					if(Numpiece.isEmpty())
					{
						throw new IllegalArgumentException("Num�ro de la Pi�ce Invalide ou non saisie");
					}
					else
					{       if(vue.getRadiobtnNvoPaiement().isSelected() || vue.getRdioBtnAjoutPaiement().isSelected()) 
							{
								if(!MontantJrnalier.isEmpty() && !Numpiece.isEmpty())
								{
								    if(trancheOne.equals("") && trancheTwo.equals("") && tranchethree.equals(""))
								    {
								    	int montantJr = Integer.valueOf(MontantJrnalier);
								    	
								    	try {
									    		locataire=CoucheMetier.RechercherLocat(Numpiece);
									    		
									    		if(!locataire.getNum_Pieces_Locataire().equals(""))
									    		{
									    			paye = new Paiement(montantJr);
									    			testpaiement=paye.getIdentifiantPaiement();
									    			CoucheMetier.EnregistrerDesPaiements(paye,locataire);
									    			Rsult=CoucheMetier.VerificationPaiement(testpaiement);
									    			if(Rsult==1) { vue.Succes(); vue.clear();}
									
									    		}
									    		else
									    		{
									    			throw new NullPointerException("Locataire inexistant");
									    		}
											
										} catch (metierException e7) {
											
											vue.MessageErrPaiement(e7.getMessage());
										}
								    }
								    else
								    {
								    	throw new IllegalArgumentException("Remplissez qu'un seul champs");
								    }
								}
								
								
								
								if(!trancheOne.isEmpty() && !Numpiece.isEmpty())
								{
									if(MontantJrnalier.isEmpty() && trancheTwo.isEmpty() && tranchethree.isEmpty())
									{
										int tranche1 = Integer.valueOf(trancheOne);
										
										try {
											locataire=CoucheMetier.RechercherLocat(Numpiece);
											
											if(!locataire.equals(null))
											{
												paye = new Paiement(tranche1,0,0);
												testpaiement=paye.getIdentifiantPaiement();
								    			CoucheMetier.EnregistrerDesPaiements(paye,locataire);
								    			Rsult=CoucheMetier.VerificationPaiement(testpaiement);
								    			if(Rsult==1) { vue.Succes(); vue.clear();}
											}
											else
											{
												throw new NullPointerException("Locataire inexistant");
											}
											
										} catch (metierException e6) {
											
											vue.MessageErrorss(e6.getMessage());
										}
									}
									else
									{
										throw new IllegalArgumentException("Remplissez qu'un seul champs");
									}	
								}
								
								
								
								if(!trancheTwo.isEmpty() && !Numpiece.isEmpty())
								{
									if(MontantJrnalier.isEmpty() && trancheOne.isEmpty() && tranchethree.isEmpty())
									{
										int tranche2 = Integer.valueOf(trancheTwo);
										
										try {
											
											locataire=CoucheMetier.RechercherLocat(Numpiece);
											
											if(!locataire.equals(null))
											{
												paye = new Paiement(0,tranche2,0);
												testpaiement=paye.getIdentifiantPaiement();
								    			CoucheMetier.EnregistrerDesPaiements(paye,locataire);
								    			Rsult=CoucheMetier.VerificationPaiement(testpaiement);
								    			if(Rsult==1) { vue.Succes(); vue.clear();}
								    			
											}
											else
											{
												throw new NullPointerException("Locataire inexistant");
											}
											
										} catch (metierException e5) {
											
											vue.MessageErrors(e5.getMessage());
										}
									}
									else
									{
										throw new IllegalArgumentException("Remplisser qu'un seul champs");
									}
								}
								
								if(!tranchethree.isEmpty() && !Numpiece.isEmpty())
								{
									if(MontantJrnalier.isEmpty() && trancheOne.isEmpty() && trancheTwo.isEmpty())
									{
										int tranche3 = Integer.valueOf(tranchethree);
										
										try {
												locataire=CoucheMetier.RechercherLocat(Numpiece);
											
											if(!locataire.equals(null))
											{
												paye = new Paiement(0,0,tranche3);
												testpaiement=paye.getIdentifiantPaiement();
								    			CoucheMetier.EnregistrerDesPaiements(paye,locataire);
								    			Rsult=CoucheMetier.VerificationPaiement(testpaiement);
								    			if(Rsult==1) { vue.Succes(); vue.clear();}
											}
											else
											{
												throw new NullPointerException("Locataire inexistant");
											}
											
										} catch (metierException e4) {
											
											vue.MessageError(e4.getMessage());
										}
									}
									else
									{
										throw new IllegalArgumentException("Remplissez qu'un seul champs");
									}
								}
								
								if(tranchethree.isEmpty() && MontantJrnalier.isEmpty() && trancheOne.isEmpty() && trancheTwo.isEmpty())
								{
									throw new NullPointerException("Remplissez tout au plus un champs");
								}
								
									
									
							}
					}
				}
		

	
	protected void ClikBtnOnPayerLngTerme() {
		
		
		String valeur = String.valueOf(vue.getNumPiecesField());
		String cautionChar= vue.getTextFieldCaution().getText();
		String Mensualit�Char = vue.getTextFieldMensualit�().getText();
		int caution = Integer.valueOf(vue.getTextFieldCaution().getText());
		int mensualit� = Integer.valueOf(vue.getTextFieldMensualit�().getText());
		Locataire locataire=new Locataire();
		Metier coucheMetier= new Metier();
		Paiement paye = new Paiement();
		int testpaiemnt=0; int Rsult=0;
		
		
		
			if(valeur.isEmpty())
			{
				throw new IllegalArgumentException("Entrez le num�ro de la pi�ce d'identit� svp!!!");
			}
			else
			{
				try {
						locataire=coucheMetier.RechercherLocat(valeur);
						
					if(!locataire.equals(null))
					{ 
						if(vue.getRadiobtnNvoPaiement().isSelected())
						{
							
							if(cautionChar.equals("")||Mensualit�Char.equals(""))
							{
								throw new IllegalArgumentException("Donner des valeurs au champs");
							}
							else
							{
								paye = new Paiement(caution,mensualit�,0,0,0,0);
								testpaiemnt=paye.getIdentifiantPaiement();
								coucheMetier.EnregistrerDesPaiements(paye, locataire);
								Rsult = coucheMetier.VerificationPaiement(testpaiemnt);
								if(Rsult==1) { vue.Succes(); vue.clear();}
							}	
						}
						
						else if(vue.getRdioBtnAjoutPaiement().isSelected())
						{
							if(Mensualit�Char.isEmpty())
							{
								throw new IllegalArgumentException("Donner la valeur du champs");
							}
							else
							{
								paye = new Paiement(0,mensualit�,0,0,0,0);
								testpaiemnt = paye.getIdentifiantPaiement();
								coucheMetier.EnregistrerDesPaiements(paye, locataire);
								Rsult=coucheMetier.VerificationPaiement(testpaiemnt);
								if(Rsult==1) { vue.Succes(); vue.clear();}
							}
						}
						else
						{
							vue.MessageIndication();
						}
						
					}
					else
					{
						 throw new NullPointerException("Locataire inexistant");
					}
					
				} catch (metierException e3) {
					
					vue.MessageSError(e3.getMessage());
				}
			}
		
	}

	protected void ClikbtnradionAjoutPaiement() {
		
		
		String value=String.valueOf(vue.getNumPiecesField());
		Locataire locataire =new Locataire();
		Paiement paye = new Paiement();
		int id=0;
		
		vue.getRadiobtnNvoPaiement().setSelected(false);
		vue.getRadiobtnNvoPaiement().setEnabled(false);
		vue.getTextFieldCaution().setText("000");
		vue.getTextFieldMensualit�().setText("");
		
		
		if(value.equals(""))
		{
			throw new IllegalArgumentException("Entrez le num�ro de la pi�ce d'identit� svp!!!");
		}
		else
		{
			Metier coucheMetier = new Metier();
			try {
				   locataire=coucheMetier.RechercherLocat(value);
				   id=locataire.getIdentifiant_locataire();
				   
				   if(!locataire.equals(null))
				   {
					   
					   if(locataire.getD_Location().equalsIgnoreCase("Location/A Long Terme"))
					   {
						   	vue.getBtnPayerJournalier().setVisible(false);
						   	paye=coucheMetier.ResearchPaiement(locataire,id);
						   	vue.getPanelCaution().setVisible(false);
						   
						   	String caracteristique;
						   	caracteristique="<html>Caution = "+paye.getCaution()+ "<br>"+"Loyer Total pay� = "+paye.getLoyer()+"</html>";
						   
						   	JOptionPane Optionpane = new JOptionPane();
						   	Optionpane.setMessage(caracteristique);
							Optionpane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
							
							JDialog Boitedialog=Optionpane.createDialog(null,"PAIEMENT LONG A TERME");
							
							Boitedialog.setVisible(true);
							
							vue.getPanelSliderPaiementField().nextPanel(1, vue.getPanelPaiement_LongTerme(), JPanelSlider.left);
					   }
					   else
					   {
						   paye=coucheMetier.ResearchPaiementJournalier(locataire, id);
						   
						   String caracteristique;
						   caracteristique="<html>Montant Journalier Pay� = "+paye.getMontantLocationJournalier()+ "<br>"+"1ere Tranche = "+paye.getTranche_1()+
								   "<br>"+"2eme Tranche = "+paye.getTranche_2()+"<br>"+"3eme Tranche ="+paye.getTranche_3()+"</html>";
						   
						   	JOptionPane Optionpane = new JOptionPane();
						   	Optionpane.setMessage(caracteristique);
							Optionpane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
							
							JDialog Boitedialog=Optionpane.createDialog(null,"PAIEMENT JOURNALIER");
							
							Boitedialog.setVisible(true);
							
							vue.getPanelSliderPaiementField().nextPanel(1, vue.getPanelJournaliere_tranche(), JPanelSlider.left);
							vue.getBtnPayerJournalier().setVisible(true);
					   }
				   }
				   else
				   {
					   throw new  NullPointerException("Locataire Inexistant");
				   }
				 
			} catch (metierException e2) {
				
				vue.messageErreur(e2.getMessage());
			}
		}
		
		
	}

	protected void ClickOnradioBtnNvoPaiement() {
		
			String value=String.valueOf(vue.getNumPiecesField());
			Locataire locataire =new Locataire();
			vue.clear();
			
			vue.getRdioBtnAjoutPaiement().setSelected(false);
			vue.getRdioBtnAjoutPaiement().setEnabled(false);
			vue.getPanelCaution().setVisible(true);
			
			
			if(value.equals(""))
			{
				throw new IllegalArgumentException("Entrez le num�ro de la pi�ce d'identit� svp!!!");
			}
			else
			{
				Metier CoucheMetier = new Metier();
				try {
					
						locataire=CoucheMetier.RechercherLocat(value);
						
					if(!locataire.equals(null))
					{
						
						if(locataire.getD_Location().equalsIgnoreCase("Location/A Long Terme"))
						{
							vue.getPanelSliderPaiementField().nextPanel(1, vue.getPanelPaiement_LongTerme(), JPanelSlider.left);
						}
						else
						{
							vue.getPanelSliderPaiementField().nextPanel(1, vue.getPanelJournaliere_tranche(), JPanelSlider.left);
						}	
					}
					else
					{
						throw new NullPointerException("Locataire Inexistant");
					}
						
				} catch (metierException e1) {
					
					vue.MessageExceptionMetieer(e1.getMessage());	
				}
			}
	}

	protected void ClikSurRechercher() {
		
		String numPiece=String.valueOf(vue.getNumPiecesField());
		Locataire locataire =new Locataire();
		BienImmobiliers bien = new BienImmobiliers();
		int IdBienImmobilier=0;
		
		
		if(numPiece.equals(""))
		{
			throw new IllegalArgumentException("Entrez le num�ro de la pi�ce d'identit� svp!!!");
		}
		else
		{
				Metier CoucheMetier = new Metier();
				
			try {
					locataire=CoucheMetier.RechercherLocat(numPiece);
				
				if(!locataire.equals(null))
				{
					
					IdBienImmobilier=locataire.getIdentifiant_locataire();
					bien=CoucheMetier.RechercherById(IdBienImmobilier);
					
				  vue.getLabelAfficheNom().setText(locataire.getNom_Locataire());
				  vue.getLabelAffichePrenom().setText(locataire.getPrenom_locataire());
				  vue.getLabelContrat().setText(locataire.getD_Location());
				  vue.getLabelAfficheDetails().setText(bien.getDetail());
				  vue.getLabelAfficheMontant().setText((String.valueOf(bien.getMontant())));
				  vue.getLabelAfficheLoyer().setText(String.valueOf(bien.getLoyer()));
				  vue.getLabelAfficheNbrePieces().setText(String.valueOf(bien.getNombrePieces()));
				 			
				}
				else
				{
					throw new RuntimeException("Locataire Inexistant");
				}	
			}catch (metierException e) {
				
				vue.MessageException(e.getMessage());
			}
		}
		
	}
	
    
	
	public void run()
	{
		vue.run();
	}
}

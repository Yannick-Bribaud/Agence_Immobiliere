package app.Controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import app.IMetier.exceptions.metierException;
import app.Modele.BienImmobiliers;
import app.interfaces.vue.AjoutBiens;
import app.metier.impl.Metier;

public class ControleurAjoutBien {
	
	private AjoutBiens vue;
	private BienImmobiliers model;
	
	
	public ControleurAjoutBien(AjoutBiens vue, BienImmobiliers model) {
		super();
		this.vue = vue;
		this.model = model;
		
		addActionListener();
	}


	private void addActionListener() {
		
		vue.addEcouteurBtnAjouter(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					ClikOnbtnAjouter();
					
				}catch(IllegalArgumentException ex) {
					
					vue.MessageExcption(ex.getMessage());
				}
				
			}
			
		});
		
		
		vue.addEcouteurBtnTerminer(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				OnBtnTerminerClik();
				
			}
			
		});
		
	}


	protected void OnBtnTerminerClik() {
		
		vue.dispose();
		
	}


	protected void ClikOnbtnAjouter() {
		
		int Montant; int loyer; int NbrePieces;
		
		if(vue.getAdressetextField().isEmpty()|| vue.getTextFieldMontant().isEmpty()||vue.getTextFieldNbrePiece().isEmpty() ||vue.getLoyertextField().isEmpty())
		{
			 throw new IllegalArgumentException("Veuillez renseigner tous les champs svp !!!");
		}
		else 
		{
			
			try {
				
					Montant = Integer.parseInt(vue.getTextFieldMontant());
					loyer = Integer.parseInt(vue.getLoyertextField());
					NbrePieces = Integer.parseInt(vue.getTextFieldNbrePiece());
					
				model= new BienImmobiliers(vue.getAdressetextField(),NbrePieces,Montant,loyer,vue.getTextArea(),vue.getMisEnLocationCheckBox());
				Metier CoucheMetier = new Metier();
				try {
					
					
					CoucheMetier.CreationBienImmo(model);
					
					int resultat=CoucheMetier.TestExistImmobilier(model);
					if(resultat==1)
					{
						vue.MessageSucces();
						vue.clear();
					}
					else
					{
						vue.MessageEchec();
					}
					
					
				} catch (metierException e) {
				    
					vue.MessageException(e.getMessage());
				}
				
			}catch(NumberFormatException e) {
				
				vue.MessageError(e.getMessage());	
			}
		    	
			
		}
	}
	
	
	public void run() {
		vue.run();
	}
	
	
	
	

}

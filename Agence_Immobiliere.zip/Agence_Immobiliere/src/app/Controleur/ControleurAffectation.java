package app.Controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import app.IMetier.exceptions.metierException;
import app.Modele.BienImmobiliers;
import app.Modele.Locataire;
import app.interfaces.vue.Affectation;
import app.metier.impl.Metier;

public class ControleurAffectation {
	
	Affectation vue;
	Locataire model;
	Metier metier = new Metier();
	
	
	public ControleurAffectation(Affectation vue, Locataire model) {
		super();
		this.vue = vue;
		this.model = model;
		addActionListener();
		addItemListener();
		
		
		try {
			
			metier.ComboConnexion(vue.getComboBoxImmobilier());
		  	} catch (metierException e) {
			
			vue.MessageConnexion(e.getMessage());
		  }
		
	}
	
	//Creation bienImmobilier
	 BienImmobiliers bien=new BienImmobiliers();
	
	
	

	private void addItemListener() {
		vue.addEcouteurSelectionCombox(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==ItemEvent.SELECTED)
				{
					IemSelected();
				}
				
			}
			
		});
		
	}







	protected void IemSelected() {
		
		
		if(!vue.getComboBoxImmobilier().getSelectedItem().toString().equalsIgnoreCase("                     ---S�lectionner---"))
		{
				String selection=vue.getComboBoxImmobilier().getSelectedItem().toString();
			
					
			try {
				
						bien=metier.RechercherSelection(selection);
				
					if(bien.equals(null))
					{
						vue.MessageResultat();	
					}
					else
					{
						String caracteristique;
						caracteristique="<html>Adresse = "+bien.getAdresseBien()+ "<br>"+"Nombre Pi�ces = "+bien.getNombrePieces()+"<br>"
							        +"Montant = "+bien.getMontant()+"<br>"+"Loyer = "+bien.getLoyer()+"<br>"+"Detail = "+bien.getDetail()+"</html>";
						
						JOptionPane Optionpane = new JOptionPane();
						Optionpane.setMessage(caracteristique);
						Optionpane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
						JDialog Boitedialog=Optionpane.createDialog(null,"CARACTERISTIQUES IMMOBILIER");
						
						vue.getCheckBoxLongterm().setEnabled(true);
			    		vue.getCheckBoxJournaliere().setEnabled(true);
			    		
			    		Boitedialog.setVisible(true);
					}
				
			} catch (metierException e) {
				
				vue.ErrorMessage(e.getMessage());
			}
			
		}
		else
		{
			vue.Reset();
			
			vue.getCheckBoxJournaliere().setSelected(false);
			vue.getCheckBoxLongterm().setEnabled(false);
			vue.getCheckBoxLongterm().setSelected(false);
    		vue.getCheckBoxJournaliere().setEnabled(false);
    		 
			
			
		}
		
	}







	private void addActionListener() {
		
		vue.addEcouteurbtnAffecter(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					ClikbtnAffecter();
					
				  }catch(IllegalArgumentException ex){
					
					vue.MessageErreurChamps(ex.getMessage());	
				}
			}
			
		});
		
		vue.EcouteurBtnTerminer(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				vue.dispose();
				
			}
			
		});
		
	}

	protected void ClikbtnAffecter() {
		
	       String nom = vue.getTextFieldNom();
	       String prenom = vue.getTextFieldPrenom();
	       String numPiece = vue.getNumPiecetextField();
	       String numerotelph = vue.getNumTeltextField();
	       String Email = vue.getEmailTextField();
	       String genre="";
	       String date;
	       String TermeContrat="";
	       if(vue.getComboBoxJour().equals("0")|| vue.getComboBoxMois().equals("0"))
	       {
	    	   date="";
	       }
	       else
	       {
	    	   date = vue.getComboBoxJour()+"/"+vue.getComboBoxMois()+"/"+vue.getComboBoxAnnee(); 
	       }
	       
	       if(vue.getRadioBtnHomme().isSelected())
	       {
	    	  genre="Homme";
	       }
	       
	       if(vue.getRadioBtnFemme().isSelected())
	       {
	    	   genre="Femme";
	       }
	       
	  
	       if(vue.getCheckBoxJournaliere().isSelected())
	       {
	    	   TermeContrat="Location/Journali�re";
	       }
	       
	       if(vue.getCheckBoxLongterm().isSelected())
	       {
	    	   TermeContrat="Location/A Long Terme";
	       }
	      
	       
	    if(nom.isEmpty()||prenom.isEmpty()||numPiece.isEmpty()||numerotelph.isEmpty()||Email.isEmpty()||genre.equals("")||date.equals("")
	    		||TermeContrat.equals(""))
	      {
	    	   throw new IllegalArgumentException("Remplissez tous les champs svp !!!");
	      }
	    else
	    {
	    	model = new Locataire(nom,prenom,numPiece,genre,date,numerotelph,Email,TermeContrat);
	    			
	    	try {
	    				
				metier.AffectationDesBien(model, bien);
				int result=metier.VerificationAffectation(model);
				if(result==1)
				{
					vue.succesAffectation();
					vue.Clear();
				}
						
			  } catch (metierException e) {
						
						vue.MessageExceptionAffectation(e.getMessage());
			}		
	    	
	    }
		
	}
	
	public void run()
	{
		vue.run();
	}
	
	

}

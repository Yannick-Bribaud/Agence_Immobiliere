package app.Controleur;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import app.IMetier.exceptions.metierException;
import app.Modele.RealUsers;
import app.interfaces.vue.Authentification;
import app.interfaces.vue.Window;
import app.metier.impl.Metier;
import diu.swe.habib.JPanelSlider.JPanelSlider;


public class ControleurAuthentification {
	
	private RealUsers modelUser;
	private Authentification vue;
	private Window fenetre;
	
	public ControleurAuthentification(RealUsers modelUser, Authentification vue, Window fenetre) {
		super();
		this.modelUser = modelUser;
		this.vue = vue;
		this.fenetre = fenetre;
		
		addActionListener();
	}
	


	private void addActionListener() {
		
		vue.addValiderListner(new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent e) {
			   
				
				if(vue.getvaleurTextFieldPassword().length()<=0 &&  vue.getvaleurTextFieldEmail().length()>0)
				{
				  vue.getPanelSlider();
				vue.getPanelSlider().nextPanel(1, vue.getPanelPassword(), JPanelSlider.right);
						 			vue.getBtnValider().setEnabled(false);	
				}
				else
				{ 
					if(vue.getvaleurTextFieldEmail().length()<=0 && vue.getvaleurTextFieldPassword().length()<=0);
					
					else
					{
						 ClickOnValider();
					}
							 		
				}
				
			}

		});
		
		
		vue.addbtnReessayerListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				OnReessayerClik();
			}
			
		});
		
		
	}	
		
	
		protected void ClickOnValider() {
			
			String mail = vue.getTextFieldEmail().getText();
			String passWord = String.valueOf(vue.getPasswordField().getPassword());
		    modelUser = new RealUsers(passWord,mail);
			RealUsers User_T= new RealUsers("","","");
			Metier CoucheMetier = new Metier();
			try {
					User_T=CoucheMetier.AuthentifiacationUser(modelUser);
					
					if(User_T.getMotDepasse()=="Erreur" && User_T.getStatut()=="Erreur")
					{
						
						vue.PrintEchecAuthentification();
					}
					else {
								vue.dispose();
						  if( User_T.getStatut().equalsIgnoreCase("Administrateur"))
						     {
						         fenetre.getPanelSliderMenu().nextPanel(1, fenetre.getPanelMenuAdmin(), JPanelSlider.right);
						         fenetre.getPanelSliderDebord().nextPanel(1, fenetre.getPanelAdminTab(), JPanelSlider.left);
						     }
						  
						  if(User_T.getStatut().equalsIgnoreCase("Gestionnaire"))
						    {
						     		fenetre.getPanelSliderMenu().nextPanel(2, fenetre.getPanelGestionnaire(), JPanelSlider.right);
						     		fenetre.getPanelSliderDebord().nextPanel(2, fenetre.getPanneauAccueil(), JPanelSlider.left);		
						    }
					}
			 				
			} catch (metierException exception) {
				
				vue.MessageErreur(exception.getMessage());
			}	 			
	}
		
		
		public void OnReessayerClik()
		{
			vue.ressayerMethode();
			
			vue.getPanelSlider().nextPanel(1, vue.getPanelEmail(), JPanelSlider.right); 
						 	vue.getBtnValider().setEnabled(false);
		}
		
		public void run()
		{
			vue.run();
		}
		
	
	
	
	

}

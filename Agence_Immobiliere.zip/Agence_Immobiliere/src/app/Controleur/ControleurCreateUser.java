package app.Controleur;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import app.IMetier.exceptions.metierException;
import app.Modele.RealUsers;
import app.interfaces.vue.CreateUser;
import app.metier.impl.Metier;

public class ControleurCreateUser {
	
	private CreateUser vue;
	private  RealUsers user;
	
	
	public ControleurCreateUser(CreateUser vue, RealUsers user) {
		super();
		this.vue = vue;
		this.user = user;
		
		addActionListener();
	}


	private void addActionListener() {
		vue.addListenerBtnCreer(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				 try {
					 ClikOnbtnCreer();
				 }catch( RuntimeException exception) {
					 
					 vue.MessageRuntime(exception.getMessage());
				 }
			}
			
		});
		
		vue.ecouteurBtnTerminer(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				  ClikSurBtnTerminer();
			}
			
		});
		
	}

   protected void ClikSurBtnTerminer() {
	   vue.dispose();
		
	}


protected void ClikOnbtnCreer() {
		
	if(vue.getNomtextField().isEmpty() || vue.getPrenomtextField().isEmpty() || vue.getPasswordField().isEmpty() || 
			vue.getLogintextField().isEmpty() || vue.getComboBoxJours().equals("0") || vue.getComboBoxMois().equals("0")
			|| vue.getEmailtextField().isEmpty()|| vue.getAdressetextField().isEmpty()|| vue.getNumTelField().isEmpty())
	{
		  throw new RuntimeException(" Veullez renseigner tous les champs svp");	
	}
	else
	{	
		 String dateNaissance = vue.getComboBoxJours()+"/"+ vue.getComboBoxMois()+"/"+vue.getComboBoxAnnee();
		 String Statut = vue.getAdminCheckBox();
	    Metier CoucheMetier = new Metier();
  user = new RealUsers(vue.getNomtextField(),vue.getPrenomtextField(),vue.getAdressetextField(),vue.getNumTelField(),vue.getLogintextField(),
	    		vue.getPasswordField(),dateNaissance,vue.getEmailtextField(),Statut);
  
  				try {
  					
					CoucheMetier.CreationcompteUser(user);
					
					int resultat=CoucheMetier.TestExistUser(user);
					
					if(resultat==1);
					{
						vue.MessageDeReussite();
						vue.Clear();
					}
					
						if(resultat==0)
						{
							vue.MessagEchec();
						}
						
					
				} catch (metierException e) {
					
					vue.MessageException(e.getMessage());
				}
	     }
		
	}
   
   public void run() {
	   vue.runCreate();
   }


	
	

}

package app.IMetier.exceptions;

public class metierException extends Exception {

	private static final long serialVersionUID = 1L;

	public metierException(String message) {
		super(message);

	}
	
	

}

package app.IMetier;

import java.util.List;

import javax.swing.JComboBox;

import app.IMetier.exceptions.metierException;
import app.Modele.BienImmobiliers;
import app.Modele.Locataire;
import app.Modele.Paiement;
import app.Modele.RealUsers;



	public interface Imetier {
	
	// Utilisateurs
	public  RealUsers AuthentifiacationUser(RealUsers user)throws metierException;
	public  void CreationcompteUser(RealUsers user) throws metierException;
	public  void modifiercompteUser(RealUsers user) throws metierException;
	public  void suppressionCompteUser(int id) throws metierException;
	public  List<RealUsers> ListCompteUsers() throws metierException;
	public int TestExistUser(RealUsers user)throws metierException;
	
	// Bien Immobiliers 
	public void CreationBienImmo(BienImmobiliers bien)throws metierException;
	public void ModifBienImmo(BienImmobiliers bien)throws metierException;
	public List<BienImmobiliers> listDesBien() throws metierException;
	public List<BienImmobiliers> listDesBienDisponibles(String Statut) throws metierException;
	public void AffectationDesBien(Locataire locat,BienImmobiliers bien)throws metierException;
	public int TestExistImmobilier(BienImmobiliers bien)throws metierException;
			//Recherche d'element selectionner
	public BienImmobiliers RechercherSelection(String Selection)throws metierException;
	
	//paiement
	public void EnregistrerDesPaiements(Paiement paye, Locataire locat) throws metierException;
	public void ModificationDesPaiements(Paiement paye, Locataire locat)throws metierException;
	public void SupprimerPaiement(int identifiant)throws metierException;
	//Connexion composant
	public void ComboConnexion(JComboBox<String>comboBox)throws metierException;
	//Recherche Locaire
	public int VerificationAffectation( Locataire locat)throws metierException;
	//Recherche pour un Nouveau paiement
	public Locataire RechercherLocat(String piece)throws metierException;
	public BienImmobiliers RechercherById(int identifiant)throws metierException;
	public Paiement ResearchPaiement(Locataire locat,int identifiantbien)throws metierException;
	public Paiement ResearchPaiementJournalier(Locataire locat,int identifiantbien)throws metierException;
	public int VerificationPaiement(int idPaiement)throws metierException;
	public List<Paiement>Paye()throws metierException;
	public List<Locataire>ListeDesLocataire()throws metierException;
	public void SuppressionLocataire(int id) throws metierException;
	public void UpdateLocataire(String nom, String Prenom, String numPiece, String genre, String Dnaissance,
			String numTEL, String Email, int id)throws metierException;
	
	

}

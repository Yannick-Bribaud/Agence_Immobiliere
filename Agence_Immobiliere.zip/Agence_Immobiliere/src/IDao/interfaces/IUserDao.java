package IDao.interfaces;

import java.util.List;

import javax.swing.JComboBox;

import DaoExceptions.DaoException;
import app.Modele.BienImmobiliers;
import app.Modele.Locataire;
import app.Modele.Paiement;
import app.Modele.RealUsers;


public interface IUserDao {
	
	//--------------------------Operation sur les utilisateurs---------------------------------------------------
	
	  // Authentification des utilisateurs
	public RealUsers authentification(RealUsers user) throws DaoException;
	
	 // creation compte
	public void CreateUser(RealUsers user) throws DaoException;
	
	//suppression d'un compte Utilisateur.
	public void suppressionCompteUser(int Identifiant)throws DaoException;
	
	// Mis a jour Utilisateur
	public void MisAjourUser(RealUsers user)throws DaoException;
	
	// lecture des utilisateurs
	public List<RealUsers>list() throws DaoException;
	
	//test de la reussite de l'ajout User;
	public int testReussite(RealUsers user)throws DaoException;
	
	
	
	
	//--------------------Operation sur les bien Immobilier------------------------------------------------------
	
	
	
	// Ajout des biens Immobilier
	public void AjouterBienImmo(BienImmobiliers bien)throws DaoException;
	
	//Liste des Biens Immobiliers
	public List<BienImmobiliers>listBien()throws DaoException;
	
	//Modification des biens Immobiliers
	public void UpdateBienImmo(BienImmobiliers bien)throws DaoException;
	
	//Listes des Biens Immobiliers Disponible
	public List<BienImmobiliers>listBienDisponible(String statut)throws DaoException;
	
	// Affectation d'un bien Immobilier
	public void Affectation(Locataire locat,BienImmobiliers bien)throws DaoException;
	
	// Test Reussite Ajout bien Immobilier
	public int TestReussiteBienImmo(BienImmobiliers bien)throws DaoException;
	
	// verification de l'affectation
	public int VerifAffectation(Locataire locat)throws DaoException;
	
	//Recherche de l'item selectionner
	public BienImmobiliers recherche(String Selection)throws DaoException;
		
	//pour paiement
	public BienImmobiliers rechercheId(int identifiant)throws DaoException;
	
	
	
	
	//-------------------------------Operation sur les paiements--------------------------------------------------
	
	
	
	
	// Enregistrement paiement
	public List<Paiement>Paie()throws DaoException;
	//
	public void EnregistrerPaiement(Paiement paye, Locataire locat)throws DaoException;
	
	//Modification paiement
	public void ModifierPaiement(Paiement paye, Locataire locat)throws DaoException;
	
	//Suppression paiement
	public void SuppressionPaiement(int identifiantPaiement)throws DaoException;
	
	//
	public Paiement recherchesPaiementLongTerme(Locataire locat, int identifiant)throws DaoException;
	
	//
	public Paiement recherchesPaiementJournalier(Locataire locat, int identifiant)throws DaoException;
	//
	public int verificationPaiement(int identifiant) throws DaoException;
	

	
	//------------------------------------------------Locataire-------------------------------------------------------------------
	
	
	
	
	//lien vers la base de donne du combobox
	public void ComboConnexion(JComboBox<String> comboBox)throws DaoException;

	//Recherche locataire
	public Locataire rechercheLocataire(String Numpiece)throws DaoException;
	
	//Liste des Locatires
	List<Locataire>LocatList()throws DaoException;
	
	//supprimer un Locataire
	public void deleteLocataire(int id)throws DaoException;
	
	public void UpdateLocataire(String nom, String Prenom, String numPiece, String genre, String Dnaissance, String numTEL, String Email,int id)throws DaoException;
	
	
	

	
	
	
	
		
	
	
	
}

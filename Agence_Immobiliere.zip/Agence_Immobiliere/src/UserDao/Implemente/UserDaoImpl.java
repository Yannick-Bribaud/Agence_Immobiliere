package UserDao.Implemente;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;
import BD_access.AccessBaseDonnee;
import DaoExceptions.DaoException;

import IDao.interfaces.IUserDao;
import app.Modele.BienImmobiliers;
import app.Modele.Locataire;
import app.Modele.Paiement;
import app.Modele.RealUsers;


public class UserDaoImpl implements IUserDao {

	@Override
	public void CreateUser(RealUsers user) throws DaoException {
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Insert into Users(id,nom,prenom,login,motDepasse,adresse,dateNaissance,numero_tel,email,statut) "
					+ "values (?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, user.getIdentifiant());
			preparedStatement.setString(2, user.getNom());
			preparedStatement.setString(3, user.getPrenom());
			preparedStatement.setString(4, user.getLogin());
			preparedStatement.setString(5, user.getMotDepasse());
			preparedStatement.setString(6, user.getAdresse());
			preparedStatement.setString(7, user.getDateNaissance());
			preparedStatement.setString(8, user.getNumero_tel());
			preparedStatement.setString(9, user.getEmail());
			preparedStatement.setString(10, user.getStatut());
			
			
			preparedStatement.execute();
			
			}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
			
		}

	}
	

	@Override
	public void suppressionCompteUser(int Identifiant) throws DaoException {
		
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Delete from users where id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,Identifiant);
			
			preparedStatement.execute();
			 
			}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
			
		}

	}

	@Override
	public void MisAjourUser(RealUsers user) throws DaoException {
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "update users set nom = ?, prenom = ? , adresse = ?, numero_tel = ?, login = ?, motDepasse = ?,"
					+ "dateNaissance = ?, email = ?, statut = ? where id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, user.getNom());
			preparedStatement.setString(2, user.getPrenom());
			preparedStatement.setString(3, user.getAdresse());
			preparedStatement.setString(4, user.getNumero_tel());
			preparedStatement.setString(5, user.getLogin());
			preparedStatement.setString(6, user.getMotDepasse());
			preparedStatement.setString(7, user.getDateNaissance());
			preparedStatement.setString(8, user.getEmail());
			preparedStatement.setString(9, user.getStatut());
			preparedStatement.setInt(10, user.getIdentifiant());
			
			
			preparedStatement.execute();
			 
			
			}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
		}

	}


	@Override
	public List<RealUsers> list() throws DaoException {
		
			List<RealUsers> userList = new ArrayList<>();
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Select * from users";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query);
			
			while(resultat.next())
			{
				int id=resultat.getInt("id");
				String nom = resultat.getString("nom");
				String prenom = resultat.getString("prenom");
				String adresse = resultat.getString("adresse");
				String numero = resultat.getString("numero_tel");
				String login = resultat.getString("login");
				String mdp = resultat.getString("motDepasse");
				String dateNaissance = resultat.getString("dateNaissance");
				String mail = resultat.getString("email");
				String Statut = resultat.getString("statut");
				
				RealUsers User = new RealUsers(nom,prenom,adresse,numero,login,mdp,dateNaissance,mail,Statut);
				User.setIdentifiant(id);
				
				userList.add(User);
			}
			
		}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
		}
		return userList;
	}


	@Override
	public void AjouterBienImmo(BienImmobiliers bien) throws DaoException {
         try {
        	 
        	 Connection connection = AccessBaseDonnee.getInstance();
        	 String query = "Insert into bienimmobilier(identifiantBien,adresseBien,nombrePieces,montant,loyer,detail,statut)"
 					+ "values (?,?,?,?,?,?,?)";
        	 PreparedStatement preparedStatement = connection.prepareStatement(query);
        	preparedStatement.setInt(1, bien.getIdentifiantBien());
 			preparedStatement.setString(2, bien.getAdresseBien());
 			preparedStatement.setInt(3, bien.getNombrePieces());
 			preparedStatement.setInt(4, bien.getMontant());
 			preparedStatement.setInt(5, bien.getLoyer());
 			preparedStatement.setString(6, bien.getDetail());
 			preparedStatement.setString(7, bien.getStatut());
 			
 			preparedStatement.execute();
        	 
         }catch(SQLException e) {
        	 
        	 throw  new DaoException(e.getMessage());
         }
		
		
	}


	
	@Override
	public void UpdateBienImmo(BienImmobiliers bien) throws DaoException {
		try {
		Connection connection = AccessBaseDonnee.getInstance();
		String query = "update bienimmobilier set adresseBien = ?, nombrePieces = ? , montant = ?, loyer = ?, detail = ?, statut = ? "
				+ " where identifiantBien = ?";
		PreparedStatement preparedStatement = connection.prepareStatement(query);
		preparedStatement.setString(1, bien.getAdresseBien());
		preparedStatement.setInt(2, bien.getNombrePieces());
		preparedStatement.setInt(3, bien.getMontant());
		preparedStatement.setInt(4, bien.getLoyer());
		preparedStatement.setString(5, bien.getDetail());
		preparedStatement.setString(6, bien.getStatut());
		preparedStatement.setInt(7, bien.getIdentifiantBien());
		
		preparedStatement.execute();
		
		}catch(SQLException e) {
       	 
       	 throw  new DaoException(e.getMessage());
        }
		
		
		
		
		
	}

	@Override
	public List<BienImmobiliers> listBien() throws DaoException {
		
		List<BienImmobiliers> listeBien =new ArrayList<>();
		
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Select * from bienimmobilier";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query);
			
			while(resultat.next())
			{
				int ID = resultat.getInt("identifiantBien");
				String addresseBi1= resultat.getString("adresseBien");
				int  nombPieces= resultat.getInt("nombrePieces");
				int montAnt = resultat.getInt("montant");
				int lOyer = resultat.getInt("loyer");
				String dEtail = resultat.getString("detail");
				String Statut = resultat.getString("statut");
				
				BienImmobiliers bienajoute = new BienImmobiliers(addresseBi1,nombPieces,montAnt,lOyer,dEtail,Statut);
				bienajoute.setIdentifiantBien(ID);
				
				listeBien.add(bienajoute);
			}
			
		}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
		}
		
		return listeBien;
	}


	@Override
	public List<BienImmobiliers> listBienDisponible(String condition) throws DaoException {
		
			List<BienImmobiliers> listeBienDispo =new ArrayList<>();
			BienImmobiliers bienajoute;
		try {
			   //String condition="En Location/Oui";
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Select * from bienimmobilier WHERE Statut='"+condition+"'";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query);
			
			while(resultat.next())
			{
				int ID = resultat.getInt("identifiantBien");
				String addresseBi1= resultat.getString("adresseBien");
				int  nombPieces= resultat.getInt("nombrePieces");
				int montAnt = resultat.getInt("montant");
				int lOyer = resultat.getInt("loyer");
				String dEtail = resultat.getString("detail");
				String Statut = resultat.getString("statut");
				
				 bienajoute = new BienImmobiliers(addresseBi1,nombPieces,montAnt,lOyer,dEtail,Statut);
				bienajoute.setIdentifiantBien(ID);
				
				listeBienDispo.add(bienajoute);
			}
			
		}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
		}
		
		return listeBienDispo;
	}


	@Override
	public void Affectation(Locataire locat, BienImmobiliers bien) throws DaoException {
		
		String Statut ="En Location/Oui";
		
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Insert into locataire(identifiant_locataire,identifiantBien,nom_Locataire,prenom_locataire, num_Pieces_Locataire, genre,date_naissance, num_telephone, adresse_mail, d_Location) "
					+ "values (?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, locat.getIdentifiant_locataire());
			preparedStatement.setInt(2, bien.getIdentifiantBien());
			preparedStatement.setString(3, locat.getNom_Locataire());
			preparedStatement.setString(4, locat.getPrenom_locataire());
			preparedStatement.setString(5, locat.getNum_Pieces_Locataire());
			preparedStatement.setString(6, locat.getGenre());
			preparedStatement.setString(7, locat.getDate_naissance());
			preparedStatement.setString(8, locat.getNum_telephone());
			preparedStatement.setString(9, locat.getAdresse_mail());
			preparedStatement.setString(10,locat.getD_Location());
			bien.setStatut(Statut);
			
			
			preparedStatement.execute();
			 
			
			}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
			
		}

	}


	@Override
	public void EnregistrerPaiement(Paiement paye, Locataire locat) throws DaoException {
		
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Insert into paiement(identifiantPaiement,num_Pieces_Locataire,identifiantBien,caution,loyer,montantLocationJournalier,tranche_1,tranche_2, tranche_3) "
					+ "values (?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, paye.getIdentifiantPaiement());
			preparedStatement.setString(2, locat.getNum_Pieces_Locataire());
			preparedStatement.setInt(3, locat.getIdentifiant_locataire());
			preparedStatement.setInt(4, paye.getCaution());
			preparedStatement.setInt(5, paye.getLoyer());
			preparedStatement.setInt(6, paye.getMontantLocationJournalier());
			preparedStatement.setInt(7, paye.getTranche_1());
			preparedStatement.setInt(8, paye.getTranche_2());
			preparedStatement.setInt(9, paye.getTranche_3());
			
			
			preparedStatement.execute();
			 
			
			}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
			
		}

	}


	@Override
	public void ModifierPaiement(Paiement paye, Locataire locat) throws DaoException {
		
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "update paiement set num_Pieces_Locataire = ?, caution= ? , loyer = ?, montantLocationJournalier = ?, tranche_1 = ?, tranche_2 = ?, "
					+ "tranche_3 = ?  where identifiantPaiement = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, locat.getNum_Pieces_Locataire());
			preparedStatement.setInt(2, paye.getCaution());
			preparedStatement.setInt(3, paye.getLoyer());
			preparedStatement.setInt(4, paye.getMontantLocationJournalier());
			preparedStatement.setInt(5, paye.getTranche_1());
			preparedStatement.setInt(6, paye.getTranche_2());
			preparedStatement.setInt(7, paye.getTranche_3());
			preparedStatement.setInt(8, paye.getIdentifiantPaiement());
			
			preparedStatement.execute();
			
			}catch(SQLException e) {
	       	 
	       	 throw  new DaoException(e.getMessage());
	        }
			
			
	}


	@Override
	public void SuppressionPaiement(int identifiantPaiement) throws DaoException {
		
		try {
			
				Connection connection = AccessBaseDonnee.getInstance();
				String query = "Delete from paiement where identifiantPaiement = ?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1,identifiantPaiement);
				
				preparedStatement.execute();
				 
				}catch(SQLException e) {
				
				throw new DaoException(e.getMessage());
			
		}
	}


	@Override
	public RealUsers authentification(RealUsers user) throws DaoException {
		 int nbreLigne=0;String statutUser; String email; String motDpass;
		 RealUsers UserTest = new RealUsers("Erreur","Erreur","Erreur");
		  
		try {
				Connection connection = AccessBaseDonnee.getInstance();
				String query = "SELECT * FROM users WHERE email ='"+user.getEmail()+"'and motDepasse ='"+user.getMotDepasse()+"'";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultat = preparedStatement.executeQuery(query); 
				
			while(resultat.next())
			{
				nbreLigne++;
				
				if(nbreLigne<=0 || nbreLigne>1) 
				 {
					
					return UserTest;
				 }
			}
			
			if(nbreLigne==1)
			{
			
				resultat.first();
				motDpass=resultat.getString("motDepasse");
				email=resultat.getString("email");
			    statutUser = resultat.getString("statut");			
			   UserTest = new RealUsers(motDpass,email,statutUser);
			}
			
		}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
	}
		return UserTest;
		
	}


	@Override
	public int testReussite(RealUsers user) throws DaoException {
		int nbreLigne=0;
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT * FROM users WHERE email ='"+user.getEmail()+"'and motDepasse ='"+user.getMotDepasse()+"'";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
		while(resultat.next())
		{
			nbreLigne++;
		}
		
		if(nbreLigne==1){
		    return 1;
		}
		
		
		
	}catch(SQLException e) {
		
		throw new DaoException(e.getMessage());
}
		return 0;
	}


	@Override
	public int TestReussiteBienImmo(BienImmobiliers bien) throws DaoException {
		
		int nbreLigne=0;
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT * FROM bienimmobilier WHERE identifiantBien ='"+bien.getIdentifiantBien()+"'";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
		while(resultat.next())
		{
			nbreLigne++;
		}
		
		if(nbreLigne==1)
		{
		    return 1;
		}
		
	}catch(SQLException e) {
		
		throw new DaoException(e.getMessage());
}
		return 0;
	}


	@Override
	public void ComboConnexion(JComboBox<String> comboBox) throws DaoException {
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT * FROM bienimmobilier"; 
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
			while(resultat.next())
			{
				comboBox.addItem(resultat.getString("detail"));
			}
		
		}catch(SQLException e) {
		
		throw new DaoException(e.getMessage());
		}
		
	}


	@Override
	public BienImmobiliers recherche(String Selection) throws DaoException {
		
		BienImmobiliers bienTrouve=null;
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT * FROM bienimmobilier WHERE detail='"+Selection+"'"; 
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
			while(resultat.next())
			{
				int ID = resultat.getInt("identifiantBien");
				String addresseBi1= resultat.getString("adresseBien");
				int  nombPieces= resultat.getInt("nombrePieces");
				int montAnt = resultat.getInt("montant");
				int lOyer = resultat.getInt("loyer");
				String dEtail = resultat.getString("detail");
				String Statut = resultat.getString("statut");
				
			    bienTrouve = new BienImmobiliers(addresseBi1,nombPieces,montAnt,lOyer,dEtail,Statut);
				bienTrouve.setIdentifiantBien(ID);
			}
		
		}catch(SQLException e) {
		
		throw new DaoException(e.getMessage());
		}
		
		return bienTrouve;
	}


	@Override
	public int VerifAffectation(Locataire locat) throws DaoException {
		
		int nbreLigne=0;
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT * FROM locataire WHERE identifiant_locataire ='"+locat.getIdentifiant_locataire()+"'";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
		while(resultat.next())
		{
			nbreLigne++;
		}
		
		if(nbreLigne==1)
		{
		    return 1;
		}
		
	}catch(SQLException e) {
		
	throw new DaoException(e.getMessage());
   }
		
		return 0;
	}


	@Override
	public Locataire rechercheLocataire(String piece) throws DaoException {
		
		 Locataire locataire = new Locataire();
		 int idBien; String nomLocat;  String prenom;String dureeLocation; String numpiece;
		int nbreLigne=0;
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT * FROM locataire WHERE num_Pieces_Locataire='"+piece+"'";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
		while(resultat.next())
		{
				nbreLigne++;
				idBien = resultat.getInt("identifiantBien");
			   nomLocat = resultat.getString("nom_Locataire");
			   prenom = resultat.getString("prenom_Locataire");
			   numpiece=resultat.getString("num_Pieces_Locataire");
			   dureeLocation = resultat.getString("d_Location");
			   
			  locataire = new Locataire(idBien,nomLocat,prenom,numpiece,dureeLocation);
			  locataire.setIdentifiant_locataire(idBien);
			  
		}
		
		if(nbreLigne==1)
		{
			  
		  return locataire;
		}
		
	}catch(SQLException e) {
		
	throw new DaoException(e.getMessage());
   }
		return null;
	}


	@Override
	public BienImmobiliers rechercheId(int identifiant) throws DaoException {
		
		BienImmobiliers bienTrouve = new BienImmobiliers();
		int nbre=0;int ID;String addresseBi1;int  nombPieces; int montAnt; int lOyer; String dEtail;String Statut;
		try {
				Connection connection = AccessBaseDonnee.getInstance();
				String query = "SELECT * FROM bienimmobilier WHERE identifiantBien='"+identifiant+"'"; 
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultat = preparedStatement.executeQuery(query); 
			
			while(resultat.next())
			{
				nbre++;
				 ID = resultat.getInt("identifiantBien");
				 addresseBi1= resultat.getString("adresseBien");
				 nombPieces= resultat.getInt("nombrePieces");
				 montAnt = resultat.getInt("montant");
				 lOyer = resultat.getInt("loyer");
				 dEtail = resultat.getString("detail");
				 Statut = resultat.getString("statut");
				
			    bienTrouve = new BienImmobiliers(addresseBi1,nombPieces,montAnt,lOyer,dEtail,Statut);
				bienTrouve.setIdentifiantBien(ID);
			}
			
			if(nbre==1)
			{
				return bienTrouve;
			}
		
		}catch(SQLException e) {
		
		throw new DaoException(e.getMessage());
		}
		return null;
	}


	@Override
	public Paiement recherchesPaiementLongTerme(Locataire Locat,int identifiant) throws DaoException {
		   Paiement paye=new Paiement();
		try {
			
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT SUM(caution) as Caution,SUM(loyer) as loyer_total FROM paiement WHERE num_Pieces_Locataire='"+Locat.getNum_Pieces_Locataire()+"'and identifiantBien='"+identifiant+"'";
																								
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
			while(resultat.next())
			{
				 int caution = resultat.getInt("Caution");
				 int loyerTotal=resultat.getInt("loyer_total");
				 
				 paye=new Paiement(caution,loyerTotal);                                       	 
			}
			
		}catch(SQLException e) {
		
			throw new DaoException(e.getMessage());
		}
		return paye;
		
	}


	@Override
	public Paiement recherchesPaiementJournalier(Locataire locat, int identifiant) throws DaoException {
		
		
		   Paiement paye=new Paiement();
		try {
			
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "SELECT SUM(montantLocationJournalier) as Montant_Journalier,tranche_1,tranche_2,tranche_3 FROM paiement WHERE num_Pieces_Locataire='"+locat.getNum_Pieces_Locataire()+"'and identifiantBien='"+identifiant+"'";
																								
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query); 
			
			while(resultat.next())
			{
				
				 int Montant_Journalier = resultat.getInt("Montant_Journalier");
				 int tranche_1=resultat.getInt("tranche_1");
				 int tranche_2=resultat.getInt("tranche_2");
				 int tranche_3=resultat.getInt("tranche_3");
				 
				 paye = new Paiement(Montant_Journalier,tranche_1,tranche_2,tranche_3);                                      
				 	 
			}
			
		}catch(SQLException e) {
		
			throw new DaoException(e.getMessage());
		}
		
		
		return paye;
	}


	@Override
	public int verificationPaiement(int identifiant) throws DaoException {
		
		int nbreLigne=0;
		try {
				Connection connection = AccessBaseDonnee.getInstance();
				String query = "SELECT * FROM paiement WHERE identifiantPaiement ='"+identifiant+"'";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultat = preparedStatement.executeQuery(query); 
			
		while(resultat.next())
		{
			nbreLigne++;
		}
		
		if(nbreLigne==1)
		{
		    return 1;
		}
		
	}catch(SQLException e) {
		
	throw new DaoException(e.getMessage());
   }
		
		return 0;
	}


	@Override
	public List<Paiement>Paie() throws DaoException {
		
		List<Paiement> PayeListe =new ArrayList<>();
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Select * from paiement";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query);
			
			while(resultat.next())
			{
				int ID = resultat.getInt("identifiantPaiement");
				String NumPieces = resultat.getString("num_Pieces_Locataire");
				int  IdentifiantBien= resultat.getInt("identifiantBien");
				int Caution = resultat.getInt("caution");
				int lOyer = resultat.getInt("loyer");
				int MontantJournalier = resultat.getInt("montantLocationJournalier");
				int tranche1 = resultat.getInt("tranche_1");
				int tranche2 =resultat.getInt("tranche_2");
				int tranche3 =resultat.getInt("tranche_3");
				
				Paiement Paye = new Paiement(Caution,lOyer,MontantJournalier,tranche1,tranche2,tranche3,NumPieces,IdentifiantBien);
				Paye.setIdentifiantPaiement(ID);
				
				PayeListe.add(Paye);
			}
			
		}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
		}
		
		return PayeListe;
	
	}


	@Override
	public List<Locataire> LocatList() throws DaoException {
		
		List<Locataire> LocataireListe =new ArrayList<>();
		try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Select * from Locataire";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultat = preparedStatement.executeQuery(query);
			
			while(resultat.next())
			{
				int ID = resultat.getInt("identifiant_locataire");
				String NomLocat = resultat.getString("nom_Locataire");
				//int  IdentifiantBien= resultat.getInt("identifiantBien");
				String prenom = resultat.getString("prenom_locataire");
				String  NumPi�ces = resultat.getString("num_Pieces_Locataire");
				String Genre= resultat.getString("genre");
				String Date = resultat.getString("date_naissance");
				String tel =resultat.getString("num_telephone");
				String Email =resultat.getString("adresse_mail");
				String Duree = resultat.getString("d_Location");
				
				Locataire Locat = new Locataire(NomLocat,prenom,NumPi�ces,Genre,Date,tel,Email,Duree);
				Locat.setIdentifiant_locataire(ID);
				
				LocataireListe.add(Locat);
			}
			
		}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
		}
		
		return LocataireListe;
	}


	@Override
	public void deleteLocataire(int id) throws DaoException {
		
try {
			
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "Delete from Locataire where identifiant_locataire = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,id);
			
			preparedStatement.execute();
			 
			}catch(SQLException e) {
			
			throw new DaoException(e.getMessage());
			
		}
		
	}


	@Override
	public void UpdateLocataire(String nom, String Prenom, String numPiece, String genre, String Dnaissance,
			String numTEL, String Email, int id) throws DaoException {
		
		try {
			Connection connection = AccessBaseDonnee.getInstance();
			String query = "update Locataire set nom_Locataire = ?, prenom_locataire= ? , num_Pieces_Locataire = ?, genre = ?, date_naissance = ?, num_telephone = ?,"
					+ "adresse_mail = ? where identifiant_locataire = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, nom );
			preparedStatement.setString(2, Prenom);
			preparedStatement.setString(3, numPiece);
			preparedStatement.setString(4, genre);
			preparedStatement.setString(5, Dnaissance);
			preparedStatement.setString(6, numTEL);
			preparedStatement.setString(7, Email);
			preparedStatement.setInt(8, id);
			
			preparedStatement.execute();
			
			}catch(SQLException e) {
	       	 
	       	 throw  new DaoException(e.getMessage());
	        }
		
		
	}



}
